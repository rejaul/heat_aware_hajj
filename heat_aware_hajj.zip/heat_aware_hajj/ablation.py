"""
Ablation study: isolate the contribution of each framework component.

Answers Reviewer 3's request to separate the effects of heat awareness,
capacity constraints, equity, and conformal calibration, rather than only
contrasting shortest-path with the full method.

Five variants, each ADDING one component to the previous, all on the SAME leg,
SAME demand, SAME network and SAME exceedance field, so differences are
attributable to the component alone:

  V1 shortest         theta = 0, no capacity, no equity, raw index costs
  V2 + heat-aware     theta > 0 on the edge cost
  V3 + hard capacity  time-expanded assignment with Q_ij per slice
  V4 + equity         lexicographic cohort ordering on residual capacity
  V5 + ECP costs      calibrated P(LST > k) instead of the raw normalised index

Metrics reported for every variant:
  distance, travel time, thermal dose, peak density, minutes above the danger
  threshold, feasibility, and (V4+) the per-cohort dose spread.

IMPORTANT ON V5. V1-V4 use the raw normalised exceedance index as the edge cost.
V5 substitutes the ECP-calibrated exceedance probability. The comparison is only
meaningful if BOTH are on the same scale, so we rescale the raw index to [0,1]
by its own empirical CDF before use. State this in the paper: it isolates
"calibrated vs uncalibrated ordering of edges", not a units change.

Usage
-----
    python ablation.py --demo                        # synthetic corridor
    python ablation.py --risk field_prob.npy         # real OSM + real field
    python ablation.py --risk field_prob.npy --calibrated calib_prob.npy
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import networkx as nx

from routing_physics import PARAMS, speed_from_density
from routing_scalarized import RoutingGraph, assign_leg_cfw
from assignment_td import (TimeExpanded, assign_cohort, lexicographic_assign,
                           flow_maximising_density, COHORT_ORDER, COHORT_SHARE,
                           COHORT_THETA)


# ---------------------------------------------------------------------------
def to_unit_scale(E):
    """
    Map an arbitrary non-negative index onto [0,1] by its empirical CDF, so the
    uncalibrated and ECP-calibrated costs are compared on the same scale.
    """
    E = np.asarray(E, float)
    order = np.argsort(E)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(E.size)
    return ranks / max(E.size - 1, 1)


def leg_metrics_uncapacitated(rg, src, dst, theta, demand, p=PARAMS):
    """V1/V2: equilibrium routing with a SOFT crush penalty, no hard capacity."""
    r = assign_leg_cfw(rg, src, dst, demand, theta, p, iters=40, method="fw")
    if r is None:
        return {"status": "no_path"}
    return {"status": "ok",
            "distance_km": r["distance_m"] / 1000.0,
            "time_min": r["time_min"],
            "dose": r["dose"],
            "peak_rho": r["peak_rho"],
            "danger_min": r["danger_min"],
            "feasible": True,
            "gap": r["gap"]}


def leg_metrics_capacitated(rg, src, dst, theta, n_people, p=PARAMS,
                            dt_s=900.0, window_frac=3):
    """V3: hard capacity per (edge, slice), single cohort."""
    probe = TimeExpanded(rg, n_slices=4, dt_s=dt_s); probe.build(theta=0.0)
    need = probe.min_slices_for(src, dst)
    if need is None:
        return {"status": "unreachable"}
    T = int(need * 2 + 6)
    te = TimeExpanded(rg, n_slices=T, dt_s=dt_s); te.build(theta=theta)
    flow, m = assign_cohort(te, src, dst, n_people, (0, max(2, T // window_frac)),
                            theta)
    if flow is None:
        return {"status": "infeasible", "reason": m, "feasible": False}
    return {"status": "ok",
            "distance_km": m["mean_km"],
            "time_min": m["mean_minutes"],
            "dose": m["mean_dose"],
            "peak_rho": None,               # bounded by construction
            "max_utilisation": m["max_utilisation"],
            "arcs_at_capacity": m["arcs_at_capacity"],
            "feasible": True}


def leg_metrics_equity(rg, src, dst, n_people, p=PARAMS, dt_s=900.0,
                       window_frac=3):
    """V4/V5: hard capacity + lexicographic multi-cohort assignment."""
    probe = TimeExpanded(rg, n_slices=4, dt_s=dt_s); probe.build(theta=0.0)
    need = probe.min_slices_for(src, dst)
    if need is None:
        return {"status": "unreachable"}
    T = int(need * 2 + 6)
    te = TimeExpanded(rg, n_slices=T, dt_s=dt_s); te.build(theta=0.0)
    res = lexicographic_assign(te, src, dst, n_people,
                               (0, max(2, T // window_frac)), verbose=False)
    doses = {k: v["mean_dose"] for k, v in res.items()
             if isinstance(v, dict) and "mean_dose" in v}
    if not doses:
        return {"status": "infeasible", "feasible": False}
    prot = doses.get(COHORT_ORDER[0])
    km = {k: v["mean_km"] for k, v in res.items()
          if isinstance(v, dict) and "mean_km" in v}
    mins = {k: v["mean_minutes"] for k, v in res.items()
            if isinstance(v, dict) and "mean_minutes" in v}
    return {"status": "ok",
            "distance_km": float(np.mean(list(km.values()))),
            "time_min": float(np.mean(list(mins.values()))),
            "dose": float(np.mean(list(doses.values()))),
            "protected_dose": prot,
            "dose_spread": float(max(doses.values()) - min(doses.values())),
            "dose_ratio": float(max(doses.values()) / max(min(doses.values()), 1e-9)),
            "per_cohort_dose": {k: float(v) for k, v in doses.items()},
            "feasible": True}


# ---------------------------------------------------------------------------
def run_ablation(rg, src, dst, n_people, theta, E_raw, E_cal=None, p=PARAMS):
    """Run all five variants on identical inputs."""
    rows = []

    # --- V1: shortest path (theta = 0) -----------------------------------
    rg.E = E_raw.copy()
    demand_rate = n_people / (PARAMS["leg_window_h"] * 3600.0)
    m = leg_metrics_uncapacitated(rg, src, dst, 0.0, demand_rate, p)
    m.update({"variant": "V1 shortest", "components": "-"})
    rows.append(m)

    # --- V2: + heat-aware cost -------------------------------------------
    m = leg_metrics_uncapacitated(rg, src, dst, theta, demand_rate, p)
    m.update({"variant": "V2 + heat-aware", "components": "heat"})
    rows.append(m)

    # --- V3: + hard capacity ---------------------------------------------
    m = leg_metrics_capacitated(rg, src, dst, theta, n_people, p)
    m.update({"variant": "V3 + hard capacity", "components": "heat+cap"})
    rows.append(m)

    # --- V4: + lexicographic equity --------------------------------------
    m = leg_metrics_equity(rg, src, dst, n_people, p)
    m.update({"variant": "V4 + equity", "components": "heat+cap+eq"})
    rows.append(m)

    # --- V5: + ECP-calibrated edge costs ---------------------------------
    if E_cal is not None:
        rg.E = E_cal.copy()
        m = leg_metrics_equity(rg, src, dst, n_people, p)
        m.update({"variant": "V5 + ECP costs", "components": "heat+cap+eq+ecp"})
        rows.append(m)
        rg.E = E_raw.copy()
    else:
        rows.append({"variant": "V5 + ECP costs", "status": "skipped",
                     "components": "heat+cap+eq+ecp",
                     "reason": "no --calibrated grid supplied"})
    return rows


def print_table(rows):
    print("\n" + "=" * 104)
    print("ABLATION: isolating each component (same leg, demand, network, field)")
    print("=" * 104)
    hdr = (f"{'variant':<22}{'feas':>6}{'km':>8}{'min':>9}{'dose':>11}"
           f"{'peak rho':>10}{'spread':>9}{'ratio':>8}")
    print(hdr); print("-" * 104)
    for r in rows:
        if r.get("status") not in ("ok",):
            print(f"{r['variant']:<22}{'--':>6}   {r.get('status','')}"
                  f"  {r.get('reason','')}")
            continue
        pr = r.get("peak_rho")
        pr_s = "  bounded" if pr is None else f"{pr:10.2f}"
        sp = r.get("dose_spread"); rt = r.get("dose_ratio")
        sp_s = "       --" if sp is None else f"{sp:9.1f}"
        rt_s = "      --" if rt is None else f"{rt:8.3f}"
        print(f"{r['variant']:<22}{'yes' if r.get('feasible') else 'no':>6}"
              f"{r['distance_km']:8.2f}{r['time_min']:9.1f}{r['dose']:11.1f}"
              f"{pr_s}{sp_s}{rt_s}")
    print("-" * 104)
    print("peak rho: 'bounded' means hard capacity makes crush density")
    print("  unreachable BY CONSTRUCTION, not merely penalised.")
    print("spread/ratio: dose difference between most- and least-vulnerable")
    print("  cohorts; only defined once the equity component is enabled.")

    # deltas
    ok = [r for r in rows if r.get("status") == "ok"]
    if len(ok) >= 2:
        base = ok[0]
        print("\n  marginal effect of each added component (vs V1 shortest):")
        for r in ok[1:]:
            dd = 100 * (base["dose"] - r["dose"]) / max(base["dose"], 1e-9)
            det = 100 * (r["distance_km"] - base["distance_km"]) / max(base["distance_km"], 1e-9)
            print(f"    {r['variant']:<22} dose {dd:+6.1f}%   distance {det:+6.1f}%")


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", help=".npy uncalibrated exceedance/index grid")
    ap.add_argument("--calibrated", help=".npy ECP-calibrated P(LST>k) grid")
    ap.add_argument("--bbox", help="west,south,east,north")
    ap.add_argument("--from", dest="src", default="Mina")
    ap.add_argument("--to", dest="dst", default="Arafat")
    ap.add_argument("--people", type=float, default=None,
                    help="pilgrims on this leg (default: config scale)")
    ap.add_argument("--theta", type=float, default=None,
                    help="value of avoiding heat (default: most-vulnerable cohort)")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo or not args.risk:
        print("DEMO MODE: schematic corridor (documented site geometry, NOT OSM)\n")
        from schematic_corridor import build_corridor
        from routing_equilibrium import prepare_edges
        G, nodes, meta = build_corridor()
        rg = RoutingGraph(G)
        E_raw = rg.E.copy()
        E_cal = np.clip(to_unit_scale(E_raw), 0.01, 0.99)   # stand-in
    else:
        from corridor_network import fetch, snap_sites
        from routing_equilibrium import prepare_edges
        G = fetch(); snapped = snap_sites(G)
        nodes = {k: v["node"] for k, v in snapped.items()}
        field = np.load(args.risk)
        bbox = (tuple(float(x) for x in args.bbox.split(","))
                if args.bbox else __import__("config").BBOX)
        prepare_edges(G, field, bbox)
        rg = RoutingGraph(G)
        E_raw = to_unit_scale(rg.E)          # put on [0,1] for comparability
        if args.calibrated:
            Gc = fetch()
            prepare_edges(Gc, np.load(args.calibrated), bbox)
            rgc = RoutingGraph(Gc)
            E_cal = np.clip(rgc.E, 0.0, 1.0)
        else:
            E_cal = None

    src, dst = nodes[args.src], nodes[args.dst]
    n_people = (args.people if args.people is not None
                else PARAMS["n_pilgrims"] * PARAMS["walk_fraction"])
    theta = args.theta if args.theta is not None else COHORT_THETA[COHORT_ORDER[0]]
    r_s, v_s, q_s = flow_maximising_density()

    print(f"graph      : V={rg.S.number_of_nodes():,} E={rg.m:,}")
    print(f"leg        : {args.src} -> {args.dst}")
    print(f"demand     : {n_people:,.0f} pilgrims")
    print(f"theta      : {theta:.0f} s per unit dose "
          f"({COHORT_ORDER[0]} cohort)")
    print(f"capacity at: rho*={r_s:.3f} ped/m2, v*={v_s:.3f} m/s, q*={q_s:.3f}")
    print(f"ECP costs  : {'supplied' if E_cal is not None else 'NOT supplied (V5 skipped)'}")

    rg.E = E_raw.copy()
    rows = run_ablation(rg, src, dst, n_people, theta, E_raw, E_cal)
    print_table(rows)

    json.dump(rows, open("ablation_results.json", "w"), indent=2, default=str)
    print("\n  results -> ablation_results.json")
    print("\n  Report this as the ablation table. Each row adds ONE component,")
    print("  so the row-to-row differences are the marginal contributions the")
    print("  reviewer asked to see isolated.")


if __name__ == "__main__":
    main()
