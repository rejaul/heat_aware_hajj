"""
Sensitivity of feasibility to the ACCESS-SET assumption.

Why this exists
---------------
Feasibility on the real corridor turned out to be decided almost entirely by how
demand is allowed to ENTER the network, not by the network itself:

  * one access node per site (nearest-node snapping): Arafat landed on a
    degree-1 node on a 3 m footpath, capping the leg at 1.225*3*3600 = 13,230
    ped/h against 810,000 demand. Everything was INFEASIBLE, and 100% of
    saturated arcs sat 92 m from that node.
  * forty access nodes within 2 km: injection capacity rises to ~1.4M ped/h,
    roughly double demand, and EVERYTHING became feasible -- including a
    half-hour dispatch window, with dose, distance and travel time identical
    across windows from 0.5 h to 26.5 h. A model in which the dispatch window
    changes nothing is not measuring the dispatch window.

Both are artefacts of an assumption, in opposite directions. The honest response
is not to pick a number but to report the range over which the conclusion holds.
This script sweeps the access-set size (and optionally the radius) and finds
where feasibility breaks, so the paper can state a bracket rather than a point.

Run
---
    python access_sensitivity.py --risk field_prob.npy
    python access_sensitivity.py --risk field_prob.npy --nodes 1 2 5 10 20 40
    python access_sensitivity.py --risk field_prob.npy --sweep-radius
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import math
import warnings

warnings.filterwarnings("ignore")

import numpy as np

WIDTH_BY_TAG = {"pedestrian": 20, "footway": 6, "path": 4, "steps": 3,
                "primary": 20, "secondary": 15, "tertiary": 12,
                "residential": 8, "service": 6, "track": 5,
                "living_street": 8, "primary_link": 20, "unclassified": 8}


def injection_capacity(G, nodes, q_star=1.225):
    """Max pedestrians per hour that can enter through a set of nodes."""
    und = G.to_undirected()
    total_w = 0.0
    for n in nodes:
        for _, _, d in und.edges(n, data=True):
            tag = d.get("highway", "unclassified")
            if isinstance(tag, list):
                tag = tag[0]
            total_w += WIDTH_BY_TAG.get(str(tag), 8.0)
    return q_star * total_w * 3600.0, total_w


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", required=True)
    ap.add_argument("--bbox")
    ap.add_argument("--from", dest="src", default="Mina")
    ap.add_argument("--to", dest="dst", default="Arafat")
    ap.add_argument("--nodes", nargs="+", type=int,
                    default=[1, 2, 3, 5, 10, 20, 40],
                    help="access-set sizes to test")
    ap.add_argument("--sweep-radius", action="store_true",
                    help="also sweep the access radius at a fixed node cap")
    ap.add_argument("--pilgrims", type=float, default=1_800_000)
    ap.add_argument("--walk-frac", type=float, default=0.45)
    ap.add_argument("--dt-min", type=float, default=30.0)
    ap.add_argument("--window", type=int, default=None,
                    help="dispatch window in slices (default: T//3)")
    args = ap.parse_args()

    import corridor_network as cn
    from corridor_network import fetch, snap_sites
    from routing_equilibrium import prepare_edges
    from routing_scalarized import RoutingGraph
    from assignment_td import TimeExpanded, assign_cohort, COHORT_THETA, COHORT_ORDER
    import config

    G = fetch()
    field = np.load(args.risk)
    bbox = (tuple(float(x) for x in args.bbox.split(",")) if args.bbox
            else config.BBOX)
    prepare_edges(G, field, bbox)
    rg = RoutingGraph(G)
    N = args.pilgrims * args.walk_frac
    theta = COHORT_THETA[COHORT_ORDER[0]]

    print("=" * 88)
    print("ACCESS-SET SENSITIVITY")
    print("=" * 88)
    print(f"  leg {args.src} -> {args.dst}   demand {N:,.0f} walkers   "
          f"theta {theta:.0f}")
    print(f"  network V={rg.S.number_of_nodes():,} E={rg.m:,}")

    rows = []
    print(f"\n{'nodes':>6}{'inject ped/h':>15}{'vs demand':>11}"
          f"{'feasible':>10}{'km':>8}{'min':>9}{'dose':>11}{'arcs full':>11}")
    print("-" * 88)

    for k in args.nodes:
        cn.MAX_ACCESS_NODES = k
        snapped = snap_sites(G)
        src = snapped[args.src]["access"][:k]
        dst = snapped[args.dst]["access"][:k]

        cap_h, wm = injection_capacity(G, src)
        ratio = cap_h / max(N, 1)

        probe = TimeExpanded(rg, n_slices=4, dt_s=args.dt_min * 60)
        probe.build(theta=0.0)
        need = probe.min_slices_for(src, dst)
        if need is None:
            print(f"{k:>6}{cap_h:>15,.0f}{ratio:>11.2f}{'unreach':>10}")
            rows.append({"nodes": k, "inject_ped_h": cap_h, "feasible": False,
                         "reason": "unreachable"})
            continue

        T = int(need * 2 + 6)
        te = TimeExpanded(rg, n_slices=T, dt_s=args.dt_min * 60)
        te.build(theta=theta)
        win = args.window if args.window else max(2, T // 3)
        flow, m = assign_cohort(te, src, dst, N, (0, win), theta)

        if flow is None:
            print(f"{k:>6}{cap_h:>15,.0f}{ratio:>11.2f}{'NO':>10}"
                  f"   {str(m)[:40]}")
            rows.append({"nodes": k, "inject_ped_h": cap_h, "width_m": wm,
                         "feasible": False, "reason": str(m)})
        else:
            print(f"{k:>6}{cap_h:>15,.0f}{ratio:>11.2f}{'yes':>10}"
                  f"{m['mean_km']:>8.2f}{m['mean_minutes']:>9.1f}"
                  f"{m['mean_dose']:>11.1f}{m['arcs_at_capacity']:>11}")
            rows.append({"nodes": k, "inject_ped_h": cap_h, "width_m": wm,
                         "feasible": True, "km": m["mean_km"],
                         "minutes": m["mean_minutes"], "dose": m["mean_dose"],
                         "arcs_full": m["arcs_at_capacity"],
                         "max_util": m["max_utilisation"]})

    print("-" * 88)

    feas = [r for r in rows if r.get("feasible")]
    infeas = [r for r in rows if not r.get("feasible")]
    if feas and infeas:
        kmin = min(r["nodes"] for r in feas)
        kmax = max(r["nodes"] for r in infeas)
        print(f"\n  FEASIBILITY BOUNDARY: infeasible up to {kmax} access nodes, "
              f"feasible from {kmin}")
        print(f"  -> the conclusion depends on the access assumption. Report the")
        print(f"     boundary, not a single feasibility claim.")
    elif feas and not infeas:
        print(f"\n  Feasible at EVERY access-set size tested, including "
              f"{min(r['nodes'] for r in feas)} node(s).")
        print("  -> feasibility is not access-limited here; the binding")
        print("     constraint lies elsewhere (or nowhere) on this leg.")
    else:
        print("\n  Infeasible at every size tested -- the network, not the")
        print("  access assumption, is binding. Investigate interior arcs.")

    if feas:
        doses = [r["dose"] for r in feas]
        kms = [r["km"] for r in feas]
        print(f"\n  across feasible settings: dose {min(doses):.0f}-{max(doses):.0f} "
              f"({100*(max(doses)-min(doses))/max(min(doses),1e-9):.1f}% spread), "
              f"distance {min(kms):.2f}-{max(kms):.2f} km")
        if (max(doses) - min(doses)) / max(min(doses), 1e-9) < 0.02:
            print("  [note] dose barely moves with the access set, so the routed")
            print("  path is essentially the same; the access assumption governs")
            print("  FEASIBILITY, not the route. Say so explicitly.")

    json.dump(rows, open("access_sensitivity.json", "w"), indent=2, default=str)
    print("\n  results -> access_sensitivity.json")
    print("\n  For the paper: report the access radius and node cap in the")
    print("  assumptions table, and give the feasibility boundary above rather")
    print("  than a single 'minimum feasible window'.")


if __name__ == "__main__":
    main()
