"""
Co-register ERA5-Land (0.1 deg, hourly) with ECOSTRESS L2T LST (70 m,
irregular overpasses) to build training pairs for the AMUN downscaler.

Pipeline
--------
1. Load an ECOSTRESS tile, mask by QC / cloud / water.
2. Take the granule's acquisition time; select the bracketing ERA5-Land hours
   and interpolate linearly in time.
3. Apply the derived variables (2 m wind, RH, sunlit-corrected radiation, WBGT).
4. Reproject the coarse ERA5 stack onto the fine ECOSTRESS grid.
5. Write an aligned NetCDF: coarse predictors + fine LST target on one grid.

The output of step 5 is exactly the (input, target) pair the U-Net consumes.
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr
import rioxarray  # noqa: F401  (registers the .rio accessor)
from rasterio.enums import Resampling

import config
import solar

# --------------------------------------------------------------------------
# Derived meteorological variables
# --------------------------------------------------------------------------


def wind_10m_to_2m(ws10, z0=config.Z0_URBAN):
    """
    Logarithmic wind profile. ERA5-Land carries only 10 m wind, but human heat
    exposure is at ~2 m, where 10 m speeds overestimate convective cooling.

        u(2) = u(10) * ln(2/z0) / ln(10/z0)

    With z0 = 0.03 m this gives roughly 0.72 * u(10).
    """
    return ws10 * (np.log(2.0 / z0) / np.log(10.0 / z0))


def relative_humidity(t2m_k, d2m_k):
    """RH (%) from temperature and dewpoint via the Magnus formula."""
    t = t2m_k - config.KELVIN
    td = d2m_k - config.KELVIN
    a, b = 17.625, 243.04
    es = np.exp(a * t / (b + t))
    e = np.exp(a * td / (b + td))
    return np.clip(100.0 * e / es, 0.0, 100.0)


def wet_bulb_stull(t_c, rh):
    """
    Stull (2011) wet-bulb approximation -- fast and adequate as a first pass.

    For the paper's Lethal Heat Stress Index (Lsi) and the full WBGT, prefer
    ECMWF's `thermofeel` (github.com/ecmwf/thermofeel), which is the library the
    CHI dataset itself uses. Keeping both lets you cross-check your recomputation
    against published CHI fields.
    """
    return (t_c * np.arctan(0.151977 * np.sqrt(rh + 8.313659))
            + np.arctan(t_c + rh) - np.arctan(rh - 1.676331)
            + 0.00391838 * rh ** 1.5 * np.arctan(0.023101 * rh)
            - 4.686035)


def wbgt_outdoor_approx(t_c, tw_c, tg_c):
    """Standard outdoor WBGT weighting."""
    return 0.7 * tw_c + 0.2 * tg_c + 0.1 * t_c


# --------------------------------------------------------------------------
# ERA5 preparation
# --------------------------------------------------------------------------


def load_era5(paths):
    ds = xr.open_mfdataset(sorted(paths), combine="by_coords")
    # CDS sometimes names the time axis 'valid_time'.
    if "valid_time" in ds.dims:
        ds = ds.rename({"valid_time": "time"})
    ds = deaccumulate(ds)
    return ds


# ERA5 accumulated fields that must be de-accumulated before use.
ACCUMULATED = ["ssrd", "ssr", "strd", "str", "slhf", "sshf", "tp", "ssrdc"]


def deaccumulate(ds, dt_seconds=3600.0):
    """
    Convert ERA5/ERA5-Land ACCUMULATED fields to per-hour values.

    ERA5-Land accumulations run from 00 UTC and reset daily, so the stored value
    at a mid-afternoon step is the total since midnight -- NOT the flux over
    that hour. Dividing such a value by 3600 s overestimates the flux by a
    factor equal to the hours elapsed since the reset (up to ~24x).

    Symptom this fixes: ssrd max 2.78e7 J/m2 implies 7711 W/m2 if treated as
    hourly, i.e. 5.7x the solar constant. After differencing, peak flux over
    Makkah should be ~700-1100 W/m2 at solar noon.

    We difference along time and restore the raw value at the daily reset (where
    the difference would be negative, because the accumulator has restarted).
    """
    if "time" not in ds.dims:
        return ds
    for v in ACCUMULATED:
        if v not in ds:
            continue
        raw = ds[v]
        diff = raw.diff("time")
        # reindex so the first step keeps its own value (accumulation from 00 UTC)
        diff = diff.reindex(time=raw.time)
        diff = diff.fillna(raw)
        # at the daily reset the difference goes negative: fall back to the raw
        # accumulation, which at that step IS the first hour of the new day
        ds[v] = diff.where(diff >= 0, raw)
        ds[v].attrs["deaccumulated"] = "per-step difference; J m-2 per hour"
    return ds


def add_derived(ds):
    """Attach 2 m wind, RH, sunlit radiation and an approximate WBGT."""
    ws10 = np.sqrt(ds["u10"] ** 2 + ds["v10"] ** 2)
    ds["ws10"] = ws10
    ds["ws2"] = wind_10m_to_2m(ws10)

    ds["rh"] = relative_humidity(ds["t2m"], ds["d2m"])
    t_c = ds["t2m"] - config.KELVIN
    ds["t2m_c"] = t_c
    ds["tw"] = wet_bulb_stull(t_c, ds["rh"])

    # Sunlit-fraction-corrected solar geometry (paper Eq. 2).
    lat2d, lon2d = xr.broadcast(ds["latitude"], ds["longitude"])
    times = pd.to_datetime(ds["time"].values)
    doy = np.array([t.dayofyear for t in times], dtype=float)
    hod = np.array([t.hour for t in times], dtype=float)

    mean_cos = np.empty((len(times), *lat2d.shape), dtype="float32")
    sun_frac = np.empty_like(mean_cos)
    for i in range(len(times)):
        mc, sf = solar.mean_cos_zenith_sunlit(
            lat2d.values, lon2d.values,
            np.full(lat2d.shape, doy[i]),
            np.full(lat2d.shape, hod[i]),
        )
        mean_cos[i], sun_frac[i] = mc, sf

    dims = ("time", "latitude", "longitude")
    ds["mean_cos_zenith"] = (dims, mean_cos)
    ds["sunlit_fraction"] = (dims, sun_frac)

    if "ssrd" in ds:
        ds["sw_sunlit"] = (dims, solar.direct_sunlit_radiation(
            ds["ssrd"].values, mean_cos, sun_frac).astype("float32"))

    # Crude globe temperature proxy; replace with thermofeel for the paper.
    if "sw_sunlit" in ds:
        ds["tg"] = t_c + 0.0125 * ds["sw_sunlit"]
        ds["wbgt"] = wbgt_outdoor_approx(t_c, ds["tw"], ds["tg"])

    return ds


# --------------------------------------------------------------------------
# ECOSTRESS handling
# --------------------------------------------------------------------------

# Tiled filenames look like:
# ECOv002_L2T_LSTE_<orbit>_<scene>_<tile>_<YYYYMMDDTHHMMSS>_<build>_<ver>_LST.tif
TIME_RE = re.compile(r"_(\d{8}T\d{6})_")


def granule_time(path: Path) -> pd.Timestamp:
    m = TIME_RE.search(path.name)
    if not m:
        raise ValueError(f"No timestamp in {path.name}")
    return pd.to_datetime(m.group(1), format="%Y%m%dT%H%M%S", utc=True)


def granule_key(path: Path) -> str:
    """Everything before the trailing _<LAYER>.tif -- groups layers per scene."""
    return path.name.rsplit("_", 1)[0]


def load_ecostress_scene(layer_paths: dict) -> xr.DataArray:
    """Open LST and apply QC / cloud / water masking. Returns LST in Celsius."""
    lst = rioxarray.open_rasterio(layer_paths["LST"], masked=True).squeeze()

    # ECOSTRESS L2T LST is stored in Kelvin with a 0.02 scale factor.
    scale = lst.attrs.get("scale_factor", 0.02)
    lst = lst * scale - config.KELVIN
    lst = lst.where((lst > -50) & (lst < 90))

    for mask_name, bad_value in (("cloud", 1), ("water", 1)):
        p = layer_paths.get(mask_name)
        if p:
            m = rioxarray.open_rasterio(p, masked=True).squeeze()
            lst = lst.where(m != bad_value)

    lst = crop_to_bbox(lst)
    return lst.rename("lst_fine")


def crop_to_bbox(da, bbox=None, min_coverage=0.70):
    """
    Clip a projected ECOSTRESS tile to config.BBOX.

    WHY THIS EXISTS. ECOSTRESS L2T tiles are ~1568 x 1568 px at 70 m, i.e. about
    110 km on a side, and are delivered on a UTM grid. config.BBOX (0.4 x 0.3
    degrees, roughly 40 x 33 km) was previously used only to SEARCH for granules;
    the pairs were written as full tiles. Two consequences followed:

      * every downstream sampler maps lat/lon to raster indices by linear
        interpolation over config.BBOX, so a full-tile raster was indexed as if
        it covered the study area -- an offset of tens of kilometres;
      * the downscaler trained on 512 px tiles drawn from anywhere in the 110 km
        raster, mostly desert, mountain and outlying urban terrain rather than
        the ritual corridor, which inflates the predicted heteroscedastic scale.

    Cropping here, before reproject_match, means the fine grid IS the corridor
    and every derived product inherits the correct extent.
    """
    if bbox is None:
        bbox = config.BBOX
    west, south, east, north = bbox

    if da.rio.crs is None:
        return da
    if da.rio.crs.to_epsg() == 4326:
        x0, y0, x1, y1 = west, south, east, north
    else:
        from rasterio.warp import transform_bounds
        x0, y0, x1, y1 = transform_bounds("EPSG:4326", da.rio.crs,
                                          west, south, east, north,
                                          densify_pts=21)

    xs, ys = da.x.values, da.y.values
    xsl = slice(min(x0, x1), max(x0, x1))
    # y may ascend or descend depending on the product
    ysl = (slice(max(y0, y1), min(y0, y1)) if ys[0] > ys[-1]
           else slice(min(y0, y1), max(y0, y1)))
    sub = da.sel(x=xsl, y=ysl)

    # Reject PARTIAL overlaps, not merely empty ones.
    #
    # A tile that clips only the eastern sliver of the box still "overlaps", and
    # an earlier version accepted it. That is worse than rejecting it: the pair
    # would be written with, say, 89 of the expected 353 columns, while every
    # downstream sampler maps lat/lon to raster indices ASSUMING the raster spans
    # config.BBOX. An 89-column scene spans a quarter of the box, so the mapping
    # is wrong by tens of kilometres -- the exact failure this crop was added to
    # remove. A mixed dataset also over-represents whichever corner the partial
    # tiles cover.
    #
    # We therefore require the crop to retain most of the expected extent.
    res_x = float(abs(xs[1] - xs[0])) if xs.size > 1 else 70.0
    res_y = float(abs(ys[1] - ys[0])) if ys.size > 1 else 70.0
    exp_x = max(1, int(round(abs(max(x0, x1) - min(x0, x1)) / res_x)))
    exp_y = max(1, int(round(abs(max(y0, y1) - min(y0, y1)) / res_y)))
    got_x, got_y = sub.sizes.get("x", 0), sub.sizes.get("y", 0)
    fx, fy = got_x / exp_x, got_y / exp_y

    if min(fx, fy) < min_coverage:
        raise ValueError(
            f"Crop to {bbox} retained {got_y} x {got_x} px of an expected "
            f"{exp_y} x {exp_x} ({100*min(fx, fy):.0f}% of the smaller axis, "
            f"below the {100*min_coverage:.0f}% floor). The tile covers only "
            "part of the study area; accepting it would produce a pair whose "
            "extent does not match config.BBOX.")
    return sub


# --------------------------------------------------------------------------
# Pairing
# --------------------------------------------------------------------------


def coarse_at_time(era5, when: pd.Timestamp):
    """Linear interpolation of the coarse stack to the overpass time."""
    return era5.interp(time=np.datetime64(when.tz_localize(None)))


def build_pair(era5, layer_paths: dict, predictors) -> xr.Dataset:
    fine = load_ecostress_scene(layer_paths)
    when = granule_time(Path(layer_paths["LST"]))

    coarse = coarse_at_time(era5, when)[predictors]
    coarse = coarse.rio.write_crs("EPSG:4326")
    coarse = coarse.rename({"longitude": "x", "latitude": "y"})

    # Upsample coarse predictors onto the 70 m ECOSTRESS grid.
    coarse_on_fine = coarse.rio.reproject_match(
        fine, resampling=Resampling.bilinear
    )

    out = coarse_on_fine.assign(lst_fine=fine)
    out.attrs["acquisition_time"] = when.isoformat()
    out.attrs["source"] = "ERA5-Land + ECOSTRESS ECO_L2T_LSTE v002"
    return out


def group_layers(raw_dir: Path) -> dict:
    """Group per-layer GeoTIFFs into scenes."""
    scenes: dict[str, dict] = {}
    for p in sorted(raw_dir.glob("*.tif")):
        key = granule_key(p)
        layer = p.stem.rsplit("_", 1)[-1]
        scenes.setdefault(key, {})[layer] = p
    return {k: v for k, v in scenes.items() if "LST" in v}


def main():
    era5_files = sorted(config.RAW_ERA5.glob("*.nc"))
    if not era5_files:
        raise SystemExit("No ERA5 files. Run download_era5land.py first.")

    era5 = add_derived(load_era5(era5_files))
    predictors = [v for v in
                  ["t2m_c", "rh", "ws2", "ws10", "tw", "tg", "wbgt",
                   "sw_sunlit", "mean_cos_zenith", "sunlit_fraction", "skt"]
                  if v in era5]
    print(f"Predictors: {predictors}")

    scenes = group_layers(config.RAW_ECO)
    print(f"Found {len(scenes)} ECOSTRESS scenes")

    written = 0
    for key, layers in scenes.items():
        try:
            pair = build_pair(era5, layers, predictors)
            valid = float(np.isfinite(pair["lst_fine"]).mean())
            if valid < 0.30:
                print(f"  [skip] {key}: only {valid:.0%} valid pixels")
                continue
            out = config.PAIRS / f"{key}_pair.nc"
            pair.to_netcdf(out)
            written += 1
            print(f"  [ok  ] {out.name} ({valid:.0%} valid)")
        except Exception as exc:
            print(f"  [fail] {key}: {exc}")

    print(f"\nWrote {written} training pairs to {config.PAIRS}")


if __name__ == "__main__":
    main()
