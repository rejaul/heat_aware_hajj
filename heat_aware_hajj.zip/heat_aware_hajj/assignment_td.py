"""
REFORMULATED assignment: time-expanded, hard-capacity, multi-cohort, equitable.

Why this replaces the Frank-Wolfe user-equilibrium version
----------------------------------------------------------
The earlier model had three coupled defects, all traceable to one choice --
a SOFT crush penalty inside a USER equilibrium:

  (1) saturation: demand could push density past jam, so "routing cannot fix
      congestion" was partly an artefact of allowing infeasible states;
  (2) convergence: near jam density v -> 0 makes the cost surface near-vertical,
      so the relative gap stalled at ~3e-2 and the theta frontier was
      non-monotone;
  (3) equity: a user equilibrium is selfish, so nothing stopped vulnerable
      cohorts from being funnelled into the same cool corridor.

This module fixes all three with a different formulation:

  * HARD CAPACITY per (edge, time slice), set at the crush-onset density. Density
    can never exceed rho_crit, so speed is bounded BELOW, the cost function stays
    well-conditioned, and infeasible demand is rejected rather than silently
    crushed.
  * TIME-EXPANDED network: node (i,t) per spatial node and time slice, plus
    waiting arcs. Departure time becomes a DECISION VARIABLE, not an input, so
    the schedule lever the authorities actually control is inside the model.
  * TIME-DEPENDENT field: the exceedance grid may vary per slice, capturing
    moving shade and diurnal heating.
  * SYSTEM-OPTIMAL min-cost flow (network simplex) instead of user equilibrium:
    solved EXACTLY, so there is no convergence gap to report at all.
  * LEXICOGRAPHIC multi-cohort assignment: the most vulnerable cohort is routed
    first on the full network, its dose is then fixed, and remaining cohorts are
    assigned on residual capacity. This is the equity mechanism the critique
    asked for -- protection by construction, not by hoping self-selection works.

Formulation
-----------
Minimise, per cohort c in priority order,

    sum_{(i,j),t}  cost^c_{ij,t} * x^c_{ij,t}

  s.t.  flow conservation on the time-expanded graph
        sum_c x^c_{ij,t} <= Q_{ij}          (hard capacity, per slice)
        departure only within the ritual window
        dose^c <= (1+eps) * dose^c_opt      (fixed after each lexicographic step)

with  cost^c_{ij,t} = t_ij + theta_c * E_{ij}(t) * t_ij   [seconds]

evaluated at the capacity density (conservative, flow-independent), which makes
each cohort's subproblem a LINEAR min-cost flow -- exactly solvable.

Complexity
----------
Time-expanded graph has V*T nodes and (E+V)*T arcs. Network simplex is
O(V' E' log(V' C)) with V'=VT, E'=(E+V)T. Per cohort, so total
O(|C| * VT * (E+V)T * log(...)). Polynomial, and no iterative gap.
"""
from __future__ import annotations

import math
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import networkx as nx

from routing_physics import PARAMS, speed_from_density

# cohort priority: most vulnerable FIRST (lexicographic protection)
COHORT_ORDER = ["unreg_75plus", "unreg_55_74", "reg_55_74", "reg_18_54"]
COHORT_THETA = {"unreg_75plus": 200.0, "unreg_55_74": 120.0,
                "reg_55_74": 60.0, "reg_18_54": 20.0}
COHORT_SHARE = {"unreg_75plus": 0.08, "unreg_55_74": 0.17,
                "reg_55_74": 0.30, "reg_18_54": 0.45}


# ---------------------------------------------------------------------------
# capacity from the fundamental diagram
# ---------------------------------------------------------------------------

def flow_maximising_density(p=PARAMS, n=4000):
    """
    The density rho* that MAXIMISES flow q = rho * v(rho).

    This -- not the crush-onset density -- is the correct capacity operating
    point. Past rho* the fundamental diagram is on its congested branch, where
    adding pedestrians REDUCES throughput. For the Weidmann parameters used here
    rho* ~ 1.75 ped/m^2 with v ~ 0.70 m/s and q ~ 1.23 ped/(m s), whereas the
    crush-onset density rho_c = 4.0 yields q ~ 0.63 -- barely half. Safety and
    throughput therefore point the same way, which is a useful result in itself.
    """
    r = np.linspace(0.05, p["rho_jam"], n)
    q = r * speed_from_density(r, p)
    i = int(np.argmax(q))
    return float(r[i]), float(speed_from_density(r[i], p)), float(q[i])


def edge_capacity(width_m, dt_s, p=PARAMS, rho_cap=None):
    """
    Max pedestrians that may enter an edge in one time slice without exceeding
    the crush-onset density.

        Q = rho_cap * v(rho_cap) * width * dt      [pedestrians per slice]

    Capping at rho_crit (not rho_jam) is deliberate: it keeps the operating
    point off the near-vertical part of the speed curve, which is what made the
    previous solver ill-conditioned.
    """
    if rho_cap is None:
        rho_cap, v, _ = flow_maximising_density(p)
    else:
        v = float(speed_from_density(rho_cap, p))
    return rho_cap * v * float(width_m) * float(dt_s)


# ---------------------------------------------------------------------------
# time-expanded graph
# ---------------------------------------------------------------------------

class TimeExpanded:
    """
    Build a time-expanded copy of the spatial graph.

    fields : list of 2-D exceedance grids, one per time slice (or a single grid
             reused for all slices).
    """

    def __init__(self, rg, n_slices, dt_s=900.0, p=PARAMS,
                 rho_cap=None, cost_scale=1.0,
                 speed_mode="loaded", load_factor=0.5):
        self.rg = rg
        self.T = int(n_slices)
        self.dt = float(dt_s)
        self.p = p
        if rho_cap is None:
            rho_cap, _, _ = flow_maximising_density(p)
        self.rho_cap = rho_cap
        self.cost_scale = cost_scale
        self.speed_mode = speed_mode      # "capacity" | "loaded" | "free"
        self.load_factor = load_factor    # fraction of rho* for "loaded"
        self.v_cap = float(speed_from_density(self.rho_cap, p))
        self.G = nx.DiGraph()
        self._built = False

    def build(self, E_by_slice=None, theta=0.0):
        """
        E_by_slice[t][edge_index] gives the exceedance for that edge at slice t.
        If None, the static rg.E is reused for every slice.
        """
        rg, T = self.rg, self.T
        G = nx.DiGraph()

        # Travel time.
        #
        # PREVIOUSLY this used the capacity speed v(rho*) = 0.70 m/s on EVERY
        # edge, whether it carried 800,000 pilgrims or none. That is the speed
        # at the flow-maximising density, i.e. a fully loaded corridor, and
        # applying it everywhere inflated the Mina->Arafat leg to 286 min for
        # 12 km. Pilgrims walk that leg in a few hours, not twelve.
        #
        # The hard-capacity formulation caps density at rho*, so the realised
        # density on an edge lies somewhere in [0, rho*] and the realised speed
        # in [v(rho*), v_free]. Using v(rho*) everywhere is therefore the
        # WORST-CASE bound, not an estimate.
        #
        # `speed_mode` selects the convention, and it must be stated in the
        # paper because it scales every reported travel time and dose:
        #   "capacity"  v(rho*) everywhere         -- conservative upper bound
        #   "free"      v_free everywhere          -- optimistic lower bound
        #   "loaded"    v at a nominal load factor -- a middle estimate
        lf = float(getattr(self, "load_factor", 1.0))
        if self.speed_mode == "free":
            v_used = self.p["v_free"]
        elif self.speed_mode == "loaded":
            v_used = float(speed_from_density(self.rho_cap * lf, self.p))
        else:
            v_used = self.v_cap
        self.v_used = max(v_used, self.p["v_min"])

        t_edge = rg.L / self.v_used
        n_slice = np.maximum(1, np.ceil(t_edge / self.dt).astype(int))
        caps = np.array([edge_capacity(w, self.dt, self.p, self.rho_cap)
                         for w in rg.W])

        for t in range(T):
            Et = rg.E if E_by_slice is None else E_by_slice[min(t, len(E_by_slice) - 1)]
            for k, (u, v) in enumerate(rg.edges):
                t2 = t + n_slice[k]
                if t2 >= T:
                    continue
                # generalized cost in seconds, integerised for network simplex
                c = t_edge[k] * (1.0 + theta * float(Et[k]))
                G.add_edge((u, t), (v, t2),
                           capacity=int(max(1, round(caps[k]))),
                           weight=int(max(1, round(c * self.cost_scale))),
                           kind="move", eidx=k, slice=t)
            # waiting arcs: staying put is free in time but costs exposure
            if t + 1 < T:
                for nd in rg.S.nodes():
                    G.add_edge((nd, t), (nd, t + 1), capacity=10 ** 9,
                               weight=int(max(1, round(self.dt * self.cost_scale * 0.25))),
                               kind="wait")
        self.G = G
        self.t_edge = t_edge
        self.n_slice = n_slice
        self.caps = caps
        self._built = True
        return self

    def min_slices_for(self, src, dst):
        """
        Minimum slices needed to reach dst from src at the capacity speed.
        Guards against the silent failure where the horizon is simply too short
        and every assignment reports INFEASIBLE for the wrong reason.
        """
        H = nx.DiGraph()
        for k, (u, v) in enumerate(self.rg.edges):
            H.add_edge(u, v, w=int(self.n_slice[k]))
        srcs = list(src) if isinstance(src, (list, tuple, set)) else [src]
        dsts = list(dst) if isinstance(dst, (list, tuple, set)) else [dst]
        best = None
        for a in srcs:
            for b in dsts:
                try:
                    d = nx.shortest_path_length(H, a, b, weight="w")
                except Exception:
                    continue
                best = d if best is None else min(best, d)
        return best

    def stats(self):
        return {"nodes": self.G.number_of_nodes(), "arcs": self.G.number_of_edges(),
                "slices": self.T, "dt_s": self.dt,
                "rho_cap": self.rho_cap, "v_cap": round(self.v_cap, 3),
                "speed_mode": self.speed_mode,
                "v_used": round(getattr(self, "v_used", self.v_cap), 3),
                "mean_capacity_per_slice": float(np.mean(self.caps))}


# ---------------------------------------------------------------------------
# lexicographic multi-cohort assignment
# ---------------------------------------------------------------------------

def assign_cohort(te, src, dst, n_people, depart_window, theta,
                  E_by_slice=None, residual=None):
    """
    Route one cohort by min-cost flow on the time-expanded graph.

    depart_window : (t_lo, t_hi) inclusive slice indices in which departure is
                    permitted (the authority-controlled dispatch window).
    residual      : dict {arc: remaining capacity} from previous cohorts.

    Returns (flow_dict, metrics) or (None, reason).
    """
    te.build(E_by_slice=E_by_slice, theta=theta)
    G = te.G.copy()

    # apply residual capacities left by higher-priority cohorts
    if residual:
        for a, cap in residual.items():
            if G.has_edge(*a):
                G[a[0]][a[1]]["capacity"] = int(max(0, cap))

    # Demand enters and leaves across a SET of access nodes, not one point.
    #
    # Injecting a whole leg through a single node makes the two or three edges
    # touching it cap the leg, whatever the rest of the network can carry. On
    # the real OSM extract this was decisive: Arafat snapped to a degree-1 node
    # on a 3 m footpath (13,230 ped/h against 810,000 demand), and every
    # saturated arc lay 92 m from it while aggregate capacity exceeded demand
    # ~1000-fold. Arafat is an open plain of several square kilometres, so a
    # single access point is not a model of anything real.
    #
    # `src` and `dst` may therefore be a node or an iterable of nodes.
    src_nodes = list(src) if isinstance(src, (list, tuple, set)) else [src]
    dst_nodes = list(dst) if isinstance(dst, (list, tuple, set)) else [dst]

    S, Tt = "__src__", "__dst__"
    G.add_node(S); G.add_node(Tt)
    t_lo, t_hi = depart_window
    added = 0
    for t in range(max(0, t_lo), min(te.T, t_hi + 1)):
        for sn in src_nodes:
            if (sn, t) in G:
                G.add_edge(S, (sn, t), capacity=10 ** 9, weight=0)
                added += 1
    if added == 0:
        return None, "no departure slice available"
    sinks = 0
    for t in range(te.T):
        for dn in dst_nodes:
            if (dn, t) in G:
                G.add_edge((dn, t), Tt, capacity=10 ** 9, weight=0)
                sinks += 1
    if sinks == 0:
        return None, "destination unreachable in horizon"

    n = int(round(n_people))
    G.nodes[S]["demand"] = -n
    G.nodes[Tt]["demand"] = n

    try:
        cost, flow = nx.network_simplex(G)
    except nx.NetworkXUnfeasible:
        return None, "INFEASIBLE: hard capacity cannot carry this demand in window"

    # ---- metrics ----
    move_ped_m = 0.0; dose = 0.0; ped_s = 0.0
    used, arr_hist = {}, {}
    for u in flow:
        for v, f in flow[u].items():
            if f <= 0 or u in (S,) or v in (Tt,):
                if v == Tt and f > 0:
                    kt = int(u[1])
                    arr_hist[kt] = arr_hist.get(kt, 0) + float(f)
                continue
            d = G[u][v]
            if d.get("kind") != "move":
                continue
            k = d["eidx"]; t = d["slice"]
            Et = te.rg.E if E_by_slice is None else E_by_slice[min(t, len(E_by_slice) - 1)]
            move_ped_m += f * te.rg.L[k]
            tt = te.t_edge[k]
            ped_s += f * tt
            dose += f * float(Et[k]) * tt
            used[(u, v)] = used.get((u, v), 0) + f

    dep_hist = {}
    for v, f in flow.get(S, {}).items():
        if f > 0:
            kt = int(v[1])
            dep_hist[kt] = dep_hist.get(kt, 0) + float(f)

    # utilisation against hard capacity, and WHICH arcs saturate.
    # The count alone hides the important structure: if only a handful of arcs
    # are full while aggregate network capacity is orders of magnitude larger
    # than demand, the binding constraint is a BOTTLENECK, not total throughput.
    util, sat = [], []
    for a in used:
        cap = max(G[a[0]][a[1]]["capacity"], 1)
        u = used[a] / cap
        util.append(u)
        if u > 0.999:
            (u0, t0), (v0, t1) = a
            sat.append({"u": str(u0), "v": str(v0), "slice": int(t0),
                        "flow": float(used[a]), "capacity": int(cap),
                        "eidx": int(G[a[0]][a[1]].get("eidx", -1))})
    sat.sort(key=lambda r: -r["flow"])
    return flow, {
        "n_people": n,
        "total_ped_km": move_ped_m / 1000.0,
        "mean_km": move_ped_m / 1000.0 / max(n, 1),
        "mean_minutes": ped_s / 60.0 / max(n, 1),
        "total_dose": dose,
        "mean_dose": dose / max(n, 1),
        "max_utilisation": float(max(util)) if util else 0.0,
        "arcs_at_capacity": int(sum(1 for u in util if u > 0.999)),
        "saturated_arcs": sat[:40],
        "saturated_nodes": sorted({r["u"] for r in sat} | {r["v"] for r in sat}),
        "depart_hist": {int(k): float(v) for k, v in sorted(dep_hist.items())},
        "arrive_hist": {int(k): float(v) for k, v in sorted(arr_hist.items())},
        "objective": int(cost),
    }


def lexicographic_assign(te, src, dst, total_people, depart_window,
                         E_by_slice=None, order=None, shares=None,
                         thetas=None, verbose=True):
    """
    Assign cohorts in vulnerability order on residual capacity.

    The most vulnerable cohort is routed FIRST on the full network, so it gets
    the best available (coolest, least congested) arcs; later cohorts take what
    remains. This is protection by construction.
    """
    order = order or COHORT_ORDER
    shares = shares or COHORT_SHARE
    thetas = thetas or COHORT_THETA

    residual = None
    out = {}
    for c in order:
        n_c = total_people * shares[c]
        flow, m = assign_cohort(te, src, dst, n_c, depart_window,
                                thetas[c], E_by_slice, residual)
        if flow is None:
            out[c] = {"status": m}
            if verbose:
                print(f"    {c:<14} {m}")
            continue
        out[c] = m
        if verbose:
            print(f"    {c:<14} n={m['n_people']:>7,}  "
                  f"{m['mean_km']:5.2f} km  {m['mean_minutes']:6.1f} min  "
                  f"mean dose {m['mean_dose']:8.1f}  "
                  f"max util {m['max_utilisation']:.2f}  "
                  f"arcs full {m['arcs_at_capacity']}")

        # subtract used capacity for the next (less vulnerable) cohort
        te.build(E_by_slice=E_by_slice, theta=thetas[c])
        residual = residual or {a: te.G[a[0]][a[1]]["capacity"] for a in te.G.edges()}
        for u in flow:
            for v, f in flow[u].items():
                if f > 0 and (u, v) in residual:
                    residual[(u, v)] = max(0, residual[(u, v)] - f)

    # equity diagnostics
    doses = [v["mean_dose"] for v in out.values() if "mean_dose" in v]
    if doses:
        out["_equity"] = {
            "max_mean_dose": float(max(doses)),
            "min_mean_dose": float(min(doses)),
            "spread": float(max(doses) - min(doses)),
            "ratio": float(max(doses) / max(min(doses), 1e-9)),
            "vulnerable_is_lowest": bool(
                out[order[0]].get("mean_dose", 9e18) <= min(doses) + 1e-6),
        }
    return out


# ---------------------------------------------------------------------------
# feasibility frontier: the departure-window lever
# ---------------------------------------------------------------------------

def window_sweep(te, src, dst, total_people, windows, E_by_slice=None,
                 theta=200.0):
    """
    Sweep the dispatch-window length. This is the lever the previous model could
    not use: with HARD capacity, too-short a window is INFEASIBLE rather than
    silently crushing, so the sweep produces the minimum feasible window --
    an operationally actionable number.
    """
    rows = []
    for w in windows:
        flow, m = assign_cohort(te, src, dst, total_people, (0, w - 1),
                               theta, E_by_slice)
        if flow is None:
            rows.append({"slices": w, "hours": w * te.dt / 3600.0,
                         "feasible": False, "reason": m})
        else:
            rows.append({"slices": w, "hours": w * te.dt / 3600.0,
                         "feasible": True,
                         "mean_km": m["mean_km"], "mean_min": m["mean_minutes"],
                         "mean_dose": m["mean_dose"],
                         "max_util": m["max_utilisation"]})
    return rows


if __name__ == "__main__":
    from routing_equilibrium import demo_graph, prepare_edges
    from routing_scalarized import RoutingGraph

    print("=" * 78)
    print("REFORMULATED ASSIGNMENT -- self-test on synthetic graph")
    print("=" * 78)

    G, bbox, nodes = demo_graph(n=14, seed=3)
    H = W = 64
    yy, xx = np.mgrid[0:H, 0:W] / H
    field = np.clip(.10 + .85 * np.exp(-((yy - .45) ** 2 + (xx - .60) ** 2) / .02), 0, 1)
    prepare_edges(G, field, bbox)
    rg = RoutingGraph(G)
    print(f"spatial graph: V={rg.S.number_of_nodes()} E={rg.m}")

    src, dst = nodes["Mina"], nodes["Arafat"]

    probe = TimeExpanded(rg, n_slices=4, dt_s=900.0); probe.build(theta=0.0)
    need = probe.min_slices_for(src, dst)
    print(f"minimum slices to traverse Mina->Arafat at capacity speed: {need}")
    T = int(need * 2 + 4) if need else 24
    te = TimeExpanded(rg, n_slices=T, dt_s=900.0)
    te.build(theta=0.0)
    print("time-expanded:", te.stats())
    N = 20000

    win_hi = max(2, T // 3)
    print(f"\nLexicographic multi-cohort assignment (N={N:,}, "
          f"dispatch window = slices 0-{win_hi}):")
    res = lexicographic_assign(te, src, dst, N, (0, win_hi))
    if "_equity" in res:
        e = res["_equity"]
        print(f"\n  equity: spread {e['spread']:.1f}, ratio {e['ratio']:.2f}, "
              f"most-vulnerable-lowest-dose = {e['vulnerable_is_lowest']}")

    print("\nDispatch-window feasibility sweep (the new control lever):")
    for r in window_sweep(te, src, dst, N, [1, 2, 4, 8, 12]):
        if r["feasible"]:
            print(f"  {r['slices']:>2} slices ({r['hours']:.1f} h): FEASIBLE  "
                  f"{r['mean_km']:5.2f} km  {r['mean_min']:6.1f} min  "
                  f"dose {r['mean_dose']:8.1f}  max util {r['max_util']:.2f}")
        else:
            print(f"  {r['slices']:>2} slices ({r['hours']:.1f} h): INFEASIBLE "
                  f"-- {r['reason']}")
    print("\nNote: infeasibility is now EXPLICIT. The old soft-penalty model")
    print("would have returned a 'solution' at crush density instead.")
