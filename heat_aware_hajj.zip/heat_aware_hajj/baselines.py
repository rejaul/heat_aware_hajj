"""
Statistical baselines for the extreme-field comparison.

Kriging predicts a conditional MEAN and (with a Gaussian interval) is doubly
wrong for extremes: wrong estimator and wrong (light-tailed) distribution. This
module replaces it with tail-suited statistical methods and DEMOTES kriging to
an explicit negative control.

1. GPDRegression       -- covariate-dependent Generalized Pareto tail (principled
                          EVT baseline; the classical mirror of neural EQRN).
2. QuantileRegression  -- direct conditional quantiles via pinball loss.
3. RegressionKriging   -- NEGATIVE CONTROL: mean regression, under-predicts tail.
   GradientBoostingQuantile -- tabular tail method + feature importance.

All share predict_quantiles(X, coords, quantiles) -> (N, Q).
"""
from __future__ import annotations

import numpy as np
from scipy import optimize
from scipy.stats import genpareto, norm

try:
    import xgboost as xgb
    _HAS_XGB = True
except ImportError:
    _HAS_XGB = False

from sklearn.linear_model import QuantileRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, WhiteKernel, ConstantKernel

try:
    from pygam import LinearGAM, s
    _HAS_PYGAM = True
except Exception:
    _HAS_PYGAM = False


# ===========================================================================
# 1. Covariate-dependent GPD regression  (principled EVT baseline)
# ===========================================================================


class GPDRegression:
    """
    Peaks-over-threshold with covariate-dependent GPD parameters.

        Y - u(x) | Y > u(x)  ~  GPD(sigma(x), xi(x)),
        log sigma(x) = x' b_sigma,   xi(x) = tanh(xi0 + x' b_xi) * xi_bound.

    u(x) is a covariate-following quantile anchor at level `threshold_tau`, so the
    tail sits on the covariate signal. Extreme quantiles are recovered
    analytically -> the model EXTRAPOLATES beyond observed data.
    """

    def __init__(self, threshold_tau=0.90, xi_bound=0.4, l2=1e-2):
        self.threshold_tau = threshold_tau
        self.xi_bound = xi_bound
        self.l2 = l2
        self.zeta_u = 1.0 - threshold_tau
        self.anchor_coef = None

    def _fit_anchor(self, X, y):
        try:
            qr = QuantileRegressor(quantile=self.threshold_tau, alpha=1e-3,
                                   solver="highs").fit(X, y)
            self.anchor_coef = (qr.coef_, qr.intercept_)
            return qr.predict(X)
        except Exception:
            A = np.column_stack([X, np.ones(len(X))])
            coef, *_ = np.linalg.lstsq(A, y, rcond=None)
            self.anchor_coef = coef
            return A @ coef

    def _anchor_predict(self, X):
        if isinstance(self.anchor_coef, tuple):
            coef, intc = self.anchor_coef
            return X @ coef + intc
        A = np.column_stack([X, np.ones(len(X))])
        return A @ self.anchor_coef

    def _nll(self, params, Xe, exc):
        # Xe includes a trailing ones-column (intercept). b_sig covers all p
        # columns (log-sigma link). For the shape, xi0 is a scalar intercept and
        # b_xi covers the (p-1) covariate columns only (NOT the ones-column), so
        # xi(x) = tanh(xi0 + Xcov . b_xi). This keeps dimensions consistent.
        p = Xe.shape[1]
        b_sig = params[:p]
        xi0 = params[p]
        b_xi = params[p + 1:]                     # length p-1
        Xcov = Xe[:, :-1]                          # drop ones-column for shape
        sigma = np.exp(np.clip(Xe @ b_sig, -4.0, 4.0))
        xi = self.xi_bound * np.tanh(xi0 + Xcov @ b_xi)
        z = exc / sigma
        arg = 1.0 + xi * z
        if np.any(arg <= 1e-9):
            return 1e12
        xi_safe = np.where(np.abs(xi) < 1e-6, 1e-6, xi)
        ll = -np.log(sigma) - (1.0 + 1.0 / xi_safe) * np.log(arg)
        ll = np.where(np.abs(xi) < 1e-6, -np.log(sigma) - z, ll)
        penalty = self.l2 * (np.sum(b_sig[:-1] ** 2) + np.sum(b_xi ** 2))
        return -np.sum(ll) + penalty

    def fit(self, X, y, coords=None):
        X = np.asarray(X, float); y = np.asarray(y, float)
        u = self._fit_anchor(X, y)
        exc_mask = y > u
        if exc_mask.sum() < max(20, X.shape[1] * 3):
            raise ValueError(f"Too few exceedances ({int(exc_mask.sum())}) for GPD regression")
        Xe = np.column_stack([X[exc_mask], np.ones(exc_mask.sum())])
        exc = (y[exc_mask] - u[exc_mask]).clip(min=1e-6)
        p = Xe.shape[1]
        # params: [b_sig (p)] + [xi0 (1)] + [b_xi (p-1)]
        x0 = np.concatenate([np.r_[np.zeros(p - 1), np.log(exc.mean())],
                             [0.0], np.zeros(p - 1)])
        res = optimize.minimize(self._nll, x0, args=(Xe, exc),
                                method="Nelder-Mead",
                                options={"maxiter": 8000, "xatol": 1e-7,
                                         "fatol": 1e-7})
        self.beta_sigma = res.x[:p]
        self.xi0 = res.x[p]
        self.beta_xi = res.x[p + 1:]              # length p-1
        self._converged = bool(res.success)
        return self

    def _params_at(self, X):
        Xe = np.column_stack([X, np.ones(len(X))])
        Xcov = Xe[:, :-1]
        sigma = np.exp(np.clip(Xe @ self.beta_sigma, -4, 4))
        xi = self.xi_bound * np.tanh(self.xi0 + Xcov @ self.beta_xi)
        return sigma, xi

    def predict_quantiles(self, X, coords=None, quantiles=(0.5, 0.9, 0.95, 0.99)):
        X = np.asarray(X, float)
        u = self._anchor_predict(X)              # the tau0-level anchor
        sigma, xi = self._params_at(X)
        cols = []
        for tau in quantiles:
            if tau <= 1.0 - self.zeta_u:
                # Below the threshold u(x): the GPD does not apply. Approximate
                # the sub-threshold quantile by scaling the anchor toward it,
                # keeping values monotone and <= u. (For a fully rigorous
                # sub-tail, fit a second low-quantile regression; this suffices
                # since the paper's interest is the TAIL, tau > 1 - zeta_u.)
                frac = tau / (1.0 - self.zeta_u)          # in (0, 1]
                cols.append(u - (1.0 - frac) * sigma)     # sits below u
            else:
                ratio = (1.0 - tau) / self.zeta_u
                small = np.abs(xi) < 1e-6
                xi_c = np.clip(xi, -0.4, 0.4)
                gpd = u + (sigma / np.where(small, 1e-6, xi_c)) * (ratio ** (-xi_c) - 1.0)
                expo = u - sigma * np.log(ratio)
                cols.append(np.where(small, expo, gpd))
        return np.sort(np.column_stack(cols), axis=1)

    def return_level(self, X, period):
        return self.predict_quantiles(X, quantiles=(1.0 - 1.0 / period,))[:, 0]


# ===========================================================================
# 2. Quantile regression  (direct-quantile statistical baseline)
# ===========================================================================


class QuantileRegression:
    def __init__(self, quantiles=(0.5, 0.9, 0.95, 0.99), boosted=False,
                 alpha=1e-3, n_estimators=300):
        self.quantiles = tuple(quantiles)
        self.boosted = boosted and _HAS_XGB
        self.alpha = alpha
        self.n_estimators = n_estimators
        self.models = {}

    def fit(self, X, y, coords=None):
        for tau in self.quantiles:
            if self.boosted:
                m = xgb.XGBRegressor(objective="reg:quantileerror",
                                     quantile_alpha=tau, n_estimators=self.n_estimators,
                                     max_depth=5, learning_rate=0.05,
                                     subsample=0.8, tree_method="hist")
            else:
                m = QuantileRegressor(quantile=tau, alpha=self.alpha, solver="highs")
            m.fit(X, y)
            self.models[tau] = m
        return self

    def predict_quantiles(self, X, coords=None, quantiles=None):
        quantiles = quantiles or self.quantiles
        cols = [self.models[t].predict(X) for t in quantiles]
        return np.sort(np.column_stack(cols), axis=1)


# ===========================================================================
# 3. Regression kriging  (NEGATIVE CONTROL)
# ===========================================================================


class RegressionKriging:
    """GAM mean + Matern GP residual. NEGATIVE CONTROL: under-predicts extremes."""

    def __init__(self, gp_subsample=1500, matern_nu=1.5, random_state=0):
        self.gp_subsample = gp_subsample
        self.matern_nu = matern_nu
        self.rng = np.random.default_rng(random_state)
        self.use_gam = _HAS_PYGAM

    def _fit_trend(self, X, y):
        if self.use_gam:
            try:
                terms = s(0)
                for j in range(1, X.shape[1]):
                    terms = terms + s(j)
                self.trend = LinearGAM(terms).fit(X, y)
                return self.trend.predict(X)
            except Exception:
                self.use_gam = False
        from sklearn.linear_model import Ridge
        from sklearn.preprocessing import StandardScaler
        self._scaler = StandardScaler().fit(X)
        self.trend = Ridge(alpha=1.0).fit(self._scaler.transform(X), y)
        return self.trend.predict(self._scaler.transform(X))

    def _trend_predict(self, X):
        if self.use_gam:
            return self.trend.predict(X)
        return self.trend.predict(self._scaler.transform(X))

    def fit(self, X, y, coords):
        trend_hat = self._fit_trend(X, y)
        resid = y - trend_hat
        n = len(y)
        idx = (self.rng.choice(n, self.gp_subsample, replace=False)
               if n > self.gp_subsample else np.arange(n))
        kernel = (ConstantKernel(1.0) * Matern(length_scale=10.0, nu=self.matern_nu)
                  + WhiteKernel(noise_level=1.0))
        self.gp = GaussianProcessRegressor(kernel=kernel, normalize_y=True,
                                           n_restarts_optimizer=1)
        self.gp.fit(coords[idx], resid[idx])
        return self

    def predict_quantiles(self, X, coords, quantiles=(0.5, 0.9, 0.95, 0.99)):
        trend_hat = self._trend_predict(X)
        rmean, rstd = self.gp.predict(coords, return_std=True)
        mean = trend_hat + rmean
        std = np.maximum(rstd, 1e-6)
        out = np.column_stack([mean + norm.ppf(q) * std for q in quantiles])
        return np.sort(out, axis=1)


# ===========================================================================
# Tabular tail method (retained)
# ===========================================================================


class GradientBoostingQuantile:
    def __init__(self, quantiles=(0.5, 0.9, 0.95, 0.99), n_estimators=400,
                 max_depth=5, learning_rate=0.05, subsample=0.8):
        if not _HAS_XGB:
            raise ImportError("xgboost not installed")
        self.quantiles = tuple(quantiles)
        self.params = dict(n_estimators=n_estimators, max_depth=max_depth,
                           learning_rate=learning_rate, subsample=subsample,
                           tree_method="hist")
        self.models = {}
        self.feature_names = None

    def fit(self, X, y, coords=None, feature_names=None):
        self.feature_names = feature_names
        for tau in self.quantiles:
            m = xgb.XGBRegressor(objective="reg:quantileerror",
                                 quantile_alpha=tau, **self.params)
            m.fit(X, y)
            self.models[tau] = m
        return self

    def predict_quantiles(self, X, coords=None, quantiles=None):
        quantiles = quantiles or self.quantiles
        cols = [self.models[t].predict(X) for t in quantiles]
        return np.sort(np.column_stack(cols), axis=1)

    def feature_importance(self):
        imp = np.zeros(len(self.feature_names or []))
        for t in self.quantiles:
            imp = imp + self.models[t].feature_importances_
        imp /= len(self.quantiles)
        names = self.feature_names or [f"f{i}" for i in range(len(imp))]
        order = np.argsort(imp)[::-1]
        return [(names[i], float(imp[i])) for i in order]


if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")
    rng = np.random.default_rng(0)
    from scipy.stats import t as tdist
    N, P = 5000, 5
    X = rng.standard_normal((N, P))
    coords = rng.uniform(0, 50, (N, 2))
    signal = 3 * X[:, 0] + 2 * np.sin(X[:, 1]) + 1.5 * X[:, 2]
    scale = np.exp(0.3 * X[:, 0])
    y = 30 + signal + genpareto.rvs(0.15, scale=scale, size=N, random_state=1)
    feats = ["lst", "dewpoint", "solar", "wind", "ndvi"]
    taus = (0.5, 0.9, 0.95, 0.99)

    print("=" * 60)
    print("1. GPDRegression (covariate-dependent GPD -- principled EVT)")
    print("=" * 60)
    gpd = GPDRegression(threshold_tau=0.90).fit(X, y)
    q = gpd.predict_quantiles(X[:5], quantiles=taus)
    print("converged:", gpd._converged, "| xi0:", round(float(gpd.xi0), 3))
    print("row0 quantiles:", np.round(q[0], 2), "monotone:",
          bool((np.diff(q[0]) >= -1e-6).all()))
    for T in (10, 100, 1000):
        print(f"  {T:4d}-event return level: {gpd.return_level(X[:1], T)[0]:.2f}")
    print("  -> extrapolates to 1000-event level (pure QR cannot)")

    print("\n2. QuantileRegression")
    qr = QuantileRegression(quantiles=taus).fit(X, y)
    q = qr.predict_quantiles(X[:5])
    print("row0 quantiles:", np.round(q[0], 2))

    print("\n3. RegressionKriging (NEGATIVE CONTROL)")
    rk = RegressionKriging(gp_subsample=800).fit(X, y, coords)
    q = rk.predict_quantiles(X[:5], coords[:5])
    print("row0 quantiles:", np.round(q[0], 2))
    print("\nCommon predict_quantiles interface across all three. OK.")
