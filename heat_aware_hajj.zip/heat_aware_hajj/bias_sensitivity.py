"""
Sensitivity check: does correcting the measured ERA5 cold bias change anything?

MEASURED BIAS. Against the Mecca station (GHCN-Daily SAM00041030) over 540
overlapping summer days, 2013-2018, ERA5-Land daily maximum 2 m temperature is
3.51 C too cold overall and 4.14 C too cold on the hottest decile, with the
bias stable year to year (-3.14 to -3.77) and correlation 0.844 falling to 0.553
in the tail. This independently reproduces the underestimate reported for the
2024 Hajj period by Zittis et al. (npj Natural Hazards 2, 107, 2025).

WHY A SENSITIVITY CHECK RATHER THAN A REBUILD. Ten of eleven predictors derive
from ERA5-Land, so the bias propagates into every derived heat index. But the
model's TARGET is observed ECOSTRESS LST, not a modelled field, and a
near-uniform offset in a predictor is largely absorbable by the network. More
importantly, none of the reported conclusions obviously depend on it:

  * rho* comes from the pedestrian fundamental diagram and uses no temperature;
  * the routing negative concerns spread BETWEEN paths within a scene, and a
    uniform offset shifts every path equally;
  * the conformal finiteness result is arithmetic in calibration sample size.

Rather than assert that, we measure it. This script applies the correction to
the exported field and reports what changes, so the paper can state the
sensitivity instead of assuming it away.

Run (after export_field.py):
    python bias_sensitivity.py
    python bias_sensitivity.py --bias -4.14        # tail-specific correction
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", default="field_prob.npy")
    ap.add_argument("--meta", default="field_export_meta.json")
    ap.add_argument("--bias", type=float, default=-3.51,
                    help="measured ERA5 bias in C (negative = ERA5 too cold)")
    ap.add_argument("--tail-bias", type=float, default=-4.14,
                    help="measured bias on the hottest decile")
    ap.add_argument("--scores", default="residual_scores_calib.json")
    ap.add_argument("--bbox")
    args = ap.parse_args()

    P = np.load(args.risk)
    meta = json.load(open(args.meta)) if Path(args.meta).exists() else {}
    k = float(meta.get("threshold_k_C", 39.53))

    print("=" * 74)
    print("ERA5 BIAS SENSITIVITY")
    print("=" * 74)
    print(f"  field {args.risk}: {P.shape}, range "
          f"[{P.min():.3f}, {P.max():.3f}], sd {P.std():.3f}")
    print(f"  threshold k = {k:.2f} C")
    print(f"  measured bias: {args.bias:+.2f} C overall, "
          f"{args.tail_bias:+.2f} C in the tail")

    # ---- 1. effect on the exceedance field --------------------------------
    #
    # Correcting a COLD bias means the true temperature is higher than modelled,
    # so the exceedance probability rises. We approximate the correction as a
    # shift of the threshold in the opposite direction, which is equivalent for
    # a monotone predictive distribution and avoids re-running the network:
    #     P(T + b > k)  ==  P(T > k - b)
    # We recover the standardised distance implied by the exported field, shift
    # it, and re-read the probability from the same reference distribution.
    from scipy.special import erf, erfinv

    z = np.sqrt(2.0) * erfinv(1.0 - 2.0 * np.clip(P, 1e-6, 1 - 1e-6))  # P = 0.5*(1-erf(z/rt2))
    # sigma implied by the export (median predicted scale, C)
    sigma = float(meta.get("sigma_median_C", 2.36))
    print(f"  implied sigma: {sigma:.2f} C  "
          f"(z range {z.min():+.2f} .. {z.max():+.2f})")

    out = {"field": args.risk, "k": k, "sigma": sigma,
           "base": {"min": float(P.min()), "max": float(P.max()),
                    "mean": float(P.mean()), "sd": float(P.std())}}

    print(f"\n  {'correction':>14}{'P range':>22}{'mean':>9}{'sd':>9}"
          f"{'frac>0.5':>10}")
    print("  " + "-" * 64)
    print(f"  {'none (base)':>14}{P.min():>10.3f}-{P.max():<11.3f}"
          f"{P.mean():>9.3f}{P.std():>9.3f}{float((P>0.5).mean()):>10.3f}")

    for label, b in (("overall", args.bias), ("tail", args.tail_bias)):
        zc = z + b / max(sigma, 1e-6)          # cold bias -> z decreases -> P rises
        Pc = np.clip(0.5 * (1.0 - erf(zc / np.sqrt(2.0))), 0.0, 1.0)
        print(f"  {label+f' ({b:+.2f} C)':>14}{Pc.min():>10.3f}-{Pc.max():<11.3f}"
              f"{Pc.mean():>9.3f}{Pc.std():>9.3f}{float((Pc>0.5).mean()):>10.3f}")
        out[label] = {"bias_C": b, "min": float(Pc.min()), "max": float(Pc.max()),
                      "mean": float(Pc.mean()), "sd": float(Pc.std()),
                      "d_mean": float(Pc.mean() - P.mean()),
                      "d_sd": float(Pc.std() - P.std())}
        np.save(f"field_prob_corrected_{label}.npy", Pc.astype("float32"))

    # ---- 2. the quantity that actually matters for routing ----------------
    print("\n  WHAT THIS DOES TO THE ROUTING CONCLUSION")
    print("  Route choice depends on the spread of exposure BETWEEN paths, not")
    print("  on its level. A correction that shifts every cell by a similar")
    print("  amount cannot create heterogeneity where there was none.")
    for label in ("overall", "tail"):
        d = out[label]
        rel = d["d_sd"] / max(out["base"]["sd"], 1e-9)
        print(f"    {label:<8} mean shifts {d['d_mean']:+.3f}, "
              f"spatial sd changes {d['d_sd']:+.4f} ({100*rel:+.1f}%)")
    print("\n  The measured route-diversity spread is 0.0002-0.0035 against a")
    print("  usability threshold of 0.02. For the correction to overturn the")
    print("  negative result it would need to increase between-path spread by")
    print("  roughly an order of magnitude, which a near-uniform shift cannot do.")

    # ---- 3. conclusions that do not involve the field at all --------------
    print("\n  CONCLUSIONS UNAFFECTED BY CONSTRUCTION")
    print("    rho* and the capacity result: derived from the pedestrian")
    print("      fundamental diagram; no temperature enters.")
    print("    conformal finiteness: split conformal fails for alpha < 1/(n+1),")
    print("      which is arithmetic in calibration sample size.")

    json.dump(out, open("bias_sensitivity.json", "w"), indent=2)
    print("\n  corrected fields -> field_prob_corrected_{overall,tail}.npy")
    print("  results          -> bias_sensitivity.json")
    print("\n  NEXT: re-run route_diversity.py on a corrected field to confirm")
    print("  the spread is unchanged:")
    print("    python route_diversity.py --risk field_prob_corrected_tail.npy")


if __name__ == "__main__":
    main()
