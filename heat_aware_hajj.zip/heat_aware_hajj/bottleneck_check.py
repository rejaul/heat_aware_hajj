"""
Diagnose WHY the assignment is infeasible: real bottleneck, or snap artefact?

The picture so far:
  * aggregate network capacity is ~817 million ped/h against a demand of 810k,
    a factor of ~1000 in surplus, so total throughput is NOT the constraint;
  * yet only 9-21 arcs out of 19,508 saturate, and the assignment fails.

A handful of saturated arcs amid vast unused capacity means a BOTTLENECK. There
are two very different explanations, and they call for different responses:

  REAL bottleneck    -- a genuinely narrow segment every path must cross (the
                        Jamarat Bridge is the documented example). Reportable
                        as a finding.
  SNAP ARTEFACT      -- all demand is injected at ONE node per site, so every
                        pilgrim must leave through the two or three edges that
                        touch it. Real pilgrims enter Muzdalifah across a wide
                        front, not through a single lamppost. This is a
                        modelling artefact and must be fixed, not reported.

This script distinguishes them by asking how far each saturated arc sits from
the snapped site nodes, and how many distinct edges are incident on those nodes.

Run (after validate_real_network.py has written its JSON):
    python bottleneck_check.py
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import json
import math
import warnings

warnings.filterwarnings("ignore")

import networkx as nx

R_EARTH = 6371000.0


def gc_m(la1, lo1, la2, lo2):
    p1, p2 = math.radians(la1), math.radians(la2)
    dp, dl = p2 - p1, math.radians(lo2 - lo1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R_EARTH * math.asin(min(1.0, math.sqrt(a)))


def main():
    from corridor_network import fetch, snap_sites

    G = fetch()
    snapped = snap_sites(G)
    site_node = {k: str(v["node"]) for k, v in snapped.items()}
    pos = {str(n): (d["y"], d["x"]) for n, d in G.nodes(data=True)}

    print("=" * 74)
    print("BOTTLENECK DIAGNOSIS")
    print("=" * 74)

    # --- how constrained is each site node itself? ---
    print("\n1. degree of each snapped site node (the injection point)")
    und = G.to_undirected()
    for nm, nid in site_node.items():
        try:
            deg = und.degree(int(nid)) if int(nid) in und else und.degree(nid)
        except Exception:
            deg = und.degree(nid)
        w_in = 0.0
        for a, b, d in und.edges(nid if nid in und else int(nid), data=True):
            tag = d.get("highway", "unclassified")
            if isinstance(tag, list):
                tag = tag[0]
            w_in += {"pedestrian": 20, "footway": 6, "path": 4, "steps": 3,
                     "primary": 20, "secondary": 15, "tertiary": 12,
                     "residential": 8, "service": 6, "track": 5,
                     "living_street": 8, "primary_link": 20}.get(str(tag), 8.0)
        cap_h = 1.225 * w_in * 3600
        print(f"   {nm:<11} node {nid:<12} degree {deg:>2}   "
              f"incident width {w_in:5.1f} m   -> max {cap_h:>12,.0f} ped/h")
        if cap_h < 200000:
            print(f"                {'':<12} ^ this alone caps the leg; all demand "
                  f"must pass through it")

    # --- where are the saturated arcs? ---
    try:
        res = json.load(open("real_network_validation.json"))
    except FileNotFoundError:
        print("\n2. no real_network_validation.json -- re-run "
              "validate_real_network.py with the updated assignment_td.py "
              "to record saturated arcs.")
        return

    print("\n2. saturated arcs, and their distance from the injection points")
    any_sat = False
    for coh, v in res.get("assignment", {}).items():
        if not isinstance(v, dict):
            continue
        sat = v.get("saturated_arcs")
        if not sat:
            continue
        any_sat = True
        print(f"\n   cohort {coh}  ({v.get('arcs_at_capacity')} arcs at capacity)")
        near, far = 0, 0
        for r in sat[:12]:
            u, w = r["u"], r["v"]
            best_site, best_d = None, 1e18
            for nm, nid in site_node.items():
                if nid not in pos or u not in pos:
                    continue
                d0 = gc_m(*pos[u], *pos[nid])
                if d0 < best_d:
                    best_d, best_site = d0, nm
            tag = "NEAR site" if best_d < 300 else "away"
            near += best_d < 300
            far += best_d >= 300
            print(f"     slice {r['slice']:>3}  flow {r['flow']:>9,.0f} / "
                  f"cap {r['capacity']:>8,}  {best_d:>7.0f} m from "
                  f"{best_site:<11} [{tag}]")
        print(f"     -> {near} near a site node, {far} elsewhere")

    if not any_sat:
        print("   (no saturated_arcs recorded -- update assignment_td.py and "
              "re-run validate_real_network.py)")
        return

    print("\n" + "=" * 74)
    print("READING THIS")
    print("=" * 74)
    print("  Mostly NEAR site nodes  -> SNAP ARTEFACT. All demand is injected at")
    print("    one node per site, so the two or three edges touching it cap the")
    print("    whole leg. Fix by distributing demand over several nodes within a")
    print("    radius of each site, then re-run. Do NOT report the infeasibility.")
    print("  Mostly ELSEWHERE        -> a genuine interior bottleneck. Report it,")
    print("    identify the segments, and relate them to the documented Jamarat")
    print("    constriction.")


if __name__ == "__main__":
    main()
