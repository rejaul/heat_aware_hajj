"""
Characterise the diurnal cycle in the ECOSTRESS scenes, and cut a homogeneous
subset for training / calibration.

WHY. The pooled tail-diagnostic histogram looked bimodal, but plotting q95 LST
against overpass hour shows it is not two clusters -- it is a smooth DIURNAL
CYCLE. ECOSTRESS flies on the ISS, whose precessing orbit drifts acquisitions
through the whole day, so the 207 scenes sample local times from pre-dawn to
mid-afternoon and LST sweeps roughly 27-65 C as a result.

Consequences, and they are not cosmetic:

  * The scenes are NOT exchangeable. A 03:00-local scene and a 13:00-local scene
    are draws from different conditional distributions, which breaks the
    assumption underlying both the tail diagnostics and conformal calibration.
  * A "stable upper endpoint" fitted to the pooled sample may be nothing more
    than the top of the diurnal cycle -- the hottest the surface gets at solar
    noon -- rather than a property of the tail.
  * Conversely the cycle is strong, smooth SIGNAL, and solar.py already supplies
    the covariates (mean_cos_zenith, sunlit_fraction) needed to model it.

This script therefore does four things:
  1. converts acquisition times to local solar hour;
  2. fits the diurnal cycle and reports how much variance time-of-day explains;
  3. tests whether a chosen window is homogeneous (residual spread, drift);
  4. writes the restricted scene list for downstream use.

Run:
    python check_overpass.py                      # characterise, suggest window
    python check_overpass.py --window 10 15       # cut 10:00-15:00 local
    python check_overpass.py --stat q99 --window 9 16
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import glob
import re
import warnings

warnings.filterwarnings("ignore")

import numpy as np

try:
    import xarray as xr
except ImportError:
    raise SystemExit("xarray not installed. pip install xarray netCDF4")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TS = re.compile(r"(\d{8})T(\d{6})")
UTC_OFFSET_H = 3.0          # Makkah = UTC+3 (no DST)


# ---------------------------------------------------------------------------
def load_scenes(pairs, target, stat):
    """Return per-scene (file, date, local_hour, statistic)."""
    out = []
    for f in sorted(glob.glob(f"{pairs}/*_pair.nc")):
        m = TS.search(f)
        if not m:
            continue
        tm = m.group(2)
        utc_h = int(tm[:2]) + int(tm[2:4]) / 60.0 + int(tm[4:6]) / 3600.0
        loc_h = (utc_h + UTC_OFFSET_H) % 24.0
        with xr.open_dataset(f) as ds:
            if target not in ds:
                continue
            a = ds[target].values.astype("float32")
            a = a[np.isfinite(a)]
            if a.size == 0:
                continue
            v = {"q95": np.percentile(a, 95), "q99": np.percentile(a, 99),
                 "max": a.max(), "mean": a.mean()}[stat]
        out.append((f, m.group(1), loc_h, float(v)))
    return out


def harmonic_fit(hours, values, n_harm=2):
    """
    Least-squares fit of a periodic diurnal cycle:
        v(h) = a0 + sum_k [ a_k cos(2 pi k h/24) + b_k sin(2 pi k h/24) ]
    Returns (predict_fn, r2, design_rank).
    """
    h = np.asarray(hours, float)
    cols = [np.ones_like(h)]
    for k in range(1, n_harm + 1):
        cols += [np.cos(2 * np.pi * k * h / 24.0), np.sin(2 * np.pi * k * h / 24.0)]
    X = np.column_stack(cols)
    beta, *_ = np.linalg.lstsq(X, values, rcond=None)
    fitted = X @ beta
    ss_res = float(np.sum((values - fitted) ** 2))
    ss_tot = float(np.sum((values - values.mean()) ** 2))
    r2 = 1.0 - ss_res / max(ss_tot, 1e-12)

    def predict(hq):
        hq = np.atleast_1d(np.asarray(hq, float))
        c = [np.ones_like(hq)]
        for k in range(1, n_harm + 1):
            c += [np.cos(2 * np.pi * k * hq / 24.0),
                  np.sin(2 * np.pi * k * hq / 24.0)]
        return np.column_stack(c) @ beta

    return predict, r2, np.linalg.matrix_rank(X)


def suggest_window(hours, values, predict, width=5.0, step=0.5):
    """Slide a window and score it on (scene count) vs (within-window drift)."""
    best, rows = None, []
    for lo in np.arange(0, 24 - width + 1e-9, step):
        hi = lo + width
        sel = (hours >= lo) & (hours <= hi)
        n = int(sel.sum())
        if n < 20:
            continue
        drift = float(predict(hi)[0] - predict(lo)[0])       # modelled sweep
        sd = float(values[sel].std())
        rows.append({"lo": float(lo), "hi": float(hi), "n": n,
                     "drift_C": abs(drift), "sd_C": sd})
        score = n / (1.0 + abs(drift))                       # many scenes, low drift
        if best is None or score > best[0]:
            best = (score, rows[-1])
    return (best[1] if best else None), rows


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", default="data/pairs")
    ap.add_argument("--target", default="lst_fine")
    ap.add_argument("--stat", default="q95", choices=["q95", "q99", "max", "mean"])
    ap.add_argument("--window", nargs=2, type=float, metavar=("LO", "HI"),
                    help="local-hour window to cut, e.g. --window 10 15")
    ap.add_argument("--width", type=float, default=5.0,
                    help="width used when suggesting a window")
    ap.add_argument("--out", default="scenes_window.txt")
    args = ap.parse_args()

    rows = load_scenes(args.pairs, args.target, args.stat)
    if not rows:
        raise SystemExit(f"No usable pairs in {args.pairs}")
    files = np.array([r[0] for r in rows])
    dates = np.array([r[1] for r in rows])
    hours = np.array([r[2] for r in rows])
    vals = np.array([r[3] for r in rows])
    n = len(vals)

    print("=" * 72)
    print(f"DIURNAL CHARACTERISATION   n = {n} scenes, statistic = {args.stat}")
    print("=" * 72)
    print(f"  local hour  : {hours.min():5.2f} .. {hours.max():5.2f}  "
          f"(UTC+{UTC_OFFSET_H:.0f})")
    print(f"  {args.stat:<11}: {vals.min():6.2f} .. {vals.max():6.2f} C   "
          f"sd {vals.std():5.2f}")
    print(f"  distinct dates: {len(set(dates))}")

    # 1. how much variance is just time of day?
    predict, r2, rank = harmonic_fit(hours, vals, n_harm=2)
    resid = vals - predict(hours)
    print(f"\n  diurnal harmonic fit (2 harmonics): R^2 = {r2:.3f}")
    print(f"    residual sd after removing the cycle: {resid.std():.2f} C "
          f"(was {vals.std():.2f} C)")
    if r2 > 0.7:
        print("    -> time of day explains most of the variance. The pooled")
        print("       sample is NOT exchangeable; do not calibrate on it as-is.")
    elif r2 > 0.3:
        print("    -> substantial diurnal structure; restrict or condition on it.")
    else:
        print("    -> weak diurnal structure; pooling may be defensible.")

    # peak of the fitted cycle
    grid = np.linspace(0, 24, 2000)
    pk = float(grid[int(np.argmax(predict(grid)))])
    print(f"    fitted peak at {pk:.2f} h local "
          f"({predict(pk)[0]:.1f} C); trough at "
          f"{float(grid[int(np.argmin(predict(grid)))]):.2f} h")

    # 2. hourly table
    print(f"\n  scenes by local hour:")
    for lo in range(0, 24, 2):
        sel = (hours >= lo) & (hours < lo + 2)
        if sel.sum():
            print(f"    {lo:02d}-{lo+2:02d}h  n={int(sel.sum()):3d}  "
                  f"{args.stat} {vals[sel].mean():6.2f} +/- {vals[sel].std():5.2f} C")

    # 3. window selection
    if args.window:
        lo, hi = args.window
    else:
        sug, _ = suggest_window(hours, vals, predict, width=args.width)
        if sug is None:
            raise SystemExit("No window of the requested width holds >=20 scenes.")
        lo, hi = sug["lo"], sug["hi"]
        print(f"\n  suggested {args.width:.0f}h window: {lo:.1f}-{hi:.1f} local "
              f"(n={sug['n']}, modelled drift {sug['drift_C']:.1f} C)")

    sel = (hours >= lo) & (hours <= hi)
    k = int(sel.sum())
    print(f"\n  WINDOW {lo:.1f}-{hi:.1f} local")
    print(f"    scenes kept   : {k} / {n} ({100*k/n:.0f}%)")
    print(f"    distinct dates: {len(set(dates[sel]))}")
    if k:
        print(f"    {args.stat:<11}: {vals[sel].min():6.2f} .. {vals[sel].max():6.2f} C   "
              f"sd {vals[sel].std():5.2f} C")
        rw = np.corrcoef(hours[sel], vals[sel])[0, 1] if k > 3 else np.nan
        print(f"    residual drift with hour inside the window: r = {rw:+.3f}")
        if abs(rw) < 0.3:
            print("    -> window is approximately homogeneous in time of day.")
        else:
            print("    -> still drifting; narrow the window or keep solar")
            print("       covariates in the model.")

    if k < 30:
        print(f"\n    [caution] only {k} scenes survive. A three-way date-disjoint")
        print("    split will be thin; report the counts and widen the window or")
        print("    the acquisition range if possible.")

    # 4. write the list
    if k:
        with open(args.out, "w") as fh:
            fh.write("\n".join(files[sel]))
        print(f"\n  scene list -> {args.out}")
        print("  Next: re-run the tail diagnostics on this homogeneous subset")
        print("  and see whether the bounded-tail result survives:")
        print(f"    python run_tail_check.py --reduce q95   # after restricting")

    # ---- figure ----
    fig, ax = plt.subplots(1, 3, figsize=(12.6, 3.4))
    ax[0].scatter(hours, vals, s=16, c=vals, cmap="inferno", zorder=3)
    gg = np.linspace(0, 24, 400)
    ax[0].plot(gg, predict(gg), "-", color="#1f4e79", lw=1.6,
               label=f"harmonic fit ($R^2$={r2:.2f})")
    ax[0].axvspan(lo, hi, color="#27ae60", alpha=.15, label=f"window {lo:.0f}-{hi:.0f}h")
    ax[0].set_xlabel("local solar hour"); ax[0].set_ylabel(f"{args.stat} LST (C)")
    ax[0].set_title("(a) diurnal cycle"); ax[0].legend(frameon=False, fontsize=7)
    ax[0].grid(alpha=.25); ax[0].set_xlim(0, 24)

    ax[1].hist(vals, bins=40, color="#95a5a6", label=f"all (n={n})")
    if k:
        ax[1].hist(vals[sel], bins=25, color="#c0392b", alpha=.85,
                   label=f"window (n={k})")
    ax[1].set_xlabel(f"{args.stat} LST (C)"); ax[1].set_ylabel("scenes")
    ax[1].set_title("(b) pooled vs restricted"); ax[1].legend(frameon=False, fontsize=7)
    ax[1].grid(alpha=.25, axis="y")

    ax[2].scatter(hours, resid, s=14, color="#8e44ad")
    ax[2].axhline(0, ls="--", color="k", lw=.8)
    ax[2].set_xlabel("local solar hour"); ax[2].set_ylabel("residual (C)")
    ax[2].set_title(f"(c) after removing cycle (sd {resid.std():.2f} C)")
    ax[2].grid(alpha=.25); ax[2].set_xlim(0, 24)

    fig.tight_layout()
    fig.savefig("overpass_check.png", dpi=140)
    print("  figure    -> overpass_check.png")


if __name__ == "__main__":
    main()
