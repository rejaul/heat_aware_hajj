"""
Model comparison harness -- the experimental core of the paper.

Runs FIVE downscaling methods on a shared train/test split and reports the
diagnostic table:

    Proposed : AMUN + quantile head (pinball)      -- tail-oriented, deep
    EQRN     : AMUN + GPD-tail head                 -- tail-oriented, deep
    U-Net    : AMUN + mean head (Gaussian NLL)      -- MEAN, deep  [shows the flaw]
    XGB-Q    : gradient boosting quantile           -- tail-oriented, tabular
    Kriging  : GAM mean + Matern GP residual        -- MEAN, classical

All deep models share the identical AMUN backbone, so differences are due to the
OBJECTIVE, not the architecture. The two mean methods are included precisely to
demonstrate the peak-under-prediction failure the paper is built around.

Two modes:
    python compare.py --demo         # fast synthetic scene, CPU, ~1-2 min
    python compare.py --pairs DIR    # real aligned .nc pairs from align.py
"""
from __future__ import annotations

import argparse
import time
import warnings

import numpy as np

warnings.filterwarnings("ignore")

TAUS = (0.05, 0.5, 0.9, 0.95, 0.99)


# ---------------------------------------------------------------------------
# Synthetic scene (spatial field with covariates and heavy-tailed extremes)
# ---------------------------------------------------------------------------


def make_scene(n=96, seed=0):
    """
    Build a coarse->fine downscaling problem with a known heavy-tailed field.
    Returns per-pixel covariates X, coords, and target y, split train/test.
    """
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:n, 0:n] / n

    # covariates (stand-ins for LST, dewpoint, solar, wind, ndvi, elevation)
    # Hot spot centred at (0.72, 0.72) so it falls INSIDE the held-out test block
    # (>0.6, >0.6) -- otherwise the test region has no extremes to evaluate.
    lst = 30 + 9 * np.exp(-((yy - .72) ** 2 + (xx - .72) ** 2) / .03) \
        + 4 * np.exp(-((yy - .3) ** 2 + (xx - .35) ** 2) / .05)
    dew = 8 + 3 * xx + rng.normal(0, .3, (n, n))
    solar = 700 + 200 * np.cos(2 * np.pi * (xx - .5))
    wind = 1.5 + 0.5 * yy
    ndvi = 0.1 + 0.3 * np.exp(-((yy - .5) ** 2 + (xx - .5) ** 2) / .1)
    elev = 250 + 40 * yy

    # true fine heat field: nonlinear in covariates + heavy-tailed extremes
    from scipy.stats import genpareto
    base = 0.6 * lst + 0.4 * dew + 0.01 * solar - 0.8 * wind - 5 * ndvi
    base = (base - base.mean()) / base.std() * 4 + 34
    # inject spatially-clustered extreme excesses (GPD tail) at the test-block hot spot
    hot = np.exp(-((yy - .72) ** 2 + (xx - .72) ** 2) / .02)
    excess = genpareto.rvs(0.15, size=(n, n), random_state=seed) * hot * 1.4
    y = base + excess + rng.normal(0, 0.5, (n, n))

    X = np.stack([lst, dew, solar, wind, ndvi, elev], -1).reshape(-1, 6)
    coords = np.stack([yy, xx], -1).reshape(-1, 2) * n
    y = y.reshape(-1)
    feats = ["lst", "dewpoint", "solar", "wind", "ndvi", "elev"]

    # standardise covariates
    X = (X - X.mean(0)) / (X.std(0) + 1e-6)

    # spatial-block split: hold out a contiguous test region (avoids leakage)
    test_mask = (coords[:, 0] > 0.6 * n) & (coords[:, 1] > 0.6 * n)
    return dict(X=X, coords=coords, y=y, feats=feats,
                train=~test_mask, test=test_mask, shape=(n, n))


# ---------------------------------------------------------------------------
# Deep-model training on flattened pixels (fast, CPU-friendly for the demo)
# ---------------------------------------------------------------------------


def train_deep_pixelwise(kind, scene, taus=TAUS, epochs=300, seed=0):
    """
    Train a small MLP with the SAME head/loss logic as the AMUN variants, but
    pixel-wise, so the demo runs quickly on CPU without tiling. The architecture
    differs from the full conv AMUN; the OBJECTIVE (quantile / GPD / mean) is
    identical, which is what the comparison isolates.
    """
    import torch
    import torch.nn as nn

    torch.manual_seed(seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    Xtr = torch.tensor(scene["X"][scene["train"]], dtype=torch.float32, device=dev)
    ytr = torch.tensor(scene["y"][scene["train"]], dtype=torch.float32, device=dev)[:, None]
    Xte = torch.tensor(scene["X"][scene["test"]], dtype=torch.float32, device=dev)

    P = Xtr.shape[1]
    hidden = 128

    if kind == "quantile":
        out_dim = len(taus)
    elif kind == "eqrn":
        out_dim = 2                      # (log_sigma, xi)
    else:                                # mean
        out_dim = 2                      # (mu, log_sigma)

    net = nn.Sequential(
        nn.Linear(P, hidden), nn.SiLU(),
        nn.Linear(hidden, hidden), nn.SiLU(),
        nn.Linear(hidden, out_dim)).to(dev)

    # threshold for EQRN: high quantile of the training targets
    u = float(np.quantile(scene["y"][scene["train"]], 0.90))
    zeta_u = 0.10

    # EQRN is sensitive to target scale; standardise the target for its NLL so the
    # GPD scale starts near 1. Predictions are de-standardised at inference.
    y_mu = float(scene["y"][scene["train"]].mean())
    y_sd = float(scene["y"][scene["train"]].std() + 1e-6)
    u_std = (u - y_mu) / y_sd

    # Covariate-driven LOCATION anchor for EQRN: a per-pixel intermediate
    # threshold u(x) that follows the local heat level. Without this, the GPD
    # scale floats free and places extremes in low-signal (cool) regions -- a
    # real EQRN failure mode. We anchor u(x) to a quick linear fit of the field
    # so the tail sits on top of the covariate signal, like the residual trick
    # used by the other models.
    from numpy.linalg import lstsq
    Xtr_np = scene["X"][scene["train"]]
    ytr_np = scene["y"][scene["train"]]
    A = np.column_stack([Xtr_np, np.ones(len(Xtr_np))])
    coef, *_ = lstsq(A, ytr_np, rcond=None)
    anchor_tr = (A @ coef - y_mu) / y_sd                      # standardised
    Ate = np.column_stack([scene["X"][scene["test"]],
                           np.ones(scene["test"].sum())])
    anchor_te = (Ate @ coef - y_mu) / y_sd

    lr = 1e-3 if kind == "eqrn" else 3e-3
    opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=1e-4)

    for _ in range(epochs):
        opt.zero_grad()
        out = net(Xtr)
        if kind == "quantile":
            # monotone via cumulative softplus
            base = out[:, 0:1]
            incr = torch.nn.functional.softplus(out[:, 1:])
            qs = torch.cat([base, base + torch.cumsum(incr, 1)], 1)
            loss = 0.0
            for i, tau in enumerate(taus):
                d = ytr - qs[:, i:i + 1]
                loss = loss + torch.maximum(tau * d, (tau - 1) * d).mean()
        elif kind == "eqrn":
            # exceedances measured relative to a per-pixel anchor u(x), so the
            # tail follows the covariate signal instead of floating free.
            anchor_t = torch.tensor(anchor_tr, dtype=torch.float32,
                                    device=dev)[:, None]
            margin = 0.5                              # std units above anchor
            u_x = anchor_t + margin
            ytr_s = (ytr - y_mu) / y_sd
            exc_mask = (ytr_s > u_x).squeeze(1)
            if exc_mask.sum() < 10:
                loss = (out ** 2).mean() * 0.0 + 1.0
            else:
                out_e = out[exc_mask]
                exc_e = (ytr_s[exc_mask] - u_x[exc_mask]).clamp_min(1e-4)
                log_sigma = out_e[:, 0:1].clamp(-2.0, 2.0)
                xi = 0.3 * torch.tanh(out_e[:, 1:2])
                sigma = torch.exp(log_sigma)
                z = exc_e / sigma
                xi_c = xi.clamp(min=-0.3)
                arg = (1 + xi_c * z).clamp_min(1e-6)
                ll = -log_sigma - (1 + 1 / xi_c.clamp_min(1e-3)) * torch.log(arg)
                ll = torch.where(xi.abs() < 1e-3, -log_sigma - z, ll)
                loss = -ll.mean() + 0.05 * (log_sigma ** 2).mean()
        else:                            # mean, Gaussian NLL
            mu = out[:, 0:1]
            log_sigma = out[:, 1:2].clamp(-6, 4)
            inv_var = torch.exp(-2 * log_sigma)
            loss = (0.5 * inv_var * (mu - ytr) ** 2 + log_sigma).mean()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
        opt.step()

    net.eval()
    with torch.no_grad():
        out = net(Xte)
        if kind == "quantile":
            base = out[:, 0:1]
            incr = torch.nn.functional.softplus(out[:, 1:])
            qs = torch.cat([base, base + torch.cumsum(incr, 1)], 1)
            return qs.cpu().numpy(), None
        elif kind == "eqrn":
            log_sigma = out[:, 0:1].clamp(-2.0, 2.0)
            xi = 0.3 * torch.tanh(out[:, 1:2])
            sigma = torch.exp(log_sigma)
            anchor_e = torch.tensor(anchor_te, dtype=torch.float32,
                                    device=dev)[:, None]
            margin = 0.5
            u_x = anchor_e + margin
            tr_std = (scene["y"][scene["train"]] - y_mu) / y_sd
            y_max_s = float((scene["y"][scene["train"]].max() - y_mu) / y_sd)
            # exceedance rate above the per-pixel anchor (constant here)
            zeta = 1.0 - 0.90                        # ~P(Y > u(x))
            cols = []
            for tau in taus:
                if tau < (1.0 - zeta):               # below anchor: empirical shape
                    qv = float(np.quantile(tr_std, tau))
                    # shift empirical below-quantile to sit under the local anchor
                    q = u_x + (qv - float(np.quantile(tr_std, 1 - zeta)))
                else:                                # tail: anchor + GPD
                    ratio = torch.tensor((1 - tau) / zeta)
                    xi_c = xi.clamp(-0.3, 0.3)
                    gpd = (sigma / xi_c.clamp_min(1e-3)) * (ratio ** (-xi_c) - 1)
                    expo = -sigma * torch.log(ratio)
                    tail = torch.where(xi_c.abs() < 1e-3, expo, gpd)
                    q = (u_x + tail).clamp(max=y_max_s + 5.0)
                cols.append(q * y_sd + y_mu)
            qs = torch.cat(cols, 1)
            qs, _ = torch.sort(qs, dim=1)
            return qs.cpu().numpy(), None
        else:
            mu = out[:, 0:1].cpu().numpy().ravel()
            std = torch.exp(out[:, 1:2].clamp(-6, 4)).cpu().numpy().ravel()
            return mu, std


# ---------------------------------------------------------------------------
# Run all methods
# ---------------------------------------------------------------------------


def run(scene, epochs=300):
    from metrics import (evaluate_quantile_method,
                         evaluate_extremes)
    from baselines import GradientBoostingQuantile, RegressionKriging
    from scipy.stats import norm

    ytr, yte = scene["y"][scene["train"]], scene["y"][scene["test"]]
    thr = float(np.quantile(ytr, 0.95))       # danger threshold from train
    results, importance = {}, None

    def add(name, qmat):
        """Merge central metrics + extreme-value diagnostics for a quantile matrix."""
        m = evaluate_quantile_method(qmat, TAUS, yte, thr)
        m.update(evaluate_extremes(qmat, TAUS, yte, periods=(10, 100)))
        results[name] = m

    def mean_to_q(mean, std):
        return np.column_stack([mean + norm.ppf(t) * std for t in TAUS])

    # --- deep: proposed quantile AMUN ---
    t = time.time()
    q, _ = train_deep_pixelwise("quantile", scene, epochs=epochs)
    add("Proposed (quantile)", q)
    dt_q = time.time() - t

    # --- deep: EQRN ---
    q, _ = train_deep_pixelwise("eqrn", scene, epochs=epochs)
    add("EQRN (GPD head)", q)

    # --- deep: plain mean U-Net ---
    mu, std = train_deep_pixelwise("mean", scene, epochs=epochs)
    add("U-Net (mean)", mean_to_q(mu, std))

    # --- tabular: gradient boosting quantile ---
    gb = GradientBoostingQuantile(quantiles=TAUS, n_estimators=300).fit(
        scene["X"][scene["train"]], ytr, feature_names=scene["feats"])
    add("XGB-Quantile", gb.predict_quantiles(scene["X"][scene["test"]]))
    importance = gb.feature_importance()

    # --- statistical EVT: covariate-dependent GPD regression (principled) ---
    try:
        from baselines import GPDRegression
        gpd = GPDRegression(threshold_tau=0.90).fit(
            scene["X"][scene["train"]], ytr)
        add("GPD-Regression (EVT)", gpd.predict_quantiles(scene["X"][scene["test"]], quantiles=TAUS))
    except Exception as e:
        print(f"  [GPD-Regression skipped: {e}]")

    # --- statistical: direct quantile regression ---
    try:
        from baselines import QuantileRegression
        qr = QuantileRegression(quantiles=TAUS).fit(scene["X"][scene["train"]], ytr)
        add("Quantile-Regression", qr.predict_quantiles(scene["X"][scene["test"]], quantiles=TAUS))
    except Exception as e:
        print(f"  [Quantile-Regression skipped: {e}]")

    # --- NEGATIVE CONTROL: regression kriging (mean regression) ---
    from baselines import RegressionKriging
    rk = RegressionKriging(gp_subsample=1200).fit(
        scene["X"][scene["train"]], ytr, scene["coords"][scene["train"]])
    add("Kriging (neg. control)",
        rk.predict_quantiles(scene["X"][scene["test"]], scene["coords"][scene["test"]], TAUS))

    return results, importance, thr, dt_q


def print_table(results, importance, thr):
    # --- central / general table ---
    cols = ["RMSE", "peak_bias", "coverage", "exc_F1"]
    print("\n" + "=" * 92)
    print("TABLE 1: GENERAL PERFORMANCE")
    print(f"(danger threshold = {thr:.2f}; RMSE is CENTRAL accuracy, not tail)")
    print("=" * 92)
    print(f"{'Method':<22}" + "".join(f"{c:>14}" for c in cols))
    print("-" * 92)
    for name, m in results.items():
        row = f"{name:<22}"
        for c in cols:
            row += f"{m.get(c, float('nan')):>14.3f}"
        print(row)

    # --- extreme-value table ---
    ecols = ["RL10_err", "RL100_err", "tail_coverage", "cal_dev@0.99",
             "tail_pinball", "tail_corr", "tail_jaccard"]
    print("\n" + "=" * 118)
    print("TABLE 2: EXTREME-VALUE PREDICTION DIAGNOSTICS  <-- the ones that matter")
    print("(RLx_err: return-level error; tail_*: computed on the tail only;")
    print(" tail_corr/jaccard: are extremes predicted in the RIGHT places?)")
    print("=" * 118)
    print(f"{'Method':<22}" + "".join(f"{c:>13}" for c in ecols))
    print("-" * 118)
    for name, m in results.items():
        row = f"{name:<22}"
        for c in ecols:
            v = m.get(c, float('nan'))
            row += f"{v:>13.3f}"
        print(row)
    print("-" * 118)
    print("\nReading TABLE 2 (extreme-prediction capability):")
    print("  * RL10_err / RL100_err: accuracy of the 1-in-10 / 1-in-100 return")
    print("    level -- THE core EVT deliverable. Lower is better.")
    print("  * tail_coverage: interval coverage computed ONLY on true extremes;")
    print("    a method can pass whole-field coverage yet fail here.")
    print("  * tail_pinball: quantile loss over tau>=0.9 only (ignores the median).")
    print("  * tail_corr / tail_jaccard: do predicted extremes land where the true")
    print("    extremes are? This is the spatial check that catches a model")
    print("    predicting big values in the WRONG locations (corr near 0 or <0).")

    if importance:
        print("\nFeature importance (XGB-Quantile) -- a reportable result:")
        for name, val in importance:
            bar = "#" * int(val * 40)
            print(f"  {name:<10} {val:5.3f} {bar}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--size", type=int, default=96)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    print(f"Building synthetic scene ({args.size}x{args.size}) ...")
    scene = make_scene(n=args.size, seed=args.seed)
    ntr, nte = scene["train"].sum(), scene["test"].sum()
    print(f"train pixels {ntr} | test pixels {nte} (held-out spatial block)")

    results, importance, thr, dt = run(scene, epochs=args.epochs)
    print_table(results, importance, thr)
    print(f"\n(demo trains small pixel-wise MLPs with identical heads/losses to")
    print(f" the full AMUN variants; swap in the conv models on real .nc pairs.)")


if __name__ == "__main__":
    main()
