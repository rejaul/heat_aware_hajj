"""
Central configuration for the Hajj heat-stress data pipeline.

Edit this file only -- every other script reads from here.
"""
from pathlib import Path

# --------------------------------------------------------------------------
# Study area: the Makkah holy-sites corridor
# (Grand Mosque -> Mina -> Muzdalifah -> Arafat)
# --------------------------------------------------------------------------
# Bounding box as (west, south, east, north) in EPSG:4326 degrees.
BBOX = (39.70, 21.25, 40.10, 21.55)

# Named landmarks, useful for extracting point time series / sanity checks.
SITES = {
    "grand_mosque": (21.4225, 39.8262),   # (lat, lon)
    "mina":         (21.4133, 39.8933),
    "muzdalifah":   (21.3833, 39.9367),
    "arafat":       (21.3549, 39.9841),
}

# --------------------------------------------------------------------------
# Temporal scope
# --------------------------------------------------------------------------
# ==========================================================================
# CASE-STUDY / QUICK MODE  (for a preliminary submission under deadline)
# --------------------------------------------------------------------------
# Set QUICK = True to restrict the ENTIRE pipeline to a small, fast-to-download
# slice: the 2024 Hajj window (the 51.8 C extreme event) plus a buffer of
# surrounding weeks, over the same spatial box. This is the minimum viable
# dataset for a proof-of-concept / case-study submission. Switch to False and
# do the full multi-season pull for the camera-ready version.
#
# HONESTY NOTE: results from QUICK mode are a CASE STUDY on limited data. Label
# them as preliminary. Do NOT report return levels or coverage from this slice
# as if they were the full multi-season study -- there are too few scenes for
# those statistics to be meaningful. The method/pipeline is what you demonstrate
# here; the full evaluation is the camera-ready deliverable.
# ==========================================================================
QUICK = True

# The case-study window: buffer weeks around the 2024 Hajj to gather enough
# ECOSTRESS overpasses (Hajj days alone yield too few clear scenes).
QUICK_YEAR = 2024
QUICK_RANGE = ("2024-05-15", "2024-07-15")   # ~2 months bracketing the event
QUICK_MONTHS = [5, 6, 7]

# IMPORTANT: do not train only on Hajj days -- there are far too few clear-sky
# ECOSTRESS overpasses. Train on the full hot season across several years and
# treat the Hajj window as the evaluation period.
_FULL_TRAIN_YEARS = list(range(2019, 2025))   # ECOSTRESS science ops stabilised 2019
_FULL_TRAIN_MONTHS = [5, 6, 7, 8, 9]          # Makkah hot season

# Active scope: QUICK mode narrows to the case-study window.
if QUICK:
    TRAIN_YEARS = [QUICK_YEAR]
    TRAIN_MONTHS = QUICK_MONTHS
else:
    TRAIN_YEARS = _FULL_TRAIN_YEARS
    TRAIN_MONTHS = _FULL_TRAIN_MONTHS

# Hajj windows (Dhul-Hijjah 8-13) for evaluation. Verify these against an
# official Umm al-Qura calendar before using them in the paper.
HAJJ_WINDOWS = {
    2022: ("2022-07-07", "2022-07-12"),
    2023: ("2023-06-26", "2023-07-01"),
    2024: ("2024-06-14", "2024-06-19"),   # the 51.8 C extreme-heat event
    2025: ("2025-06-04", "2025-06-09"),
}

# --------------------------------------------------------------------------
# ERA5-Land variables (CDS naming)
# --------------------------------------------------------------------------
# NOTE: ERA5-Land supplies wind only at 10 m. The 2 m wind used in the paper is
# derived in align.py via the logarithmic wind profile.
ERA5_VARIABLES = [
    "2m_temperature",
    "2m_dewpoint_temperature",
    "10m_u_component_of_wind",
    "10m_v_component_of_wind",
    "surface_solar_radiation_downwards",
    "surface_net_solar_radiation",
    "surface_thermal_radiation_downwards",
    "skin_temperature",
]

# --------------------------------------------------------------------------
# ECOSTRESS product
# --------------------------------------------------------------------------
# Tiled L2 product: 70 m, projected, delivered as per-layer GeoTIFFs.
ECOSTRESS_SHORT_NAME = "ECO_L2T_LSTE"
ECOSTRESS_VERSION = "002"

# Layers to keep from each granule.
ECOSTRESS_LAYERS = ["LST", "LST_err", "QC", "cloud", "water", "view_zenith"]

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
RAW_ERA5 = DATA / "raw" / "era5land"
RAW_ECO = DATA / "raw" / "ecostress"
INTERIM = DATA / "interim"
PAIRS = DATA / "pairs"          # aligned coarse/fine training pairs

for _p in (RAW_ERA5, RAW_ECO, INTERIM, PAIRS):
    _p.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------
# Physical constants
# --------------------------------------------------------------------------
Z0_URBAN = 0.03      # roughness length (m) for the log wind profile
KELVIN = 273.15
