"""
Real pedestrian network for the Hajj ritual corridor, from OpenStreetMap.

Replaces the stylised/synthetic corridor with the ACTUAL walkable network around
Al-Masjid al-Haram, Mina, the Jamarat Bridge, Muzdalifah and Arafat, pulled from
OSM via osmnx and cached locally as GraphML.

This must run on a machine with internet access to the Overpass API (your PC).
The fetch is done ONCE and cached; everything downstream reads the cache.

Usage
-----
    python corridor_network.py                 # fetch + cache + report
    python corridor_network.py --refresh       # force re-fetch
    python corridor_network.py --network all   # if 'walk' is too sparse

Notes
-----
* OSM coverage of the holy sites is good for the engineered pedestrian ways
  (the Mashaer walkways, Jamarat approaches) but sparser over the open plains of
  Arafat and Muzdalifah, which have fewer mapped footways. If the 'walk' graph
  comes back fragmented, re-run with `--network all`, which includes service
  roads and tracks that pilgrims do use on foot.
* Coordinates below are well-known approximate centroids of the ritual sites.
  VERIFY them against an authoritative source before publishing; small offsets
  will change which OSM node each site snaps to.
"""
from __future__ import annotations

import argparse
import os
import sys

# Real ritual-site coordinates (lat, lon). Verify before publication.
SITES = {
    "Haram":       (21.4225, 39.8262),   # Al-Masjid al-Haram
    "Jamarat":     (21.4222, 39.8728),   # Jamarat Bridge (Mina) -- known bottleneck
    "Mina":        (21.4133, 39.8933),   # Mina tent city (centroid)
    "Muzdalifah":  (21.3833, 39.9333),   # Muzdalifah plain
    "Arafat":      (21.3547, 39.9843),   # Jabal al-Rahmah / Arafat plain
}

# The canonical Hajj transit sequence (the rites themselves are NOT re-routable;
# we optimise only the connecting transits between consecutive waypoints).
RITUAL_SEQUENCE = ["Haram", "Mina", "Muzdalifah", "Arafat", "Mina", "Jamarat"]

CACHE = "data/corridor_walk.graphml"


def bbox_from_config(pad=0.01):
    """Bounding box covering all sites, padded. Returns (west, south, east, north)."""
    lats = [v[0] for v in SITES.values()]
    lons = [v[1] for v in SITES.values()]
    return (min(lons) - pad, min(lats) - pad, max(lons) + pad, max(lats) + pad)


def fetch(network_type="walk", refresh=False, simplify=True):
    """Fetch (or load cached) OSM pedestrian network for the corridor."""
    import osmnx as ox

    os.makedirs(os.path.dirname(CACHE), exist_ok=True)
    if os.path.exists(CACHE) and not refresh:
        print(f"loading cached network -> {CACHE}")
        return ox.load_graphml(CACHE)

    west, south, east, north = bbox_from_config()
    print(f"fetching OSM '{network_type}' network for bbox "
          f"({west:.4f}, {south:.4f}, {east:.4f}, {north:.4f}) ...")
    print("  (this hits the Overpass API and can take 1-3 minutes)")

    G = ox.graph_from_bbox((west, south, east, north),
                           network_type=network_type,
                           simplify=simplify,
                           retain_all=False,
                           truncate_by_edge=True)
    ox.save_graphml(G, CACHE)
    print(f"cached -> {CACHE}")
    return G


# Radius over which demand is distributed for each site, in metres.
# Arafat and Muzdalifah are open plains where pilgrims arrive across a wide
# front; the built-up sites have narrower, channelised approaches.
SITE_RADIUS_M = {
    "Haram": 400.0, "Jamarat": 500.0, "Mina": 800.0,
    "Muzdalifah": 1500.0, "Arafat": 2000.0,
}
MIN_DEGREE = 3          # a site anchor must not be a dead end
MAX_ACCESS_NODES = 40   # cap the super-source fan-out


def snap_sites(G, multi=True, min_degree=MIN_DEGREE):
    """
    Map each ritual site to graph node(s).

    WHY THIS IS NOT A SINGLE NEAREST NODE.

    Point-snapping injects a whole leg's demand through one node, so the two or
    three edges touching it cap the leg regardless of how much capacity the rest
    of the network has. Diagnosis on the real OSM extract found this exactly:
    Arafat snapped to a DEGREE-1 node on a 3 m footpath, capping the leg at
    1.225 * 3 * 3600 = 13,230 ped/h against a demand of 810,000, and 100% of
    saturated arcs sat 92 m from that node while aggregate network capacity
    exceeded demand by a factor of ~1000. The infeasibility was an artefact of
    the snap, not a property of the corridor.

    Two corrections:
      * prefer a well-connected anchor (degree >= min_degree), even if slightly
        further away, so a dead-end path is never a site's only access point;
      * return a SET of access nodes within a site-specific radius, so demand
        enters across a front. Arafat and Muzdalifah are open plains of several
        square kilometres; pilgrims do not file through one lamppost.

    Returns, per site: the primary node (back-compatible), its offset, and
    `access` -- the list of nodes over which demand should be distributed.
    """
    import osmnx as ox
    import networkx as nx

    und = G.to_undirected()
    out = {}
    for name, (lat, lon) in SITES.items():
        nid = ox.distance.nearest_nodes(G, X=lon, Y=lat)

        # --- prefer a well-connected primary anchor ---
        if und.degree(nid) < min_degree:
            best, best_d = nid, float("inf")
            for n, d in G.nodes(data=True):
                if und.degree(n) < min_degree:
                    continue
                dy = (d["y"] - lat) * 111_320.0
                dx = (d["x"] - lon) * 111_320.0 * 0.93
                dd = (dx * dx + dy * dy) ** 0.5
                if dd < best_d:
                    best_d, best = dd, n
            nid = best

        nlat, nlon = G.nodes[nid]["y"], G.nodes[nid]["x"]
        dy = (nlat - lat) * 111_320.0
        dx = (nlon - lon) * 111_320.0 * 0.93
        dist = (dx ** 2 + dy ** 2) ** 0.5

        # --- access set: well-connected nodes within the site radius ---
        access = [nid]
        if multi:
            r = SITE_RADIUS_M.get(name, 500.0)
            cand = []
            for n, d in G.nodes(data=True):
                if und.degree(n) < min_degree:
                    continue
                ddy = (d["y"] - lat) * 111_320.0
                ddx = (d["x"] - lon) * 111_320.0 * 0.93
                dd = (ddx * ddx + ddy * ddy) ** 0.5
                if dd <= r:
                    cand.append((dd, n))
            cand.sort()
            access = [n for _, n in cand[:MAX_ACCESS_NODES]] or [nid]

        out[name] = {"node": nid, "lat": nlat, "lon": nlon, "snap_m": dist,
                     "access": access, "n_access": len(access),
                     "radius_m": SITE_RADIUS_M.get(name, 500.0),
                     "degree": int(und.degree(nid))}
    return out


def report(G, snapped):
    import networkx as nx

    n, e = G.number_of_nodes(), G.number_of_edges()
    print(f"\nnetwork: {n} nodes, {e} edges")

    und = G.to_undirected()
    comps = list(nx.connected_components(und))
    comps.sort(key=len, reverse=True)
    print(f"connected components: {len(comps)} "
          f"(largest holds {len(comps[0])}/{n} = {100*len(comps[0])/n:.1f}% of nodes)")

    print("\nsite snapping:")
    biggest = comps[0]
    for name, d in snapped.items():
        flag = "" if d["node"] in biggest else "   <-- NOT in main component!"
        print(f"  {name:<11} node {d['node']:<12} offset {d['snap_m']:7.1f} m  "
              f"degree {d.get('degree','?'):>2}  access nodes {d.get('n_access',1):>3} "
              f"(r={d.get('radius_m',0):.0f} m){flag}")

    # connectivity along the ritual sequence
    print("\nritual-sequence connectivity:")
    ok = True
    for a, b in zip(RITUAL_SEQUENCE[:-1], RITUAL_SEQUENCE[1:]):
        na, nb = snapped[a]["node"], snapped[b]["node"]
        reach = nx.has_path(und, na, nb)
        ok &= reach
        print(f"  {a:<11} -> {b:<11} {'connected' if reach else 'NO PATH'}")

    print()
    if not ok:
        print("SOME LEGS ARE DISCONNECTED. Options:")
        print("  1. re-run with --network all  (adds service roads/tracks)")
        print("  2. increase the bbox padding in bbox_from_config()")
        print("  3. route only the connected legs and say so in the paper")
    else:
        print("All ritual legs are connected: ready for routing.")
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--refresh", action="store_true", help="force re-fetch from OSM")
    ap.add_argument("--network", default="walk",
                    choices=["walk", "all", "all_public", "drive_service"],
                    help="OSM network type ('all' if 'walk' is too sparse)")
    args = ap.parse_args()

    try:
        import osmnx  # noqa: F401
    except ImportError:
        sys.exit("osmnx not installed. Run: pip install osmnx")

    G = fetch(network_type=args.network, refresh=args.refresh)
    snapped = snap_sites(G)
    report(G, snapped)

    print(f"\nNext: attach your real predicted risk field to these edges with")
    print(f"      python routing.py --risk <your_field.npy>")


if __name__ == "__main__":
    main()
