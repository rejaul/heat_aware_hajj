"""
Verify that ECOSTRESS scenes are cropped to config.BBOX before rebuilding pairs.

Run this BEFORE `python align.py`. A full rebuild takes a long time, and the
failure it guards against is silent: if the crop does not fire, pairs are written
as full ~1568 x 1568 (110 km) tiles while every downstream sampler assumes the
raster spans config.BBOX. Routes would then be computed from surface
temperatures tens of kilometres away and still look entirely plausible.

Checks, in order:
  1. config.BBOX is the corridor box, not the old wide one
  2. align.crop_to_bbox exists (i.e. the updated align.py is actually installed)
  3. a real scene crops to roughly the expected pixel dimensions
  4. the cropped extent, converted back to lat/lon, contains all ritual sites
  5. how many scenes overlap the box at all (tile 37QED vs 37QFD)

Run:  python crop_test.py
      python crop_test.py --n 12        # test more scenes
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import re
import warnings

warnings.filterwarnings("ignore")

import numpy as np

SITES = {"Haram": (21.4225, 39.8262), "Jamarat": (21.4222, 39.8728),
         "Mina": (21.4133, 39.8933), "Muzdalifah": (21.3833, 39.9333),
         "Arafat": (21.3547, 39.9843)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=6, help="scenes to test")
    args = ap.parse_args()

    import config
    import align

    west, south, east, north = config.BBOX
    print("=" * 70)
    print("CROP TEST")
    print("=" * 70)
    print(f"1. config.BBOX = {config.BBOX}")
    span_x = (east - west) * 111.32 * np.cos(np.radians((south + north) / 2))
    span_y = (north - south) * 110.57
    print(f"   spans ~{span_x:.1f} x {span_y:.1f} km "
          f"-> ~{int(span_x*1000/70)} x {int(span_y*1000/70)} px at 70 m")
    if span_x > 60 or span_y > 60:
        print("   [warn] this is much larger than the ritual corridor; you may")
        print("   still be on the old wide box.")

    has = hasattr(align, "crop_to_bbox")
    print(f"\n2. align.crop_to_bbox present: {has}")
    if not has:
        raise SystemExit(
            "   The installed align.py has no crop_to_bbox. Download the "
            "updated align.py before rebuilding, or pairs will be written as "
            "full tiles.")

    scenes = align.group_layers(config.RAW_ECO)
    keys = list(scenes)
    print(f"\n3. cropping {min(args.n, len(keys))} of {len(keys)} scenes")

    ok, no_overlap, other = 0, 0, 0
    dims_seen, tiles = [], {}
    for k in keys[: args.n]:
        tile = (re.search(r"_(\d{2}[A-Z]{3})_", k) or [None, "????"])[1] \
            if re.search(r"_(\d{2}[A-Z]{3})_", k) else "????"
        try:
            lst = align.load_ecostress_scene(scenes[k])
            d = dict(lst.sizes)
            dims_seen.append((d.get("y", 0), d.get("x", 0)))
            tiles.setdefault(tile, [0, 0])[0] += 1
            ok += 1
            print(f"   {tile}  {d}   x {float(lst.x[0]):.0f}..{float(lst.x[-1]):.0f}")
        except ValueError as e:
            if "does not overlap" in str(e):
                no_overlap += 1
                tiles.setdefault(tile, [0, 0])[1] += 1
                print(f"   {tile}  REJECTED (outside the box) -- expected for "
                      f"tiles that do not cover the corridor")
            else:
                other += 1
                print(f"   {tile}  ERROR: {str(e)[:70]}")
        except Exception as e:
            other += 1
            print(f"   {tile}  ERROR: {type(e).__name__}: {str(e)[:60]}")

    print(f"\n   cropped OK {ok} | outside box {no_overlap} | other errors {other}")
    if tiles:
        print("   by tile (kept / rejected):")
        for t, (a, b) in sorted(tiles.items()):
            print(f"     {t}: {a} / {b}")

    if not dims_seen:
        raise SystemExit("   No scene cropped successfully -- stop and fix "
                         "before running align.py.")

    ys = [d[0] for d in dims_seen]; xs = [d[1] for d in dims_seen]
    print(f"\n   cropped dims: y {min(ys)}-{max(ys)}, x {min(xs)}-{max(xs)}")
    if max(ys) > 1000 or max(xs) > 1000:
        raise SystemExit(
            "   STILL FULL-TILE SIZED. The crop is not taking effect. Do not "
            "run align.py; the coordinate slice is not matching.")

    # 4. does the cropped extent actually contain the ritual sites?
    print("\n4. ritual sites inside config.BBOX:")
    inside = 0
    for nm, (la, lo) in SITES.items():
        ins = (west <= lo <= east) and (south <= la <= north)
        inside += ins
        mark = "yes" if ins else "NO  <-- outside the study box"
        print(f"   {nm:<11} ({la:.4f}, {lo:.4f})  {mark}")
    if inside < len(SITES):
        print("   [warn] not all sites are covered; widen config.BBOX or the")
        print("   routing will be missing part of the ritual circuit.")

    # 5. tile suitability
    print("\n5. recommendation")
    tile_px = min(min(ys), min(xs))
    rec = 256 if tile_px >= 288 else (128 if tile_px >= 160 else 64)
    print(f"   smallest cropped side is {tile_px} px, so train with --tile {rec}")
    print(f"   (HeatPairDataset pads with NaN when tile > scene, which wastes")
    print(f"    capacity and dilutes the loss)")
    print("\n   If everything above looks right:")
    print("     python align.py > align_crop_log.txt 2>&1")


if __name__ == "__main__":
    main()
