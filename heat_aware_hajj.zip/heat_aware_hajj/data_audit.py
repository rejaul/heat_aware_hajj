"""
Data audit: what do we actually have, on the dates that matter, and why is so
much of it unusable?

Three questions, in order of consequence:

  1. COVERAGE ON HAJJ DATES. The pilgrimage follows the lunar calendar and moves
     ~11 days earlier each Gregorian year, so a fixed May-September window does
     not sample the ritual days evenly. How many scenes fall on or near the
     actual Hajj dates, by year?

  2. CLOUD AND VALIDITY. 113 of 216 corridor-overlapping scenes were rejected by
     a 30% valid-pixel floor, and the rejected distribution was heavily skewed:
     151 of 242 sat below 10% valid. For an arid site that is surprising, and
     worth separating into genuine cloud, off-swath geometry, and QC masking.

  3. ANOMALIES. Is loss concentrated in particular years, months, times of day
     or orbits? Systematic loss biases the record; random loss merely thins it.

Hajj dates below are the Gregorian equivalents of 8-13 Dhul-Hijjah. VERIFY them
against an authoritative source before publication: the civil start of the month
is set by observation and can shift by a day.

Run:  python data_audit.py
      python data_audit.py --window 10      # +/- days around the Hajj window
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import glob
import json
import re
import warnings
from collections import Counter, defaultdict
from datetime import date, datetime

warnings.filterwarnings("ignore")

import numpy as np

# 8-13 Dhul-Hijjah in Gregorian terms. Day of Arafah is 9 Dhul-Hijjah.
HAJJ = {
    2019: (date(2019, 8,  9), date(2019, 8, 14), date(2019, 8, 10)),
    2020: (date(2020, 7, 28), date(2020, 8,  2), date(2020, 7, 30)),
    2021: (date(2021, 7, 17), date(2021, 7, 22), date(2021, 7, 19)),
    2022: (date(2022, 7,  7), date(2022, 7, 12), date(2022, 7,  8)),
    2023: (date(2023, 6, 26), date(2023, 7,  1), date(2023, 6, 27)),
    2024: (date(2024, 6, 14), date(2024, 6, 19), date(2024, 6, 15)),
}

TS = re.compile(r"(\d{8})T(\d{6})")
TILE = re.compile(r"_(\d{2}[A-Z]{3})_")
ORBIT = re.compile(r"LSTE_(\d{5})_")
UTC_OFFSET_H = 3.0


def parse(name):
    m = TS.search(name)
    if not m:
        return None
    d = datetime.strptime(m.group(1), "%Y%m%d").date()
    tm = m.group(2)
    utc = int(tm[:2]) + int(tm[2:4]) / 60.0
    loc = (utc + UTC_OFFSET_H) % 24.0
    tile = (TILE.search(name).group(1) if TILE.search(name) else "?")
    orb = int(ORBIT.search(name).group(1)) if ORBIT.search(name) else -1
    return {"date": d, "local_h": loc, "utc_h": utc, "tile": tile, "orbit": orb}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/raw/ecostress")
    ap.add_argument("--pairs", default="data/pairs")
    ap.add_argument("--window", type=int, default=7,
                    help="+/- days around the Hajj window to count as 'near'")
    args = ap.parse_args()

    # ---- inventory every granule we downloaded ----
    raw = glob.glob(f"{args.raw}/**/*LST*", recursive=True) + \
          glob.glob(f"{args.raw}/*LST*")
    raw_keys = {}
    for f in raw:
        p = parse(os.path.basename(f))
        if p:
            raw_keys[os.path.basename(f).rsplit("_", 1)[0]] = p
    used = {}
    for f in glob.glob(f"{args.pairs}/*_pair.nc"):
        p = parse(os.path.basename(f))
        if p:
            used[os.path.basename(f)] = p

    print("=" * 78)
    print("DATA AUDIT")
    print("=" * 78)
    print(f"  granules inventoried : {len(raw_keys):>5}")
    print(f"  pairs built          : {len(used):>5}")
    if raw_keys:
        print(f"  retention            : {100*len(used)/len(raw_keys):>5.1f}%")

    src = used if used else raw_keys
    if not src:
        raise SystemExit("No scenes found. Check --raw and --pairs paths.")

    # ---- 1. coverage on Hajj dates ----
    print("\n1. COVERAGE ON THE RITUAL DAYS")
    print("   The lunar calendar moves the Hajj ~11 days earlier each year, so a")
    print("   fixed seasonal window samples the ritual days unevenly.")
    print(f"\n   {'year':>6}{'Hajj window':>22}{'on days':>9}{'within ' + str(args.window) + 'd':>12}"
          f"{'that year':>11}")
    print("   " + "-" * 62)
    rows = []
    for yr, (a, b, arafah) in sorted(HAJJ.items()):
        on = [v for v in src.values() if a <= v["date"] <= b]
        near = [v for v in src.values()
                if abs((v["date"] - arafah).days) <= args.window]
        yrall = [v for v in src.values() if v["date"].year == yr]
        rows.append({"year": yr, "on": len(on), "near": len(near),
                     "year_total": len(yrall)})
        print(f"   {yr:>6}{a.strftime('%d %b')+' - '+b.strftime('%d %b'):>22}"
              f"{len(on):>9}{len(near):>12}{len(yrall):>11}")
    tot_on = sum(r["on"] for r in rows)
    print("   " + "-" * 62)
    print(f"   scenes falling on actual ritual days: {tot_on} of {len(src)}"
          f"  ({100*tot_on/max(len(src),1):.1f}%)")
    if tot_on < 10:
        print("   -> The record barely covers the ritual days themselves. Claims")
        print("      about conditions DURING the Hajj rest on very few scenes;")
        print("      the analysis characterises the SEASON, not the event.")

    # ---- 2. validity / cloud ----
    print("\n2. VALID-PIXEL FRACTION (cloud, QC and off-swath combined)")
    try:
        import xarray as xr
        fr, by_year, by_hour = [], defaultdict(list), defaultdict(list)
        for f in sorted(glob.glob(f"{args.pairs}/*_pair.nc")):
            p = parse(os.path.basename(f))
            with xr.open_dataset(f) as ds:
                if "lst_fine" not in ds:
                    continue
                a = ds["lst_fine"].values
                v = float(np.isfinite(a).mean())
            fr.append(v)
            if p:
                by_year[p["date"].year].append(v)
                by_hour[int(p["local_h"] // 4) * 4].append(v)
        if fr:
            fr = np.array(fr)
            print(f"   retained scenes: n={fr.size}, valid fraction "
                  f"min {fr.min():.2f} median {np.median(fr):.2f} max {fr.max():.2f}")
            print("\n   by year:")
            for y in sorted(by_year):
                v = np.array(by_year[y])
                print(f"     {y}  n={v.size:>3}  median valid {np.median(v):.2f}")
            print("\n   by local time of day:")
            for h in sorted(by_hour):
                v = np.array(by_hour[h])
                print(f"     {h:02d}-{h+4:02d}h  n={v.size:>3}  "
                      f"median valid {np.median(v):.2f}")
    except ImportError:
        print("   [skip] xarray not available")

    # ---- 3. where the losses fall ----
    print("\n3. WHERE THE LOSSES FALL")
    if raw_keys and used:
        used_dates = {v["date"] for v in used.values()}
        lost = [v for k, v in raw_keys.items() if v["date"] not in used_dates]
        print(f"   granules not represented in any pair: {len(lost)}")

        ct = Counter(v["tile"] for v in lost)
        print(f"\n   by MGRS tile (lost):")
        for t, c in ct.most_common():
            kept = sum(1 for v in used.values() if v["tile"] == t)
            print(f"     {t}: lost {c:>4}   kept {kept:>4}")
        print("   -> a tile lost wholesale is a GEOMETRY problem (the tile does")
        print("      not cover the corridor), not a cloud problem.")

        cy = Counter(v["date"].year for v in lost)
        cy_k = Counter(v["date"].year for v in used.values())
        print(f"\n   by year (lost / kept):")
        for y in sorted(set(cy) | set(cy_k)):
            tot = cy[y] + cy_k[y]
            print(f"     {y}: {cy[y]:>4} / {cy_k[y]:>4}   "
                  f"retention {100*cy_k[y]/max(tot,1):>5.1f}%")

        ch = Counter(int(v["local_h"] // 4) * 4 for v in lost)
        ch_k = Counter(int(v["local_h"] // 4) * 4 for v in used.values())
        print(f"\n   by local time of day (lost / kept):")
        for h in sorted(set(ch) | set(ch_k)):
            tot = ch[h] + ch_k[h]
            print(f"     {h:02d}-{h+4:02d}h: {ch[h]:>4} / {ch_k[h]:>4}   "
                  f"retention {100*ch_k[h]/max(tot,1):>5.1f}%")
        print("   -> retention that varies strongly with year or hour is a")
        print("      SYSTEMATIC bias in the record, not random thinning, and")
        print("      must be reported as such.")

    out = {"granules": len(raw_keys), "pairs": len(used), "hajj_coverage": rows}
    json.dump(out, open("data_audit.json", "w"), indent=2, default=str)
    print("\n  results -> data_audit.json")
    print("\n  NOTE: verify the Hajj dates above against an authoritative source.")
    print("  The civil start of Dhul-Hijjah is set by observation and can shift")
    print("  by a day, which matters when the window is only six days wide.")


if __name__ == "__main__":
    main()
