"""
Dataset for AMUN training: reads the aligned NetCDF pairs produced by align.py.

Each pair holds the coarse predictor stack already reprojected onto the 70 m
ECOSTRESS grid, plus the masked fine LST target.

SPLIT SEMANTICS (CHANGED): split_files() now groups scenes by ACQUISITION DATE
and cuts at date boundaries, so training, validation and calibration share no
acquisition date. The previous version sorted by filename and sliced by index,
which guaranteed neither property -- see the note on split_files() below.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import torch
import xarray as xr
from torch.utils.data import Dataset

import config

PREDICTORS = ["t2m_c", "rh", "ws2", "ws10", "tw", "tg", "wbgt",
              "sw_sunlit", "mean_cos_zenith", "sunlit_fraction", "skt"]
TARGET = "lst_fine"
BASELINE = "wbgt"          # coarse field the network learns a residual on


class HeatPairDataset(Dataset):
    def __init__(self, files, tile: int = 512, stats: dict | None = None,
                 augment: bool = True, min_valid: float = 0.25,
                 samples_per_file: int = 4):
        self.files = list(files)
        self.tile = tile
        self.augment = augment
        self.min_valid = min_valid
        self.samples_per_file = samples_per_file
        self.stats = stats
        if not self.files:
            raise ValueError("No pair files given.")

    def __len__(self):
        return len(self.files) * self.samples_per_file

    # -- normalisation ----------------------------------------------------
    @staticmethod
    def compute_stats(files, max_files: int = 60) -> dict:
        acc = {v: [] for v in PREDICTORS + [TARGET]}
        for f in list(files)[:max_files]:
            with xr.open_dataset(f) as ds:
                for v in acc:
                    if v in ds:
                        a = ds[v].values.astype("float32").ravel()
                        a = a[np.isfinite(a)]
                        if a.size:
                            acc[v].append(a[::37])       # subsample
        stats = {}
        for v, chunks in acc.items():
            if chunks:
                a = np.concatenate(chunks)
                stats[v] = {"mean": float(a.mean()),
                            "std": float(a.std() + 1e-6)}
        return stats

    def _norm(self, arr, name):
        s = self.stats.get(name) if self.stats else None
        if not s:
            return arr
        return (arr - s["mean"]) / s["std"]

    # -- sampling ---------------------------------------------------------
    def _crop(self, ds, rng):
        ny, nx = ds[TARGET].shape[-2:]
        t = self.tile
        if ny < t or nx < t:
            pad_y, pad_x = max(0, t - ny), max(0, t - nx)
            ds = ds.pad(y=(0, pad_y), x=(0, pad_x), constant_values=np.nan)
            ny, nx = ds[TARGET].shape[-2:]

        for _ in range(12):                       # try to land on valid data
            y0 = rng.integers(0, ny - t + 1)
            x0 = rng.integers(0, nx - t + 1)
            sub = ds.isel(y=slice(y0, y0 + t), x=slice(x0, x0 + t))
            frac = float(np.isfinite(sub[TARGET].values).mean())
            if frac >= self.min_valid:
                return sub
        return sub

    def __getitem__(self, idx):
        f = self.files[idx // self.samples_per_file]
        rng = np.random.default_rng(idx * 7919)

        with xr.open_dataset(f) as ds:
            sub = self._crop(ds, rng)

            chans = []
            for v in PREDICTORS:
                a = (sub[v].values.astype("float32") if v in sub
                     else np.zeros(sub[TARGET].shape, dtype="float32"))
                chans.append(self._norm(np.nan_to_num(a), v))
            x = np.stack(chans, 0)

            # NOTE ON THE BASELINE. The residual anchor is the coarse WBGT
            # field but it is normalised with the TARGET (LST) statistics, which
            # puts it in target space so that "target = baseline + residual" is
            # meaningful. Because WBGT and LST have different means and scales,
            # the normalised baseline carries a constant offset the network must
            # absorb. Not incorrect, but it wastes a little capacity. If you
            # retrain from scratch, consider normalising the baseline with its
            # own statistics. Do NOT change this on a trained checkpoint.
            base = np.nan_to_num(sub[BASELINE].values.astype("float32")) \
                if BASELINE in sub else np.zeros(sub[TARGET].shape, "float32")
            base = self._norm(base, TARGET)[None]

            y = sub[TARGET].values.astype("float32")
            mask = np.isfinite(y)
            y = self._norm(np.nan_to_num(y), TARGET)[None]
            mask = mask[None]

        if self.augment:
            if rng.random() < 0.5:
                x, y, base, mask = (np.flip(a, -1) for a in (x, y, base, mask))
            if rng.random() < 0.5:
                x, y, base, mask = (np.flip(a, -2) for a in (x, y, base, mask))
            k = int(rng.integers(0, 4))
            if k:
                x, y, base, mask = (np.rot90(a, k, (-2, -1))
                                    for a in (x, y, base, mask))

        return (torch.from_numpy(np.ascontiguousarray(x)),
                torch.from_numpy(np.ascontiguousarray(base)),
                torch.from_numpy(np.ascontiguousarray(y)),
                torch.from_numpy(np.ascontiguousarray(mask)))


_TS = re.compile(r"(\d{8})T(\d{6})")     # 20240615T104012 (ECOSTRESS style)
_D8 = re.compile(r"(\d{8})")             # bare YYYYMMDD fallback


def acquisition_key(path):
    """(date_YYYYMMDD, datetime_YYYYMMDDHHMMSS) from a pair filename, or (None, None)."""
    name = Path(path).name
    m = _TS.search(name)
    if m:
        return m.group(1), m.group(1) + m.group(2)
    m = _D8.search(name)
    if m:
        return m.group(1), m.group(1) + "000000"
    return None, None


def split_files(pair_dir: Path | None = None, val_frac=0.15, cal_frac=0.20,
                seed=0, strict=True, verbose=True, return_meta=False):
    """
    Chronological split at ACQUISITION-DATE boundaries.

    Why this replaced the previous implementation
    ---------------------------------------------
    The old version did sorted(glob(...)) then sliced by index. Two problems
    followed, and together they made the claim "trained and evaluated on
    disjoint acquisition dates" unverifiable:

      1. ECOSTRESS-derived pair names place the ORBIT number BEFORE the
         timestamp (ECOv002_L2T_LSTE_<orbit>_<scene>_<tile>_<date>T<time>_...),
         so lexicographic order sorts by orbit, not acquisition time. Orbit and
         date correlate but are not identical.
      2. Slicing by index lets one date with several scenes straddle a boundary,
         putting scenes from the SAME day on both sides. That leaks across the
         calibration boundary and weakens the conformal guarantee, which needs a
         genuinely held-out calibration set.

    This version parses the timestamp, groups by date, and cuts at date
    boundaries. Fractions apply to the number of DATES, not scenes, so scene
    counts will not match the fractions exactly -- that is correct, report as-is.

    strict=True raises if any filename lacks a parseable timestamp, so the
    claim cannot be made on unverifiable data.
    """
    pair_dir = Path(pair_dir or config.PAIRS)
    files = sorted(pair_dir.glob("*_pair.nc"))
    if not files:
        raise SystemExit(f"No pairs in {pair_dir}. Run align.py first.")

    keyed, unparsed = [], []
    for f in files:
        d, dt = acquisition_key(f)
        (unparsed.append(f) if d is None else keyed.append((d, dt, f)))

    if unparsed:
        msg = (f"{len(unparsed)} of {len(files)} pair file(s) have no parseable "
               f"acquisition timestamp (e.g. {unparsed[0].name})")
        if strict:
            raise SystemExit(
                msg + "\n  A date-disjoint split cannot be verified on these "
                "files. Fix the naming in align.py so the ECOSTRESS timestamp "
                "is preserved, or call split_files(strict=False) -- in which "
                "case do NOT claim disjoint acquisition dates.")
        print(f"  [warn] {msg}; excluded from the split.")

    by_date = {}
    for d, dt, f in keyed:
        by_date.setdefault(d, []).append((dt, f))
    dates = sorted(by_date)
    n_dates = len(dates)

    if n_dates < 3:
        raise SystemExit(
            f"Only {n_dates} distinct acquisition date(s) in {pair_dir}. A "
            "three-way date-disjoint split is impossible. Widen "
            "config.QUICK_RANGE and re-run download/align.")

    n_val = max(1, round(val_frac * n_dates))
    n_cal = max(1, round(cal_frac * n_dates))
    if n_val + n_cal >= n_dates:
        raise SystemExit(
            f"{n_dates} dates cannot support val={n_val} + calib={n_cal} plus a "
            "non-empty training set. Widen the acquisition window.")

    d_tr = dates[: n_dates - n_val - n_cal]
    d_va = dates[n_dates - n_val - n_cal: n_dates - n_cal]
    d_cal = dates[n_dates - n_cal:]

    def flatten(ds):
        out = []
        for d in ds:
            out.extend(f for _, f in sorted(by_date[d]))
        return out

    tr, va, cal = flatten(d_tr), flatten(d_va), flatten(d_cal)

    # invariants: exactly the properties the paper claims
    assert not (set(d_tr) & set(d_va)), "date leak: train/val"
    assert not (set(d_tr) & set(d_cal)), "date leak: train/calib"
    assert not (set(d_va) & set(d_cal)), "date leak: val/calib"

    meta = {
        "n_scenes": len(tr) + len(va) + len(cal), "n_dates": n_dates,
        "train": {"dates": len(d_tr), "scenes": len(tr), "range": [d_tr[0], d_tr[-1]]},
        "val": {"dates": len(d_va), "scenes": len(va), "range": [d_va[0], d_va[-1]]},
        "calib": {"dates": len(d_cal), "scenes": len(cal), "range": [d_cal[0], d_cal[-1]]},
        "date_disjoint": True,
        "strictly_forward": bool(max(d_tr) < min(d_va) and max(d_va) < min(d_cal)),
        "excluded_unparsed": len(unparsed),
    }

    if verbose:
        print(f"  date-grouped chronological split over {n_dates} dates "
              f"({meta['n_scenes']} scenes):")
        for k in ("train", "val", "calib"):
            m = meta[k]
            print(f"    {k:<6} {m['dates']:>3} dates / {m['scenes']:>3} scenes  "
                  f"[{m['range'][0]} .. {m['range'][1]}]")
        print(f"    date-disjoint: {meta['date_disjoint']}   "
              f"strictly forward: {meta['strictly_forward']}")
        if n_val < 2 or n_cal < 3:
            print("    [caution] very few validation/calibration DATES; the "
                  "conformal guarantee is weak here. Report the counts and say "
                  "so in the limitations.")

    return (tr, va, cal, meta) if return_meta else (tr, va, cal)


def describe_split(pair_dir=None):
    """Print a paper-ready sentence containing the real counts."""
    _, _, _, m = split_files(pair_dir, verbose=False, return_meta=True)
    print(f"The {m['n_scenes']} usable scenes span {m['n_dates']} acquisition "
          f"dates, partitioned chronologically at date boundaries into training "
          f"({m['train']['scenes']} scenes over {m['train']['dates']} dates), "
          f"validation ({m['val']['scenes']}/{m['val']['dates']}) and "
          f"calibration ({m['calib']['scenes']}/{m['calib']['dates']}) sets that "
          f"share no acquisition date.")
    return m


def save_stats(stats, path):
    Path(path).write_text(json.dumps(stats, indent=2))


def load_stats(path):
    return json.loads(Path(path).read_text())


if __name__ == "__main__":
    describe_split()
