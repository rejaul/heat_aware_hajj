"""
Multi-agent UAV dispatch simulator.

Implements the receding-horizon allocation of Sect. 6 of the paper:

    max_{a_k}  sum_k [ Rbar_{a_k} - lambda * E(loc_k -> a_k) ]
    s.t.       E(.) <= B_k,  no-fly / separation constraints

solved by decentralised auction and re-solved each cycle as the risk surface
updates.

Heat-stress incidents are generated stochastically with intensity proportional
to the local risk. An incident is *served* if a UAV reaches its cell within the
response window, and *missed* otherwise. Because Tier-3 escalation consumes an
ambulance, a heat-stroke bed and sometimes air evacuation, we cost a missed
event far above a served one -- this is the avoided-escalation argument of
Sect. 8, made quantitative.

CRITICAL: installed cooling infrastructure is NOT actuated in any arm. Misting
stations, shaded corridors and chilled facilities operate identically under
every policy, so differences are attributable to the aerial layer alone.

Run:  python dispatch.py
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from risk import RiskSurface, Availability, _synthetic_scene

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

CELL_M = 120.0          # cell edge, metres
UAV_SPEED = 15.0        # m/s cruise
ENERGY_PER_M = 0.022    # Wh per metre travelled
ENERGY_HOVER = 3.5      # Wh per minute on station
SERVICE_MIN = 2.0       # minutes on station per intervention
RESPONSE_WINDOW = 12.0  # minutes to reach an incident before it is "missed"
LAMBDA = 0.004          # energy penalty in the objective
SERVICE_RADIUS = 3      # cells; a UAV on station covers a neighbourhood
SERVICE_CAPACITY = 4    # incidents one sortie can attend


@dataclass
class UAV:
    uid: int
    pos: tuple            # (row, col) in cell units
    battery: float        # Wh remaining
    capacity: float       # Wh full
    busy_until: float = 0.0
    served: int = 0
    energy_used: float = 0.0
    distance_m: float = 0.0


@dataclass
class Incident:
    t: float
    cell: tuple
    tier: int
    served_at: float | None = None
    served_by: int | None = None

    @property
    def latency(self):
        return None if self.served_at is None else self.served_at - self.t


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def dist_m(a, b) -> float:
    return float(np.hypot(a[0] - b[0], a[1] - b[1]) * CELL_M)


def travel_min(a, b) -> float:
    return dist_m(a, b) / UAV_SPEED / 60.0


def travel_energy(a, b) -> float:
    return dist_m(a, b) * ENERGY_PER_M


def tier_of(risk_val: float, q50: float, q80: float, q95: float) -> int:
    if risk_val >= q95:
        return 3
    if risk_val >= q80:
        return 2
    if risk_val >= q50:
        return 1
    return 0


# ---------------------------------------------------------------------------
# Policies
# ---------------------------------------------------------------------------


def assign_risk_targeted(uavs, rbar, now, rng, served_cells):
    """
    Decentralised auction: each free UAV bids on the reachable cell maximising
    Rbar - lambda * E(travel). Conflicts resolved by highest bid.
    """
    ny, nx = rbar.shape
    # Candidate cells: top-K by risk, excluding recently served.
    flat = rbar.ravel().copy()
    for c in served_cells:
        flat[c[0] * nx + c[1]] *= 0.25          # decay, not exclusion
    top = np.argsort(flat)[::-1][:120]
    cands = [(int(i // nx), int(i % nx)) for i in top]

    bids = []
    for u in uavs:
        if u.busy_until > now:
            continue
        for c in cands:
            e = travel_energy(u.pos, c) + ENERGY_HOVER * SERVICE_MIN
            if e > u.battery:
                continue
            value = rbar[c] - LAMBDA * e
            bids.append((value, u.uid, c))

    bids.sort(reverse=True)
    taken_cells, taken_uavs, out = set(), set(), {}
    for value, uid, c in bids:
        if uid in taken_uavs or c in taken_cells:
            continue
        out[uid] = c
        taken_uavs.add(uid)
        taken_cells.add(c)
    return out


def assign_nearest(uavs, rbar, now, rng, served_cells):
    """Dispatch to the nearest cell above a fixed risk trigger."""
    ny, nx = rbar.shape
    thr = np.quantile(rbar, 0.90)
    hot = list(zip(*np.where(rbar >= thr)))
    if not hot:
        return {}
    out, taken = {}, set()
    for u in uavs:
        if u.busy_until > now:
            continue
        best, bd = None, np.inf
        for c in hot:
            if c in taken:
                continue
            d = dist_m(u.pos, c)
            e = travel_energy(u.pos, c) + ENERGY_HOVER * SERVICE_MIN
            if e <= u.battery and d < bd:
                best, bd = c, d
        if best:
            out[u.uid] = best
            taken.add(best)
    return out


def assign_uniform(uavs, rbar, now, rng, served_cells):
    """Risk-blind: patrol cells drawn uniformly at random."""
    ny, nx = rbar.shape
    out = {}
    for u in uavs:
        if u.busy_until > now:
            continue
        for _ in range(20):
            c = (int(rng.integers(ny)), int(rng.integers(nx)))
            e = travel_energy(u.pos, c) + ENERGY_HOVER * SERVICE_MIN
            if e <= u.battery:
                out[u.uid] = c
                break
    return out


POLICIES = {
    "Uniform patrol": assign_uniform,
    "Nearest-resource": assign_nearest,
    "Risk-targeted (ours)": assign_risk_targeted,
}


# ---------------------------------------------------------------------------
# Simulation
# ---------------------------------------------------------------------------


def simulate(rbar, policy_fn, n_uav=12, horizon_min=240.0, cycle_min=5.0,
             incident_scale=0.006, seed=0, battery_wh=280.0):
    rng = np.random.default_rng(seed)
    ny, nx = rbar.shape

    q50, q80, q95 = np.quantile(rbar, [0.50, 0.80, 0.95])

    uavs = [UAV(uid=i,
                pos=(int(rng.integers(ny)), int(rng.integers(nx))),
                battery=battery_wh, capacity=battery_wh)
            for i in range(n_uav)]

    # Incident intensity proportional to risk.
    lam = incident_scale * rbar / max(rbar.mean(), 1e-9)

    incidents: list[Incident] = []
    served_cells: list[tuple] = []
    t = 0.0
    while t < horizon_min:
        # -- generate incidents this cycle --
        counts = rng.poisson(lam * cycle_min / 60.0)
        for (r, c) in zip(*np.where(counts > 0)):
            for _ in range(int(counts[r, c])):
                incidents.append(
                    Incident(t=t, cell=(int(r), int(c)),
                             tier=tier_of(rbar[r, c], q50, q80, q95)))

        # -- assign --
        assign = policy_fn(uavs, rbar, t, rng, served_cells[-40:])
        for u in uavs:
            if u.uid not in assign:
                continue
            target = assign[u.uid]
            tt = travel_min(u.pos, target)
            e = travel_energy(u.pos, target) + ENERGY_HOVER * SERVICE_MIN
            u.distance_m += dist_m(u.pos, target)
            u.energy_used += e
            u.battery -= e
            u.pos = target
            u.busy_until = t + tt + SERVICE_MIN
            served_cells.append(target)

            # -- serve open incidents within the service radius --
            arrival = t + tt
            attended = 0
            for inc in incidents:
                if attended >= SERVICE_CAPACITY:
                    break
                if inc.served_at is not None:
                    continue
                if arrival - inc.t > RESPONSE_WINDOW:
                    continue
                if (abs(inc.cell[0] - target[0]) <= SERVICE_RADIUS
                        and abs(inc.cell[1] - target[1]) <= SERVICE_RADIUS):
                    inc.served_at = arrival
                    inc.served_by = u.uid
                    u.served += 1
                    attended += 1

            if u.battery < 0.18 * u.capacity:      # recharge / swap
                u.battery = u.capacity
                u.busy_until = t + 15.0

        t += cycle_min

    # -- metrics --
    total = len(incidents)
    served = [i for i in incidents if i.served_at is not None]
    missed = [i for i in incidents if i.served_at is None]
    t3_missed = [i for i in missed if i.tier == 3]
    lat = [i.latency for i in served] or [np.nan]
    energy = sum(u.energy_used for u in uavs)

    hi = rbar >= q80
    covered = np.zeros_like(rbar, dtype=bool)
    for c in served_cells:
        covered[c] = True
    risk_cov = float((covered & hi).sum() / max(hi.sum(), 1))

    return {
        "incidents": total,
        "served": len(served),
        "missed": len(missed),
        "missed_rate": len(missed) / max(total, 1),
        "tier3_missed": len(t3_missed),
        "latency_mean": float(np.nanmean(lat)) if served else float("nan"),
        "risk_coverage": risk_cov,
        "energy_wh": energy,
        "energy_per_served": energy / max(len(served), 1),
        "distance_km": sum(u.distance_m for u in uavs) / 1000.0,
    }


def main():
    heat, sigma, dens = _synthetic_scene(n=64, seed=3)
    rs = RiskSurface(heat=heat, heat_sigma=sigma, density=dens)
    _, rbar = rs.compute(Availability(True, False, False, False), n_mc=150,
                         rng=np.random.default_rng(5))

    print("=" * 92)
    print("UAV DISPATCH SIMULATION  (Mode A: autonomous, satellite-only)")
    print("12 UAVs | 4 h horizon | 5 min cycles | installed cooling UNCHANGED in all arms")
    print("=" * 92)
    hdr = (f"{'Policy':<22}{'Latency':>9}{'RiskCov':>9}{'Missed':>9}"
           f"{'T3 miss':>9}{'Wh/served':>11}{'Energy':>10}")
    print(hdr)
    print("-" * 92)

    rows = {}
    for name, fn in POLICIES.items():
        runs = [simulate(rbar, fn, seed=s) for s in range(12)]
        agg = {k: float(np.mean([r[k] for r in runs])) for k in runs[0]}
        rows[name] = agg
        print(f"{name:<22}{agg['latency_mean']:>8.2f}m"
              f"{agg['risk_coverage']:>8.1%}"
              f"{agg['missed_rate']:>8.1%}"
              f"{agg['tier3_missed']:>9.1f}"
              f"{agg['energy_per_served']:>11.1f}"
              f"{agg['energy_wh']:>9.0f}Wh")

    base = rows["Nearest-resource"]
    ours = rows["Risk-targeted (ours)"]
    print("-" * 92)
    print("\nMarginal gain over nearest-resource (the honest comparison):")
    print(f"  latency          {(1-ours['latency_mean']/base['latency_mean']):+.1%}")
    print(f"  missed rate      {(1-ours['missed_rate']/max(base['missed_rate'],1e-9)):+.1%}")
    print(f"  Tier-3 missed    {base['tier3_missed']:.1f} -> {ours['tier3_missed']:.1f}")
    print(f"  energy/served    {(1-ours['energy_per_served']/base['energy_per_served']):+.1%}")
    print("\nNOTE: simulation on a synthetic risk field with prior-based cohort")
    print("hazards. These are NOT empirical results. Report as a simulation")
    print("study until run on fitted AMUN output.")


def fleet_sweep(sizes=(6, 12, 24, 48, 96), seeds=8):
    """
    Fleet-size sweep. The key question for a deployment case is not whether the
    policy helps at a fixed fleet size, but how large a fleet each policy needs
    to drive Tier-3 misses toward zero.
    """
    heat, sigma, dens = _synthetic_scene(n=64, seed=3)
    rs = RiskSurface(heat=heat, heat_sigma=sigma, density=dens)
    _, rbar = rs.compute(Availability(True, False, False, False), n_mc=150,
                         rng=np.random.default_rng(5))

    print("\n" + "=" * 92)
    print("FLEET-SIZE SWEEP  (Tier-3 missed events, mean of %d runs)" % seeds)
    print("=" * 92)
    print(f"{'UAVs':<8}" + "".join(f"{n:>24}" for n in POLICIES))
    print("-" * 92)
    table = {}
    for n in sizes:
        row = []
        for name, fn in POLICIES.items():
            runs = [simulate(rbar, fn, n_uav=n, seed=s) for s in range(seeds)]
            row.append(float(np.mean([r["tier3_missed"] for r in runs])))
        table[n] = row
        print(f"{n:<8}" + "".join(f"{v:>24.1f}" for v in row))
    print("-" * 92)
    return table



if __name__ == "__main__":
    main()
    fleet_sweep()
