# Scalarized router — algorithms, complexity, and measured behaviour

`routing_scalarized.py`. Supersedes the MSA version.

## Why scalarized (and not constrained)

| Formulation | Problem | Complexity |
|---|---|---|
| **Scalarized** `min t + theta*dose` | weighted sum | **polynomial** |
| Constrained `min t s.t. dose <= B` | Resource-Constrained Shortest Path | weakly **NP-hard** |
| Full Pareto set | multi-objective SP | Pareto set can be **exponential** |

We use the scalarized form and sweep `theta` to trace the frontier
*approximately* in polynomial time, instead of enumerating it exactly in
exponential time. **Note: Dijkstra is NOT NP-hard** — shortest path with
non-negative weights is polynomial, and every cost term here is non-negative,
so no relaxation is needed.

## Algorithms used

**Shortest path: A\*** with the admissible heuristic

```
h(u, dst) = great_circle(u, dst) / v_free
```

Admissible because cost >= travel time >= distance/v_free >= straight_line/v_free
(the heat toll and crush penalty are non-negative), so A* returns the exact
optimum. Plain Dijkstra remains available via `--no-astar`.

**Equilibrium: Frank–Wolfe / conjugate Frank–Wolfe** with an *exact line search*
by bisection on `phi(alpha) = d . c(x + alpha*d)`. Cost is monotone increasing in
flow, so `phi` is monotone and bisection is guaranteed. MSA is retained as a
baseline (`--method msa`).

## Complexity

With V nodes, E edges, N equilibrium iterations, K line-search bisections,
S samples/edge, L legs, T theta values:

| Step | Cost |
|---|---|
| edge preparation (once) | `O(E*S)` |
| one A* query | `O(E + V log V)` worst case |
| one line search | `O(K*E)` |
| one FW/CFW iteration | `O(E + V log V + K*E)` |
| one leg to equilibrium | `O(N*(E + V log V + K*E))` |
| full theta sweep | `O(T*L*N*(E + V log V + K*E)) + O(E*S)` |

K and S are small constants, so this is `O(T*L*N*(E + V log V))` — polynomial in
every argument.

## Measured results (demo graph: V=900, E=4,646)

**Solver comparison, same leg, 60 iterations:**

| method | final gap | dose | seconds |
|---|---|---|---|
| MSA | 2.02e-01 | 2220.4 | 0.43 |
| FW | **3.14e-02** | 2168.2 | 4.11 |
| CFW | 3.60e-02 | 2156.8 | 4.58 |

FW/CFW reach a **~6x tighter gap** than MSA at equal iteration count. FW and CFW
are comparable here; CFW's conjugate direction costs a numerical Hessian and did
not pay for itself on this graph.

**A\* vs Dijkstra:** 2.6 ms vs 2.2 ms per query — A* is *slower* on a 900-node
graph, because the heuristic overhead exceeds the pruning benefit. A* is
expected to pay off on a full Makkah OSM extract (~40k nodes); benchmark on your
real graph before choosing.

## The important finding: convergence degrades with saturation

| demand (ped/s) | peak rho | final gap | regime |
|---|---|---|---|
| 1.0 | 0.19 | **9.85e-05** | free-flow |
| 5.0 | 1.73 | 1.41e-03 | congested |
| 15.0 | 2.35 | 1.05e-02 | congested |
| 37.5 (historic) | 2.78 | 3.14e-02 | congested |
| 75.0 | 3.72 | 3.43e-01 | heavily congested |

The solver is **essentially exact in free-flow** (gap 1e-04) and degrades
monotonically as the network saturates. This is **physics, not a bug**: near jam
density the fundamental diagram drives v -> 0, so cost -> infinity and the
equilibrium cost surface becomes near-vertical, which is hard for any
equilibrium method.

**Consequences to state in the paper:**

1. At historic Hajj demand the network is congested, so equilibrium results
   carry real numerical uncertainty (gap ~3e-02). Report the gap with every
   result; do not claim an exactly-converged equilibrium.
2. The **theta sweep is still not monotone in dose** at historic demand. Do not
   present it as a clean Pareto frontier until the gap is tighter. It IS clean
   in the free-flow regime.
3. Substantively: **routing alone cannot fix a saturated network.** This is a
   quantitative argument for departure-time spreading and demand management, not
   just path choice — and it is arguably the more useful operational finding.

## Next upgrade if you need tighter gaps

Bush-based assignment (Dial's Algorithm B, OBA, TAPAS) reaches gaps of 1e-10
where link-based methods stall around 1e-02 to 1e-03. That is the right fix if
the theta frontier must be publication-clean at congested demand.

## Run

```bash
python routing_scalarized.py --demo --benchmark        # solver comparison
python routing_scalarized.py --demo --sweep --method fw
python routing_scalarized.py --risk field_prob.npy --sweep --method fw
```
