# Congestion-Coupled Heat-Aware Routing — model, parameters, findings

`routing_physics.py` (physics core) + `routing_equilibrium.py` (multi-leg
equilibrium router). Assumes you supply an **exceedance-probability grid**
P(WBGT > k) per grid point.

## The model

Generalized cost per edge, in seconds (a "tolled network" formulation):

```
c_ij = t_ij(rho)  +  theta_g * E_eff_ij * t_ij(rho)  +  phi * Psi(rho_ij)
       travel time    heat toll                          crush penalty
```

with `t_ij = l_ij / v(rho_ij)` and **v() the Weidmann fundamental diagram**:

```
v(rho) = v_free * [1 - exp(-gamma (1/rho - 1/rho_jam))]
```

Three couplings the naive router missed:

1. **Line-integral exposure.** Each edge is rasterised across the risk grid and
   exposure integrated over the length spent in each cell. Validated against a
   step-function field: line integral 0.490 vs true 0.500; 3-point sampling
   gave 0.333 — a 33% error.
2. **Crowding slows walking, which lengthens exposure.** Same 1 km at the same
   heat: dose 231 at rho=0.5 vs **6000 at jam density — a 26x amplification**.
   Congestion and heat casualty are the same failure mode.
3. **Crowding also heats** (crowd heat-island term added to E).

Equilibrium by **Method of Successive Averages** (replaces the arbitrary
feedback constant of the naive version), with a reported relative gap.

## The ritual circuit (now closed)

```
Haram -> Mina -> Arafat -> Muzdalifah -> Mina -> Jamarat -> Haram
 day 8   day 9   day 9      day 10       day 10   day 10
```
Arafat -> Muzdalifah is constrained to depart AFTER SUNSET (ritual requirement).
Arrival time on each leg seeds departure on the next.

## Parameters and their provenance

| Parameter | Value | Basis |
|---|---|---|
| `v_free` | 1.34 m/s | [lit] Weidmann |
| `rho_jam` | 5.4 ped/m² | [lit] Weidmann |
| `gamma_fd` | 1.913 | [lit] Weidmann |
| `beta_heat` | 2.1 °C | [lit] crowd heat-island |
| `rho_crit` | 4.0 ped/m² | [lit-ish] crush risk onset |
| `n_pilgrims` | 1.8 M | [lit] historic Hajj scale |
| `walk_fraction` | 0.45 | **[assumed]** |
| `leg_window_h` | 6 h | **[assumed]** |
| edge widths | 4–20 m by OSM tag | **[assumed]** — OSM rarely records width |
| `phi_crush` | 60 s/(ped/m²)² | **[assumed]** |
| `theta_g` | swept 0–500 | **no literature value — SWEPT, not fitted** |

Everything marked **[assumed]** must be reported as such in the paper.

## Findings from the demo run

**1. At historic demand the network saturates.** With 1.8 M pilgrims x 45%
walking over a 6 h window (37.5 ped/s), peak density pins at **8.1 ped/m² —
above jam density — for every value of theta**. Routing alone cannot fix a
saturated network; this is an argument for *departure-time spreading*, not just
path choice, and it matches the reported 8–9 ped/m² corridor densities.

**2. Heat-aware routing buys ~12–13% dose reduction, and saturates early.**
Going from theta=0 (pure navigation-app time minimisation) to theta=10 already
captures 11.3% of the available 12.8%. Being *more* heat-averse buys almost
nothing once the network is congested — a useful, non-obvious operational
result.

## Honest limitations (report these)

1. **MSA convergence is incomplete.** The relative gap falls only 0.44 -> 0.13
   between 25 and 400 iterations (MSA is O(1/n)). Path metrics stabilise much
   faster (~6% dose drift over the same range), but **do not claim an
   exactly-converged equilibrium**. Frank–Wolfe with line search would converge
   faster and is the right upgrade.
2. **The theta sweep is non-monotonic** (detour 7.1%, 14.1%, 6.8%, 25.7% ...).
   This is a convergence artifact, not a real effect. Fix convergence before
   reporting the sweep as a Pareto frontier.
3. **Density is modelled, not observed.** It comes from the assignment itself
   seeded by assumed demand. With live crowd-camera feeds it would be measured.
4. **Static field within a traversal.** Legs take hours; the field changes
   underneath. Time-dependent costs c_ij(t) are the proper treatment — the
   departure-time hook is in place but costs are not yet time-varying.
5. **Edge widths and capacities are assumed** from OSM tags.

## Run it

```bash
python routing_physics.py                       # self-test the physics
python routing_equilibrium.py --demo --sweep    # logic check
python routing_equilibrium.py --risk field_prob.npy --sweep \
       --cohort unreg_75plus                    # your real grid
```

`field_prob.npy` = P(WBGT > 32.2) per grid point, north-up, covering
`config.BBOX`.
