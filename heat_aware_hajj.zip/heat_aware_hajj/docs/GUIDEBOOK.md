# GUIDEBOOK — running the pipeline end-to-end on the 2024 case study

A step-by-step order of operations, from raw data to a quality-assessed
prediction, with decision points ("do X only if Y") along the way. Follow the
stages in order. Each stage says: **what to run**, **what to expect**, and
**how to decide whether to continue or fix something first**.

Everything here is the PRELIMINARY (2024-only) case study. Keep all results
labelled preliminary/synthetic-where-applicable until the full multi-season run.

---

## Stage 0 — one-time setup (do once)

**Credentials**
- CDS (ERA5-Land): accept the licence once in the browser; put the single token
  in `~/.cdsapirc`. See `download_era5land.py` docstring.
- Earthdata (ECOSTRESS): `export EARTHDATA_TOKEN="<fresh-token>"`. See
  `download_ecostress.py` docstring. Use a freshly generated token.

**Dependencies**
```bash
pip install -r requirements.txt --break-system-packages
```

**Confirm you are in case-study mode** (should already be set):
```bash
python -c "import config; print('QUICK:', config.QUICK, '| years:', config.TRAIN_YEARS)"
# expect: QUICK: True | years: [2024]
```
If it does not say `[2024]`, stop and fix `config.py` before downloading.

---

## Stage 1 — check data coverage BEFORE downloading

**Run**
```bash
python download_ecostress.py --inventory
```

**Expect** a granule count for the 2024 window (you saw 25).

**Decide**
- **>= ~15 granules** -> proceed to Stage 2.
- **< 15 granules** -> widen `config.QUICK_RANGE` (add buffer weeks) or add a
  second year, then re-run `--inventory`. Extremes need enough clear overpasses.

Why first: this costs nothing (downloads nothing) and tells you whether the
window is viable before you spend time pulling data.

---

## Stage 2 — download the data

**Run** (in this order)
```bash
python download_era5land.py      # small, fast; monthly chunks, resumable
python download_ecostress.py     # the case-study scenes (drop --inventory)
```

**Expect**
- ERA5-Land: 3 files (May, June, July 2024). Each goes accepted -> running ->
  successful. A 502 + auto-retry is normal; let it recover.
- ECOSTRESS: downloads the granules found in Stage 1.

**Decide**
- If the first ERA5 filename is NOT `era5land_2024...`, stop — you are pulling the
  wrong years (config not in QUICK mode). Fix and restart.
- Leftover files from other years are harmless; they will not match 2024
  ECOSTRESS and are ignored downstream.

---

## Stage 3 — build training pairs (THE key checkpoint)

**Run**
```bash
python align.py
```

**Expect** aligned coarse/fine pairs written to `data/pairs/*_pair.nc`. `align.py`
reprojects ERA5-Land onto the ECOSTRESS grid, computes heat indices, and drops
scenes with too few valid pixels (cloud/quality masking, min 30% valid).

**Decide — this number governs everything downstream:**
- **>= ~10 pairs** -> proceed to Stage 4.
- **< 10 pairs** -> widen `config.QUICK_RANGE` by a few weeks and re-run Stages
  2–3. Do NOT push forward on too few pairs; every later metric depends on this.

Report the pair count to yourself (or note it) before continuing — it sets your
expectations for how trustworthy the later numbers are. 15–20 is a workable
case-study sample; single digits is proof-of-concept only.

---

## Stage 4 — TEST THE HEAVY-TAIL ASSUMPTION (do this before modelling)

This is the scientific gate: your whole extreme-value apparatus (GPD, EQRN, ECP)
is only justified if the heat field is actually heavy-tailed. Find out now.

**Run** (a tiny driver script — see snippet at the bottom of this file, save as
`run_tail_check.py`)
```bash
python run_tail_check.py
```
This loads your real pairs, pools the fine heat-field values, and runs the full
tail battery from `tail_diagnostics.py`, saving a 6-panel figure.

**Expect** a printed VERDICT (heavy / exponential / bounded), a GPD shape `xi`,
normality tests, mean-residual-life and threshold-stability plots, and
return-level estimates. It also gives you the **threshold** to use for the GPD
methods (from the mean-residual-life / stability plots).

**Decide — this steers the whole paper:**
- **xi > 0 (heavy)** -> the EVT framing is fully justified. Proceed with
  confidence; the GPD/EQRN methods should shine. Use the stability plot to pick
  the POT threshold quantile for Stage 6.
- **xi ~ 0 (exponential/light)** or **xi < 0 (bounded)** -> the tail is not heavy
  on this sample. Still proceed, BUT soften the paper's claims about needing
  extreme-value machinery, and lean the contribution toward the calibration and
  risk layers. Better you find this than a reviewer.

Keep the figure — it belongs in the paper as evidence you interrogated your
assumptions.

---

## Stage 5 — fit the proposed model (quantile downscaler)

**Run**
```bash
python train.py --tile 128 --batch 8 --epochs 60
```
(Small data -> few epochs, strong regularisation. `train.py` prints a small-`n`
warning automatically and trains the AMUN quantile head.)

**Expect** decreasing train/val loss and a saved model checkpoint. On a small
sample, watch the train-vs-val gap: a large gap = overfitting (reduce epochs /
increase augmentation).

**Decide**
- Loss decreasing and val not diverging -> proceed.
- Val loss rising while train falls -> overfitting; cut epochs, raise dropout/
  weight-decay, or widen the window for more scenes.

---

## Stage 6 — (optional) fit the GPD-tail benchmarks

Only worth doing if Stage 4 said the tail is heavy (otherwise these add little).

**Run**
```bash
# EQRN with the censoring channel (Option 2), threshold from Stage 4
python train_censored_eqrn.py --epochs 40 --tile 128 --tau 0.90
```
Set `--tau` to the threshold quantile the mean-residual-life plot suggested.

**Expect** a censored-GPD training run + a tail-diagnostics report, saving
`censored_eqrn_2024.pt`. It prints `tail_corr`/`tail_jaccard` — compare these
against the plain `eqrn.py` to see whether censoring helped place extremes.

**Decide**
- Report the comparison honestly. On a small near-light-tailed sample the
  difference may be within noise — say so if it is.

---

## Stage 7 — compare all methods (the results table)

**Run**
```bash
python compare.py            # uses real pairs if present in data/pairs/
```

**Expect** the two comparison tables:
- TABLE 1 (general): RMSE, peak-bias, coverage, exceedance-F1.
- TABLE 2 (extreme-value): return-level errors, tail-only coverage, tail-pinball,
  tail-corr / tail-jaccard.
Plus XGB feature importance.

**Read it honestly**
- `peak_bias < 0` for the mean methods = the under-prediction you are arguing
  against (good — it demonstrates the point).
- If classical EVT baselines (GPD-Regression, Quantile-Regression) match or beat
  the deep methods, SAY SO — that is the honest finding on this data, and it is
  fine for a preliminary paper.
- `tail_corr`/`tail_jaccard` catch a method predicting extremes in the WRONG
  places — always report them for spatial extremes.

---

## Stage 8 — calibrate (the headline result)

**Run**
```bash
python ecp.py
```

**Expect** the split-conformal vs extreme-conformal comparison: as the confidence
level rises, split conformal returns INFINITE intervals while ECP stays finite,
at essentially the same coverage. This result holds even on modest data — it is
your strongest, most data-independent contribution.

**Decide** — nothing to gate here; this is a result to report. If coverage is far
from nominal, note the sample is small and revisit with the full data.

---

## Stage 9 — assess prediction QUALITY (beyond a single number)

Quality = accuracy in the tail + honest uncertainty + extremes in the right
places. You already have the pieces; assemble them:

1. **Tail metrics** from Stage 7 TABLE 2 (return-level error, tail coverage).
2. **Calibration** from Stage 8 (does coverage match nominal?).
3. **Spatial correctness** from `tail_corr`/`tail_jaccard` (Stage 7).
4. **Conditional coverage** (the honest end-to-end test): does the calibrated
   interval hold WITHIN subgroups (by region / heat level), not just overall?
   Marginal coverage can pass while conditional fails.

**Run** the risk surface + degradation check to confirm the operational layer:
```bash
python risk.py
```
**Expect** the composite risk surface, cohort vulnerability, and the
graceful-degradation property (risk monotone as capability is removed; should
hold in ~100% of cells).

---

## Stage 10 — produce the figures / artefacts for the paper

**Run**
```bash
python heatmap.py --risk <your_risk_field>   # interactive live risk map (HTML)
python dispatch.py                            # UAV dispatch simulation + fleet sweep
```

**Expect** `hajj_risk_map.html` (a compelling figure) and the dispatch results
(risk-targeted vs uniform vs nearest; Tier-3 miss reduction with the honest
latency trade-off).

**Note** dispatch is a SIMULATION — label it as such in the paper.

---

## Stage 11 — write up (already drafted)

The preliminary paper (`paper_sustain.tex`) and `SUBMISSION_checklist.md` are
ready. Update the results with your REAL 2024 numbers where you have them, keep
everything else labelled preliminary/synthetic, and follow the checklist
(especially: compile on the official Springer template, not the shim; replace
news-sourced figures with citable ones; run the plagiarism screen).

---

## Quick reference — the whole sequence

```bash
# 0. setup (once): credentials + pip install -r requirements.txt
python -c "import config; print(config.QUICK, config.TRAIN_YEARS)"  # 1a. confirm QUICK
python download_ecostress.py --inventory      # 1b. coverage check  (GATE: >=15?)
python download_era5land.py                    # 2.  download ERA5-Land
python download_ecostress.py                   # 2.  download ECOSTRESS
python align.py                                # 3.  build pairs     (GATE: >=10?)
python run_tail_check.py                       # 4.  heavy-tail test  (STEERS paper)
python train.py --tile 128 --batch 8 --epochs 60   # 5. fit proposed model
python train_censored_eqrn.py --tau 0.90       # 6.  (opt) GPD benchmark if heavy
python compare.py                              # 7.  method comparison table
python ecp.py                                  # 8.  calibration (headline)
python risk.py                                 # 9.  risk surface + degradation
python heatmap.py --risk <field>               # 10. live map figure
python dispatch.py                             # 10. dispatch simulation
```

---

## Appendix — `run_tail_check.py` (Stage 4 driver)

Save this as `run_tail_check.py` in the pipeline folder:

```python
"""Load real pairs, pool the fine heat field, run the tail diagnostics."""
import numpy as np, glob, xarray as xr
from dataset import TARGET
from tail_diagnostics import run_tail_diagnostics

vals = []
for f in sorted(glob.glob("data/pairs/*_pair.nc")):
    with xr.open_dataset(f) as ds:
        if TARGET in ds:
            a = ds[TARGET].values.astype("float32")
            vals.append(a[np.isfinite(a)].ravel())
if not vals:
    raise SystemExit("No pairs found — run align.py first (Stage 3).")

x = np.concatenate(vals)
print(f"pooled {x.size} fine heat-field values from {len(vals)} scenes")
summary = run_tail_diagnostics(x, name="ECOSTRESS heat field (2024)",
                               threshold_q=0.90, out_png="tail_real_2024.png")
# The printed VERDICT + tail_real_2024.png tell you if the tail is heavy,
# and the mean-residual-life / stability plots suggest the POT threshold.
```
