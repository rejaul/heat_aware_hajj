# Reformulated model — response to the critique

## What changed and why

The previous model had three coupled defects, all traceable to one choice:
a **soft** crush penalty inside a **user** equilibrium.

| Defect | Old model | Reformulation |
|---|---|---|
| Saturation | density could exceed jam; "routing can't fix congestion" was partly an artefact of permitting infeasible states | **hard capacity** per (edge, slice); infeasible demand is *rejected*, not crushed |
| Convergence | near jam, v→0 ⇒ near-vertical cost surface ⇒ gap stalled at 3e-2, θ frontier non-monotone | **exact min-cost flow** (network simplex) — no iterative gap at all |
| Equity | user equilibrium is selfish; nothing stopped vulnerable cohorts funnelling into the same cool corridor | **lexicographic** assignment: most-vulnerable cohort routed first on the full network, others on residual capacity |
| Departure time | exogenous input, the strongest control lever unused | **decision variable** via a time-expanded network |
| Static field | one field per leg | field may vary **per time slice** |

## Formulation

Time-expanded graph: node `(i,t)` per spatial node and slice, plus waiting arcs.
Per cohort `c`, in vulnerability order, solve

```
min  Σ_{(i,j),t}  cost^c_{ij,t} · x^c_{ij,t}
s.t. flow conservation on the time-expanded graph
     Σ_c x^c_{ij,t} ≤ Q_ij            (hard capacity)
     departure only within the dispatch window
```
with `cost^c_{ij,t} = t_ij + θ_c · E_ij(t) · t_ij` (seconds), evaluated at the
capacity density so each subproblem is **linear** and exactly solvable.

## The capacity finding (new, and important)

Capacity must be set at the **flow-maximising** density, not at crush onset:

| operating point | ρ (ped/m²) | v (m/s) | throughput q (ped/m/s) |
|---|---|---|---|
| **flow-maximising ρ\*** | **1.75** | **0.700** | **1.225** |
| crush onset ρ_c | 4.0 | 0.156 | 0.625 |
| jam ρ_j | 5.4 | 0.050 | 0.270 |

Operating at crush-onset density delivers **barely half** the throughput of ρ\*,
*and* a 4.5× slower walk. **Safety and throughput are aligned, not in tension** —
a counterintuitive, operationally useful result that follows directly from the
fundamental diagram. My first implementation capped at ρ_c and was both unsafe
and slower; this is fixed.

## Complexity

Time-expanded graph: `V·T` nodes, `(E+V)·T` arcs. Network simplex is
`O(V'E' log(V'C))` with `V'=VT`, `E'=(E+V)T`, run once per cohort:

```
O( |C| · VT · (E+V)T · log(VT·C) )
```

Polynomial, and — unlike the Frank–Wolfe version — **there is no convergence gap
to report**, because min-cost flow is solved exactly.

## Honest status

**Verified working:** time-expanded construction, hard capacity, exact min-cost
flow, explicit infeasibility, adaptive horizon sizing, the capacity-point result.

**NOT verified — two things you must check on first run:**

1. **Real-network validation did not run.** The Overpass API is blocked in the
   environment where this was written, so `validate_real_network.py` is
   *untested*. Treat its first execution as a debugging run.
2. **The equity mechanism did not differentiate on the synthetic graph** — all
   four cohorts received identical mean dose (2958.8). Either the graph has too
   many equal-cost alternatives to reveal differentiation, or the residual-capacity
   subtraction is not binding. **This must be re-checked on the real network**,
   where alternatives are richer and capacity genuinely scarce. Do not claim the
   equity result until you see cohort doses actually differ.

**Still open from the critique** (honestly not addressed):
MPC/feedback control, a behavioural compliance model, crowd-turbulence and
stop-and-go dynamics beyond the steady-state fundamental diagram, Weidmann
parameters recalibrated for Hajj demographics, and validation against observed
WBGT/density/GPS.

## Run

```bash
python assignment_td.py                                  # self-test
python validate_real_network.py --risk field_prob.npy    # REAL network
python validate_real_network.py --network all            # if walk is sparse
```

`validate_real_network.py` reports network quality, the capacity operating point,
the minimum feasible dispatch window, and per-cohort doses — and writes
`real_network_validation.json`.
