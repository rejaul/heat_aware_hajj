# Heat-Aware Routing on the REAL Hajj Corridor

Runs on the **actual OpenStreetMap pedestrian network** for the ritual corridor,
using **your real predicted heat field** — no synthetic geometry.

## Why this is real data

| Component | Source |
|---|---|
| Pedestrian network | OpenStreetMap via `osmnx` (free, no credentials) |
| Heat/risk field | YOUR 2024 ECOSTRESS + ERA5-Land pipeline output |
| Ritual sites | Real coordinates (Haram, Mina, Jamarat, Muzdalifah, Arafat) |

## Step 1 — fetch the real network (once, needs internet)

```bash
pip install osmnx
python corridor_network.py
```

Fetches the walkable network over the corridor bbox and caches it to
`data/corridor_walk.graphml`. It then reports node/edge counts, how far each
ritual site snapped to its nearest OSM node, and **whether every leg of the
ritual sequence is connected**.

If some legs come back `NO PATH` (likely — OSM footway coverage is sparse over
the open plains of Arafat/Muzdalifah):

```bash
python corridor_network.py --network all --refresh
```

`all` adds service roads and tracks, which pilgrims do walk on. If legs are
still disconnected, route only the connected legs and say so in the paper.

## Step 2 — export your predicted field as a raster

Routing needs a north-up 2-D array covering `config.BBOX`. From your trained
model:

```python
import numpy as np
# q = model output, shape (Q, H, W), quantiles (0.5, 0.9, 0.95, 0.99)
np.save("field_median.npy", q[0])    # tau=0.50
np.save("field_q95.npy",    q[2])    # tau=0.95
```

For the exceedance-probability version (what the cost model wants), save
`P(WBGT > 32.2)` from the calibrated layer instead — values in [0, 1].

## Step 3 — run the routing comparison

```bash
python routing.py --risk field_median.npy --tau-risk field_q95.npy \
                  --from Mina --to Arafat --cohort unreg_75plus
```

Outputs the five-policy table, the risk-aversion Pareto frontier, and
`routing_results.json`.

## The five policies

| Policy | Objective |
|---|---|
| `shortest` | minimise distance (pilgrim default) |
| `coolest_mean` | minimise exposure dose on the median field |
| `risk_averse` | minimise dose on the **tau=0.95** field (uses your ECP layer) |
| `cohort` | risk-aversion set by cohort vulnerability |
| `congestion_coupled` | flow split over k-best paths, density raises effective heat |

## Cost model

Exposure **dose** = exceedance probability integrated over exposure time:

```
dose_ij = P(WBGT_ij > k) * length_ij / walking_speed
c_ij    = [lambda * E_ij + (1 - lambda)] * length_ij
```

`lambda=0` is the shortest path; `lambda=1` is pure exposure minimisation.
Routing on a **calibrated probability** (and on a high quantile) is the novel
part — existing thermal-routing work uses deterministic index values.

## Reading the results

- **Detour %** — benchmark against the literature: thermal routing typically
  buys large exposure cuts for detours of only ~1–3%. A much larger detour on
  your network is worth investigating (it may mean the network is sparse).
- **Dose reduction %** — the headline benefit.
- **Peak E** — the minimax view; matters for lethal thresholds.
- **Pareto frontier** — the distance/exposure trade-off as `lambda` sweeps.

## Known demo artifacts (they disappear on real data)

Running `--demo` uses a synthetic irregular graph, where:
- `risk_averse` matches `coolest_mean` because the demo tau-field is a uniform
  scaling of the median (argmin is scale-invariant). On real data the tau=0.95
  field varies spatially and the routes diverge.
- `cohort` matches `coolest_mean` because the default cohort is the most
  vulnerable (lambda=1.0). Pass `--cohort reg_18_54` to see the difference.

Verified cohort behaviour on the irregular test graph:

| Cohort | lambda | distance | dose | peak |
|---|---|---|---|---|
| reg_18_54 | 0.25 | 22039 m | 5719 | 0.614 |
| reg_55_74 | 0.42 | 22921 m | 3879 | 0.318 |
| unreg_55_74 | 0.75 | 23129 m | 3729 | 0.318 |
| unreg_75plus | 1.00 | 25204 m | 3496 | 0.166 |

The most vulnerable cohort walks 14% further but takes **39% less dose and 73%
lower peak exposure** — the equity argument made quantitative.

## Honest caveats for the paper

1. **Ritual sequence is fixed.** You optimise connecting transits only; the
   rites and their order are not re-routable.
2. **Jamarat Bridge is a known bottleneck** — respect capacity there rather
   than piling flow onto it.
3. **Congestion coupling is iterative, not an equilibrium.** Full traffic
   assignment is future work.
4. **OSM completeness varies.** Report node/edge counts and the connectivity
   check from Step 1 so reviewers know what network you routed on.
5. **Static field within a traversal.** A long walk crosses a changing field;
   time-dependent routing is the refinement.
