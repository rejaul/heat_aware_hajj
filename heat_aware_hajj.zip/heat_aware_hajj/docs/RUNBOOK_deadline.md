# DEADLINE RUNBOOK — Preliminary (Case-Study) Submission

A minimal, ordered sequence to get a **submittable proof-of-concept on real
data** before the deadline, with the full analysis deferred to camera-ready.

## The idea

`config.QUICK = True` restricts the whole pipeline to a small, fast-to-download
slice: the **2024 Hajj heat event** (the 51.8 °C event your paper is about) plus
buffer weeks, over the Mina–Arafat box. You demonstrate the *method and pipeline*
on real data at reduced scope now; you run the *full multi-season evaluation* for
camera-ready.

## Honesty contract (read first)

- Frame the submission as a **case study / proof-of-concept**, e.g. "We
  demonstrate the framework on the 2024 Hajj heat event; a full multi-season
  evaluation follows in the camera-ready version."
- **Do NOT** report return levels, tail coverage, or calibration from this slice
  as if they were the full study — too few scenes for those to be meaningful.
- Anchor the paper's contribution on the **method** (which won't change between
  versions), not on a headline number (which might). This protects you if the
  full analysis later differs.
- Clearly label every preliminary number as such, and label synthetic-data
  results (dispatch, return-level demo) as simulation.

## Step 0 — credentials (once)

- CDS: accept the ERA5-Land licence once in the browser; put the single token in
  `~/.cdsapirc` (see `download_era5land.py` docstring).
- Earthdata: `export EARTHDATA_TOKEN="<fresh-token>"` (see
  `download_ecostress.py` docstring). **Use a freshly generated token.**

## Step 1 — check ECOSTRESS coverage BEFORE downloading

```bash
python download_ecostress.py --inventory
```

This prints how many scenes exist in the 2024 case-study window WITHOUT
downloading. Decision point:

- **>= ~15 scenes** → good enough to proceed.
- **< 15 scenes** → widen `config.QUICK_RANGE` (add buffer weeks) or add a second
  year, then re-check. Extremes need enough clear overpasses.

## Step 2 — download the slice

```bash
python download_era5land.py        # small, fast; monthly chunks, resumable
python download_ecostress.py       # the case-study scenes
```

Both print a "CASE-STUDY MODE" banner so you know you're on the reduced scope.

## Step 3 — build training pairs

```bash
python align.py
```

Produces `data/pairs/*.nc`. If very few pairs survive quality masking, that's the
signal to widen the window (Step 1).

## Step 4 — run the analysis you CAN defend now

```bash
# proposed method + all baselines on the real slice (labelled preliminary)
python compare.py                        # uses real pairs if present

# the ECP finite-interval result — holds even on modest data (your strongest)
python ecp.py

# a real downscaled field + live map for the 2024 event (compelling figure)
python train.py --tile 256 --batch 8 --epochs 60    # small data -> few epochs
python heatmap.py --risk <your_field>.npy
```

`train.py` and `compare.py` print small-data warnings automatically when scene
counts are low.

## What goes in the PRELIMINARY paper

Safe to include now:
- Full methodology (complete; independent of data volume — this is most of it).
- Pipeline validated on the real 2024 slice (AMUN field + live heatmap figure).
- The ECP "split-conformal-goes-infinite vs ECP-stays-finite" result.
- Seven-method comparison table, **labelled preliminary / reduced-scope**.
- Synthetic-data results (dispatch simulation, return-level demo), **labelled
  simulation**.

Deferred to CAMERA-READY:
- Full multi-season, full-spatial training (`config.QUICK = False`).
- Threshold-stability / mean-residual-life analysis (also a misspecification
  check).
- Return-level and tail-coverage numbers on enough data to be meaningful.
- Variance across seeds, ablations.

## Switching to full mode for camera-ready

Edit one line:

```python
# config.py
QUICK = False
```

Then re-run Steps 1–4. Every script picks up the full scope automatically. You
can also force full scope per-run without editing config: `--full` on either
downloader.
