"""
Search and download ECOSTRESS tiled LST (ECO_L2T_LSTE v002, 70 m) over the
Makkah holy sites via NASA Earthdata.

Authentication (choose ONE; the token route is what you asked for)
------------------------------------------------------------------
`earthaccess` tries these in order, so set up whichever you prefer:

1. TOKEN (recommended for headless/servers)
   Generate a token at https://urs.earthdata.nasa.gov (User Profile ->
   Generate Token). Then expose it as an environment variable -- NEVER paste it
   into a file that gets shared or committed:

       export EARTHDATA_TOKEN="eyJ0eXAiOiJKV1Qi..."      # Linux / macOS
       setx  EARTHDATA_TOKEN "eyJ0eXAiOiJKV1Qi..."       # Windows (new shell)

   This script reads EARTHDATA_TOKEN and hands it to earthaccess.

2. .netrc (username/password)
       machine urs.earthdata.nasa.gov login <user> password <pass>

3. Interactive: run once and type credentials when prompted.

SECURITY: a token is a bearer credential -- anyone who has it can act as you
until it expires. Keep it in an environment variable or a secrets manager, not
in source code. If a token is ever exposed, revoke it in your Earthdata profile
and generate a new one.

Why ECOSTRESS
-------------
Unlike Landsat/MODIS (sun-synchronous, fixed overpass time), ECOSTRESS flies on
the ISS, so overpasses drift through the diurnal cycle. That is what makes it
usable as high-resolution supervision for an hourly heat model -- but it also
means acquisitions are irregular, so expect an uneven sample.

Usage
-----
    python download_ecostress.py --inventory     # list granules, download none
    python download_ecostress.py                 # download training scope
    python download_ecostress.py --hajj 2024     # just the 2024 Hajj window
"""
from __future__ import annotations

import argparse
import os
import sys
from datetime import date

import config

try:
    import earthaccess
except ImportError:  # pragma: no cover
    sys.exit("earthaccess not installed. Run: pip install earthaccess")


def season_windows(years, months):
    """Contiguous (start, end) ISO strings for each year's hot season."""
    windows = []
    for y in years:
        start = date(y, min(months), 1)
        end_month = max(months)
        last_day = 30 if end_month in (4, 6, 9, 11) else 31
        windows.append((start.isoformat(), date(y, end_month, last_day).isoformat()))
    return windows


def search(temporal):
    return earthaccess.search_data(
        short_name=config.ECOSTRESS_SHORT_NAME,
        version=config.ECOSTRESS_VERSION,
        bounding_box=config.BBOX,
        temporal=temporal,
    )


def wanted(granule_links):
    """Keep only the layers we need (tiled product ships one GeoTIFF per layer)."""
    keep = []
    for link in granule_links:
        name = link.split("/")[-1]
        if any(f"_{lyr}.tif" in name for lyr in config.ECOSTRESS_LAYERS):
            keep.append(link)
    return keep


def authenticate():
    """
    Log in to Earthdata, preferring a token from the environment.

    earthaccess reads a token from the EARTHDATA_TOKEN environment variable when
    strategy='environment' is used. We try that first, then fall back to .netrc,
    then interactive -- so the same script works headless (token) or locally.
    """
    token = os.environ.get("EARTHDATA_TOKEN")
    if token:
        # earthaccess picks up EARTHDATA_TOKEN via the 'environment' strategy.
        try:
            auth = earthaccess.login(strategy="environment")
            if auth is not None and getattr(auth, "authenticated", False):
                print("Authenticated with EARTHDATA_TOKEN.")
                return auth
        except Exception as exc:
            print(f"  [token auth failed, trying .netrc: {exc}]")

    # Fallbacks: .netrc, then interactive prompt.
    for strategy in ("netrc", "interactive"):
        try:
            auth = earthaccess.login(strategy=strategy, persist=True)
            if auth is not None and getattr(auth, "authenticated", False):
                print(f"Authenticated via {strategy}.")
                return auth
        except Exception:
            continue

    sys.exit("Earthdata authentication failed. Set EARTHDATA_TOKEN, create "
             "~/.netrc, or run interactively. See the module docstring.")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--inventory", action="store_true",
                    help="report granule counts only, do not download")
    ap.add_argument("--hajj", type=int, default=None,
                    help="restrict to one Hajj window, e.g. 2024")
    ap.add_argument("--full", action="store_true",
                    help="override config.QUICK and use the full multi-season scope")
    args = ap.parse_args()

    quick = getattr(config, "QUICK", False) and not args.hajj and not args.full

    authenticate()

    if args.hajj:
        if args.hajj not in config.HAJJ_WINDOWS:
            sys.exit(f"No Hajj window configured for {args.hajj}")
        windows = [config.HAJJ_WINDOWS[args.hajj]]
    elif quick:
        # Case-study mode: one contiguous window bracketing the 2024 event.
        windows = [config.QUICK_RANGE]
        print("=" * 66)
        print("CASE-STUDY (QUICK) MODE  -- preliminary submission scope")
        print(f"  window: {config.QUICK_RANGE[0]} .. {config.QUICK_RANGE[1]}")
        print(f"  box:    {config.BBOX}")
        print("  This is a reduced slice for a proof-of-concept submission.")
        print("  Set config.QUICK=False (or --full) for the camera-ready pull.")
        print("=" * 66)
    else:
        windows = season_windows(config.TRAIN_YEARS, config.TRAIN_MONTHS)

    total = 0
    for temporal in windows:
        results = search(temporal)
        total += len(results)
        print(f"{temporal[0]} .. {temporal[1]}: {len(results)} granules")

        if args.inventory:
            continue

        # Filter to the layers of interest to avoid pulling the full bundle.
        links = []
        for r in results:
            links.extend(wanted(r.data_links()))

        if links:
            earthaccess.download(links, str(config.RAW_ECO))

    print(f"\nTotal granules found: {total}")
    if args.inventory:
        print("Inventory only -- nothing downloaded.")
        if quick and total < 15:
            print(f"NOTE: only {total} scenes in the case-study window. If this is")
            print("too few to train, widen config.QUICK_RANGE (more buffer weeks)")
            print("or add a second year -- extremes need enough clear overpasses.")
        elif total < 15:
            print("If counts look thin, widen TRAIN_MONTHS/TRAIN_YEARS in config.py.")
    else:
        print(f"Files in {config.RAW_ECO}")


if __name__ == "__main__":
    main()
