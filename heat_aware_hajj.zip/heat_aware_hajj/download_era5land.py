"""
Download hourly ERA5-Land fields over the Makkah holy sites from the
Copernicus Climate Data Store.

Setup (one time)
----------------
1. Register at https://cds.climate.copernicus.eu and log in.
2. Copy your personal access token from your CDS profile page.
3. Create ~/.cdsapirc containing:

       url: https://cds.climate.copernicus.eu/api
       key: <your-personal-access-token>

   NOTE: the CDS moved to new infrastructure; the key is now a single token,
   NOT the old "UID:APIKEY" format. If you get a 401, this is usually why.
4. Accept the ERA5-Land licence once on the dataset's "Download" tab,
   otherwise every request is rejected.

Usage
-----
    python download_era5land.py                    # full training scope
    python download_era5land.py --year 2024        # a single year
    python download_era5land.py --years 2013 2018  # an inclusive range
    python download_era5land.py --months 1 12      # override the month range

The range form exists for station validation. The Mecca GHCN-Daily record
(SAM00041030) ends 2018-08-05, so it does not overlap a 2019-2024 pull at all;
validating ERA5 against observations requires downloading the years the station
actually covers. Use --out-dir to keep that pull separate from the training
data, so the two are not mixed by align.py.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import config

try:
    import cdsapi
except ImportError:  # pragma: no cover
    sys.exit("cdsapi not installed. Run: pip install cdsapi")

DATASET = "reanalysis-era5-land"


def area_from_bbox(bbox):
    """CDS expects [north, west, south, east]; config stores (w, s, e, n)."""
    west, south, east, north = bbox
    # Pad slightly so the coarse grid fully covers the fine tile after regrid.
    pad = 0.15
    return [north + pad, west - pad, south - pad, east + pad]


def request_month(client, year: int, month: int, out_dir=None) -> None:
    out_dir = out_dir or config.RAW_ERA5
    out = Path(out_dir) / f"era5land_{year}{month:02d}.nc"
    if out.exists():
        print(f"  [skip] {out.name} already present")
        return

    print(f"  [get ] {out.name}")
    client.retrieve(
        DATASET,
        {
            "variable": config.ERA5_VARIABLES,
            "year": str(year),
            "month": f"{month:02d}",
            "day": [f"{d:02d}" for d in range(1, 32)],
            "time": [f"{h:02d}:00" for h in range(24)],
            "area": area_from_bbox(config.BBOX),
            "data_format": "netcdf",
            "download_format": "unarchived",
        },
        str(out),
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--year", type=int, default=None,
                    help="single year (default: all TRAIN_YEARS)")
    ap.add_argument("--years", nargs=2, type=int, metavar=("FIRST", "LAST"),
                    default=None, help="inclusive year range, e.g. --years 2013 2018")
    ap.add_argument("--months", nargs=2, type=int, metavar=("FIRST", "LAST"),
                    default=None, help="inclusive month range (default: config.TRAIN_MONTHS)")
    ap.add_argument("--out-dir", default=None,
                    help="write elsewhere than config.RAW_ERA5 (keeps a "
                         "validation pull separate from training data)")
    ap.add_argument("--full", action="store_true",
                    help="override config.QUICK and pull the full scope")
    args = ap.parse_args()

    if args.year and args.years:
        sys.exit("Use --year or --years, not both.")

    quick = (getattr(config, "QUICK", False) and not args.full
             and not args.years and not args.months)

    if quick and not args.year:
        print("=" * 66)
        print("CASE-STUDY (QUICK) MODE  -- preliminary submission scope")
        print(f"  months {config.TRAIN_MONTHS} of {config.TRAIN_YEARS[0]} "
              f"over box {config.BBOX}")
        print("  Small, fast pull bracketing the 2024 event. Monthly chunks are")
        print("  resumable (already-downloaded months are skipped).")
        print("  Set config.QUICK=False (or --full) for the camera-ready pull.")
        print("=" * 66)

    if args.year:
        years = [args.year]
    elif args.years:
        a, b = sorted(args.years)
        years = list(range(a, b + 1))
    else:
        years = config.TRAIN_YEARS

    if args.months:
        a, b = sorted(args.months)
        months = list(range(a, b + 1))
    else:
        months = config.TRAIN_MONTHS

    out_dir = Path(args.out_dir) if args.out_dir else config.RAW_ERA5
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"years  : {years[0]}-{years[-1]} ({len(years)})")
    print(f"months : {months}")
    print(f"out    : {out_dir}")
    print(f"total  : {len(years) * len(months)} monthly requests\n")

    client = cdsapi.Client()

    for year in years:
        print(f"ERA5-Land {year}")
        for month in months:
            try:
                request_month(client, year, month, out_dir)
            except Exception as exc:  # keep going; CDS queues can time out
                print(f"  [fail] {year}-{month:02d}: {exc}")

    print(f"\nDone. Files in {out_dir}")


if __name__ == "__main__":
    main()
