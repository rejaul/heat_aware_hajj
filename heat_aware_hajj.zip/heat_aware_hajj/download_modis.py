"""
Download MODIS land surface temperature for the Hajj corridor.

WHY MODIS, GIVEN WE ALREADY HAVE ECOSTRESS.

ECOSTRESS gives 70 m detail, which is what routing needs, but it flies on the
ISS: the precessing orbit drifts acquisitions through the diurnal cycle, and we
measured that time of day accounts for R^2 = 0.937 of the variance in
scene-level surface temperature. That single fact undermined several analyses.
Scenes at different local hours are not exchangeable, so the conformal
calibration rests on a weakened assumption; block maxima over irregularly-timed
scenes are not comparable draws, so the GPD shape parameter was never
identified; and the record covers only 2018 onward, which does not overlap the
Makkah station record that ends in August 2018.

MODIS is the complement, not a replacement:

  fixed overpass    Terra ~10:30 and ~22:30 local, Aqua ~13:30 and ~01:30.
                    Observations at a FIXED local solar time are exchangeable
                    across days, which is exactly what block maxima and
                    conformal calibration require.
  long record       2000 (Terra) / 2002 (Aqua) to present, so it spans both the
                    station era (to 2018) and the ECOSTRESS era (2018 onward)
                    and can bridge the validation gap between them.
  daily, four looks per day.

  1 km resolution   the cost. Our corridor is 25 x 16 km, so MODIS gives about
                    25 x 16 pixels: far too coarse to distinguish routes 300 m
                    apart. MODIS cannot support the routing analysis and is not
                    used for it.

Products: MOD11A1 (Terra) and MYD11A1 (Aqua), daily 1 km LST/emissivity, with
LST in kelvin at a 0.02 scale factor and per-pixel QC.

Setup is the same as for ECOSTRESS: an Earthdata login, either via
EARTHDATA_TOKEN in the environment or a ~/.netrc entry.

Usage
-----
    python download_modis.py --inventory              # count granules first
    python download_modis.py --years 2013 2024
    python download_modis.py --years 2000 2024 --product MOD11A1
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import argparse
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

PRODUCTS = {
    "MOD11A1": ("Terra", "10:30 / 22:30"),
    "MYD11A1": ("Aqua", "13:30 / 01:30"),
}


def authenticate():
    import earthaccess
    tok = os.environ.get("EARTHDATA_TOKEN")
    if tok:
        try:
            auth = earthaccess.login(strategy="environment", persist=False)
            if auth and getattr(auth, "authenticated", False):
                print("  authenticated via EARTHDATA_TOKEN")
                return auth
        except Exception:
            pass
    try:
        auth = earthaccess.login(strategy="netrc", persist=False)
        if auth and getattr(auth, "authenticated", False):
            print("  authenticated via netrc")
            return auth
    except Exception:
        pass
    auth = earthaccess.login(strategy="interactive", persist=True)
    if not (auth and getattr(auth, "authenticated", False)):
        sys.exit("Earthdata authentication failed.")
    return auth


def search(product, bbox, year, months):
    """Granules for one product-year over the corridor, restricted to months."""
    import earthaccess
    west, south, east, north = bbox
    out = []
    for m in months:
        last = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1]
        try:
            res = earthaccess.search_data(
                short_name=product, version="061",
                bounding_box=(west, south, east, north),
                temporal=(f"{year}-{m:02d}-01", f"{year}-{m:02d}-{last:02d}"),
            )
            out.extend(res)
        except Exception as exc:
            print(f"    [warn] {product} {year}-{m:02d}: {str(exc)[:70]}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--product", nargs="+", default=list(PRODUCTS),
                    choices=list(PRODUCTS))
    ap.add_argument("--years", nargs=2, type=int, default=[2013, 2024],
                    metavar=("FIRST", "LAST"))
    ap.add_argument("--months", nargs=2, type=int, default=[5, 9],
                    metavar=("FIRST", "LAST"))
    ap.add_argument("--out", default="data/raw/modis")
    ap.add_argument("--inventory", action="store_true",
                    help="count granules without downloading")
    ap.add_argument("--bbox", help="west,south,east,north (default config.BBOX)")
    args = ap.parse_args()

    try:
        import earthaccess  # noqa: F401
    except ImportError:
        sys.exit("earthaccess not installed. Run: pip install earthaccess")

    import config
    bbox = (tuple(float(x) for x in args.bbox.split(","))
            if args.bbox else config.BBOX)
    y0, y1 = sorted(args.years)
    m0, m1 = sorted(args.months)
    months = list(range(m0, m1 + 1))

    print("=" * 74)
    print("MODIS LST DOWNLOAD")
    print("=" * 74)
    print(f"  box      : {bbox}")
    print(f"  years    : {y0}-{y1}   months: {months}")
    for p in args.product:
        sat, times = PRODUCTS[p]
        print(f"  {p:<9}: {sat}, overpass ~{times} local")
    print("  1 km resolution: suitable for time-series and tail analysis,")
    print("  NOT for routing (the corridor is only ~25 x 16 px at this scale).")

    authenticate()
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    total = 0
    for p in args.product:
        print(f"\n{p}")
        for year in range(y0, y1 + 1):
            g = search(p, bbox, year, months)
            total += len(g)
            print(f"  {year}: {len(g):>4} granules")
            if args.inventory or not g:
                continue
            sub = out_dir / p / str(year)
            sub.mkdir(parents=True, exist_ok=True)
            have = {f.name for f in sub.glob("*")}
            todo = [x for x in g
                    if x.data_links() and
                    Path(x.data_links()[0]).name not in have]
            if not todo:
                print(f"        all present, skipping")
                continue
            print(f"        downloading {len(todo)}")
            try:
                import earthaccess
                earthaccess.download(todo, str(sub))
            except Exception as exc:
                print(f"        [fail] {str(exc)[:70]}")

    print(f"\nTotal granules found: {total}")
    if args.inventory:
        print("Inventory only -- nothing downloaded.")
    else:
        print(f"Files under {out_dir}")
        print("\nNext: python modis_analysis.py")


if __name__ == "__main__":
    main()
