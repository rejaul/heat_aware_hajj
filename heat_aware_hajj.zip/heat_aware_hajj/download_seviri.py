"""
Download SEVIRI 15-minute land surface temperature from LSA SAF.

FILE LAYOUT (confirmed against the live service):

    https://datalsasaf.lsasvcs.ipma.pt/PRODUCTS/MSG/MLST/HDF5/
        <YYYY>/<MM>/<DD>/HDF5_LSASAF_MSG_LST_MSG-Disk_<YYYYMMDDhhmm>

Two things matter here. The product is **MSG-Disk**, the full disk, not a
regional subset, so the corridor window computed by msg_window.py applies
directly with no origin offset: lines 2580-2588, columns 646-656. And the files
carry no extension, so a glob on *.h5 finds nothing; seviri_tail.py also
matches names containing HDF5, which these do.

VOLUME. Slots are every 15 minutes, so a full day is 96 files and a day
restricted to daylight is 52. One Hajj week of daytime slots is about 364
files. Start with a single day, confirm the window, then widen.

CREDENTIALS come from the environment, never the command line, so they do not
land in a shell history:

    $env:LSASAF_USER = "..."
    $env:LSASAF_PASS = "..."

Usage
-----
    python download_seviri.py --date 2024-06-14 --day-only
    python download_seviri.py --start 2024-06-14 --end 2024-06-19 --day-only
    python download_seviri.py --date 2024-06-14 --slots 1200 1215 1230
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path

BASE = "https://datalsasaf.lsasvcs.ipma.pt/PRODUCTS/MSG/MLST/HDF5"
UTC_OFFSET_H = 3.0          # Makkah local = UTC + 3


def slots_for(day_only, lo_local=6.0, hi_local=19.0):
    """Every 15-minute slot, as HHMM strings in UTC."""
    out = []
    for h in range(24):
        for m in (0, 15, 30, 45):
            loc = (h + UTC_OFFSET_H) % 24.0 + m / 60.0
            if day_only and not (lo_local <= loc <= hi_local):
                continue
            out.append(f"{h:02d}{m:02d}")
    return out


def fetch(url, dest, user, pw, retries=3):
    import urllib.request
    import base64
    if dest.exists() and dest.stat().st_size > 100_000:
        return "skip"
    req = urllib.request.Request(url)
    tok = base64.b64encode(f"{user}:{pw}".encode()).decode()
    req.add_header("Authorization", f"Basic {tok}")
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                body = r.read()
            if len(body) < 100_000:
                return f"too small ({len(body)} B)"
            dest.write_bytes(body)
            return "ok"
        except Exception as e:
            if attempt == retries - 1:
                return str(e)[:60]
            time.sleep(2 * (attempt + 1))
    return "failed"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", help="single day, YYYY-MM-DD")
    ap.add_argument("--start")
    ap.add_argument("--end")
    ap.add_argument("--slots", nargs="+", help="specific HHMM slots in UTC")
    ap.add_argument("--day-only", action="store_true",
                    help="restrict to 06:00-19:00 local")
    ap.add_argument("--out", default="data/raw/seviri")
    args = ap.parse_args()

    user = os.environ.get("LSASAF_USER")
    pw = os.environ.get("LSASAF_PASS")
    if not (user and pw):
        sys.exit("Set LSASAF_USER and LSASAF_PASS in the environment first.")

    if args.date:
        days = [datetime.strptime(args.date, "%Y-%m-%d").date()]
    elif args.start and args.end:
        a = datetime.strptime(args.start, "%Y-%m-%d").date()
        b = datetime.strptime(args.end, "%Y-%m-%d").date()
        days = [a + timedelta(days=i) for i in range((b - a).days + 1)]
    else:
        sys.exit("Give --date, or --start and --end.")

    slots = args.slots if args.slots else slots_for(args.day_only)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("SEVIRI MLST DOWNLOAD")
    print("=" * 70)
    print(f"  days  : {days[0]} to {days[-1]}  ({len(days)})")
    print(f"  slots : {len(slots)} per day"
          f"{' (daylight only)' if args.day_only else ''}")
    print(f"  total : {len(days) * len(slots)} files")
    print(f"  out   : {out}")
    print("  product MSG-Disk (full disk): the msg_window.py window applies")
    print("  directly, lines 2580-2588 and columns 646-656.\n")

    n_ok = n_skip = n_fail = 0
    for d in days:
        sub = out / f"{d:%Y%m%d}"
        sub.mkdir(exist_ok=True)
        for s in slots:
            name = f"HDF5_LSASAF_MSG_LST_MSG-Disk_{d:%Y%m%d}{s}"
            url = f"{BASE}/{d:%Y}/{d:%m}/{d:%d}/{name}"
            r = fetch(url, sub / name, user, pw)
            if r == "ok":
                n_ok += 1
            elif r == "skip":
                n_skip += 1
            else:
                n_fail += 1
                if n_fail <= 5:
                    print(f"  [fail] {name}: {r}")
        print(f"  {d}: {n_ok} downloaded, {n_skip} already present, "
              f"{n_fail} failed")

    print(f"\n  done: {n_ok} new, {n_skip} present, {n_fail} failed")
    if n_fail and n_ok == 0:
        print("\n  Nothing downloaded. Check the credentials, and confirm the")
        print("  path in a browser before a larger pull.")
    else:
        print("\n  Next:")
        print("    python msg_window.py --file "
              f"{out}/{days[0]:%Y%m%d}/<one file>")
        print("    python seviri_tail.py --window 2580 2588 646 656")


if __name__ == "__main__":
    main()
