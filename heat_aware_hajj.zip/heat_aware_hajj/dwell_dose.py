"""
Cumulative thermal exposure across the pilgrimage: travel against dwell.

THE OMISSION THIS ADDRESSES. Our assignment integrates exposure over TRAVEL
time only:  dose = E * t_travel. But the Hajj is mostly stationary. Pilgrims
stand at Arafat for an afternoon and stay at Mina for three nights, against
perhaps eight hours of walking in total. If stationary exposure is anything
other than negligible, it dominates, and a model that optimises movement is
managing a minority of the hazard.

The corrected accounting is

    dose = E_travel * t_travel  +  sum over sites of  E_site * t_dwell_site

where t_dwell comes from ritual timing, not from the assignment: the duration
of the stand at Arafat is fixed by the rite, and no routing decision changes it.

WHAT THIS SCRIPT CAN AND CANNOT DO. Travel exposure is measured: it comes from
the calibrated field sampled along real network edges. Dwell exposure is NOT
measured, and this is the crux. Satellite land surface temperature sees the
tent roof at Mina, not the conditions beneath it, and many tents are
air-conditioned. We therefore treat dwell exposure as an interval and propagate
it, rather than asserting a value. The output is a decomposition with explicit
uncertainty on the dominant term, which is the honest form of the result.

The headline this produces is not a number but a ratio: what share of
cumulative exposure is addressable by routing at all.

Run:
    python dwell_dose.py
    python dwell_dose.py --mina-exposure 0.20 0.55      # tighten the interval
    python dwell_dose.py --field field_prob.npy         # use the real field
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import warnings

warnings.filterwarnings("ignore")

import numpy as np

# Ritual phases. Durations are set by the rite, not by any routing decision.
# Hours are nominal and vary by group; the sweep below is what matters.
PHASES = [
    # name,                       kind,     hours, notes
    ("Haram to Mina",             "travel",   2.0, "8 Dhul-Hijjah"),
    ("Mina, day 1 and night",     "dwell",   18.0, "tents, partly air-conditioned"),
    ("Mina to Arafat",            "travel",   3.0, "the long leg"),
    ("Arafat, the standing",      "dwell",    6.5, "open plain, noon to sunset"),
    ("Arafat to Muzdalifah",      "travel",   2.5, "after sunset"),
    ("Muzdalifah, overnight",     "dwell",    8.0, "open ground, but night"),
    ("Muzdalifah to Mina",        "travel",   2.0, "pre-dawn"),
    ("Mina, days 2 to 4",         "dwell",   42.0, "tents; includes nights"),
    ("Mina to Jamarat, three times", "travel", 2.0, "the stoning"),
]

# Exposure intervals for the dwell phases, as [low, high]. These are NOT
# measurements. Arafat is open ground at peak heat, so its interval is high and
# narrow. Mina spans air-conditioned tents through unshaded ground over three
# days and nights, so its interval is wide and is the dominant uncertainty.
# Muzdalifah is open but overnight.
DWELL_E = {
    "Mina, day 1 and night": (0.20, 0.55),
    "Arafat, the standing": (0.62, 0.74),
    "Muzdalifah, overnight": (0.15, 0.35),
    "Mina, days 2 to 4": (0.20, 0.55),
}


def travel_exposure(field_path=None, default=0.61):
    """Mean exceedance along the corridor; measured if a field is supplied."""
    if field_path and os.path.exists(field_path):
        f = np.load(field_path)
        return float(np.nanmean(f)), "measured from " + os.path.basename(field_path)
    return default, "assumed (corridor mean from the paper)"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--field", default="field_prob.npy")
    ap.add_argument("--mina-exposure", nargs=2, type=float, default=None,
                    metavar=("LO", "HI"))
    ap.add_argument("--arafat-exposure", nargs=2, type=float, default=None,
                    metavar=("LO", "HI"))
    ap.add_argument("--n-draws", type=int, default=20000)
    args = ap.parse_args()

    if args.mina_exposure:
        DWELL_E["Mina, day 1 and night"] = tuple(args.mina_exposure)
        DWELL_E["Mina, days 2 to 4"] = tuple(args.mina_exposure)
    if args.arafat_exposure:
        DWELL_E["Arafat, the standing"] = tuple(args.arafat_exposure)

    E_tr, src = travel_exposure(args.field)

    print("=" * 78)
    print("CUMULATIVE EXPOSURE: TRAVEL AGAINST DWELL")
    print("=" * 78)
    print(f"  travel exposure: {E_tr:.3f}  ({src})")
    print("  dwell exposure : intervals, NOT measured. Satellite LST sees the")
    print("  tent roof at Mina, not the conditions beneath it.")

    print(f"\n  {'phase':<32}{'kind':>8}{'hours':>8}{'exposure':>16}{'dose':>16}")
    print("  " + "-" * 76)
    rows, t_travel, t_dwell = [], 0.0, 0.0
    for name, kind, hrs, note in PHASES:
        if kind == "travel":
            lo = hi = E_tr
            t_travel += hrs
        else:
            lo, hi = DWELL_E.get(name, (0.3, 0.6))
            t_dwell += hrs
        d_lo, d_hi = lo * hrs, hi * hrs
        rows.append({"phase": name, "kind": kind, "hours": hrs,
                     "e_lo": lo, "e_hi": hi, "dose_lo": d_lo, "dose_hi": d_hi})
        e_s = f"{lo:.2f}" if lo == hi else f"{lo:.2f}-{hi:.2f}"
        d_s = f"{d_lo:.2f}" if d_lo == d_hi else f"{d_lo:.1f}-{d_hi:.1f}"
        print(f"  {name:<32}{kind:>8}{hrs:>8.1f}{e_s:>16}{d_s:>16}")

    # ---- Monte Carlo over the dwell intervals ----
    rng = np.random.default_rng(0)
    n = args.n_draws
    tot = np.zeros(n); trav = np.zeros(n)
    for r in rows:
        if r["kind"] == "travel":
            d = np.full(n, r["dose_lo"])
            trav += d
        else:
            e = rng.uniform(r["e_lo"], r["e_hi"], n)
            d = e * r["hours"]
        tot += d
    share = 100.0 * trav / tot

    print("  " + "-" * 76)
    print(f"  {'hours walking':<32}{t_travel:>16.1f}")
    print(f"  {'hours stationary':<32}{t_dwell:>16.1f}"
          f"   ({t_dwell/t_travel:.1f}x longer)")

    print(f"\n  CUMULATIVE DOSE")
    print(f"    travel      {trav.mean():8.2f}")
    print(f"    total       {tot.mean():8.2f}   "
          f"(90% interval {np.percentile(tot,5):.1f} to {np.percentile(tot,95):.1f})")
    print(f"\n  SHARE OF EXPOSURE ARISING DURING TRAVEL")
    print(f"    {share.mean():.1f}%   "
          f"(90% interval {np.percentile(share,5):.1f}% to "
          f"{np.percentile(share,95):.1f}%)")

    print("\n" + "=" * 78)
    print("READING THIS")
    print("=" * 78)
    print(f"  Routing, scheduling and capacity decisions act on travel exposure")
    print(f"  only, which is about {share.mean():.0f}% of the cumulative total. The")
    print("  remainder accrues while pilgrims are stationary, and its magnitude")
    print("  depends on accommodation conditions the model cannot observe.")
    print("\n  TWO CONSEQUENCES, AND THEY PULL DIFFERENT WAYS.")
    print("  The capacity result is UNAFFECTED: it concerns throughput and")
    print("  crush risk during movement, where the fundamental diagram applies,")
    print("  and the 4.5-fold dose multiplication at crush density is a")
    print("  statement about travel dose specifically.")
    print("  But any claim about REDUCING A PILGRIM'S TOTAL HEAT BURDEN through")
    print("  movement decisions is bounded by the share above. Shade and cooling")
    print("  at the sites themselves act on the larger term.")

    # sensitivity: how much would the conclusion move if Mina were well cooled?
    print("\n  SENSITIVITY TO MINA ACCOMMODATION")
    for lo, hi, lbl in ((0.05, 0.15, "well air-conditioned"),
                        (0.20, 0.55, "mixed (default)"),
                        (0.50, 0.70, "largely unshaded")):
        t2 = np.zeros(n)
        for r in rows:
            if r["kind"] == "travel":
                t2 += r["dose_lo"]
            elif r["phase"].startswith("Mina,"):
                t2 += rng.uniform(lo, hi, n) * r["hours"]
            else:
                t2 += rng.uniform(r["e_lo"], r["e_hi"], n) * r["hours"]
        print(f"    {lbl:<22} travel share {100*np.mean(trav/t2):5.1f}%")
    print("  The span above is the single largest uncertainty in the pilgrimage's")
    print("  thermal budget, and it is a measurement question, not a modelling one.")

    json.dump({"travel_exposure": E_tr, "rows": rows,
               "travel_share_pct_mean": float(share.mean()),
               "travel_share_pct_p05": float(np.percentile(share, 5)),
               "travel_share_pct_p95": float(np.percentile(share, 95)),
               "hours_travel": t_travel, "hours_dwell": t_dwell},
              open("dwell_dose.json", "w"), indent=2)
    print("\n  results -> dwell_dose.json")


if __name__ == "__main__":
    main()
