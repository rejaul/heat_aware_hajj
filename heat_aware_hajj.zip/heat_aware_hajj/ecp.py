"""
Extreme Conformal Prediction (ECP) with generalized-Pareto profile-likelihood
calibration, plus seasonal reweighting.

Why not plain split conformal
-----------------------------
Split conformal takes the ceil((1-alpha)(n+1))-th order statistic of the
calibration scores. If that index exceeds n -- which happens whenever
alpha < 1/(n+1), or whenever you ask about an event more extreme than anything
in calibration -- the interval is unbounded and the method tells you nothing.
That is precisely the regime of a record-breaking heat event.

ECP instead models the *tail of the score distribution* with a GPD and takes the
conformal correction from a profile-likelihood upper confidence bound on the
required high quantile. The bound stays finite beyond the observed range and
carries its own uncertainty about the tail shape.

Reference: Pasche, Lam & Engelke, "Extreme conformal prediction", Extremes 2026.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import optimize, stats


# ---------------------------------------------------------------------------
# Generalized Pareto fitting
# ---------------------------------------------------------------------------


def gpd_nll(params, excesses, weights=None):
    """Negative log-likelihood of the GPD for excesses over a threshold."""
    log_scale, xi = params
    scale = np.exp(log_scale)
    z = excesses / scale

    if xi > -1e-8:
        arg = 1.0 + xi * z
        if np.any(arg <= 0):
            return np.inf
        ll = -np.log(scale) - (1.0 + 1.0 / xi) * np.log(arg)
    else:  # exponential limit
        ll = -np.log(scale) - z

    if weights is not None:
        return -np.sum(weights * ll)
    return -np.sum(ll)


def fit_gpd(excesses, weights=None):
    """MLE for (scale, shape). Returns (scale, xi, nll)."""
    excesses = np.asarray(excesses, dtype=float)
    excesses = excesses[excesses > 0]
    if excesses.size < 10:
        raise ValueError(f"Too few exceedances to fit a GPD: {excesses.size}")

    x0 = [np.log(excesses.mean()), 0.1]
    res = optimize.minimize(gpd_nll, x0, args=(excesses, weights),
                            method="Nelder-Mead",
                            options={"xatol": 1e-8, "fatol": 1e-8,
                                     "maxiter": 5000})
    log_scale, xi = res.x
    return float(np.exp(log_scale)), float(xi), float(res.fun)


def gpd_quantile(p_exceed, scale, xi, threshold, zeta_u):
    """
    Quantile of the full distribution at exceedance probability `p_exceed`,
    given P(X > u) = zeta_u.

        x_p = u + (scale/xi) * [ (p_exceed/zeta_u)^(-xi) - 1 ]
    """
    ratio = p_exceed / zeta_u
    if abs(xi) < 1e-8:
        return threshold + scale * (-np.log(ratio))
    return threshold + (scale / xi) * (ratio ** (-xi) - 1.0)


# ---------------------------------------------------------------------------
# Profile likelihood
# ---------------------------------------------------------------------------


def profile_quantile_bound(excesses, p_exceed, zeta_u, threshold,
                           conf=0.95, weights=None):
    """
    Upper confidence bound on the high quantile x_p via profile likelihood.

    We reparameterise the GPD in terms of the target quantile, profile out the
    shape, and invert the likelihood-ratio test:

        2 [ l(x_hat) - l(x) ] <= chi2_{1, conf}

    Returns (point_estimate, upper_bound).
    """
    excesses = np.asarray(excesses, dtype=float)
    excesses = excesses[excesses > 0]

    scale_hat, xi_hat, nll_hat = fit_gpd(excesses, weights)
    x_hat = gpd_quantile(p_exceed, scale_hat, xi_hat, threshold, zeta_u)
    ratio = p_exceed / zeta_u

    def scale_from_quantile(xq, xi):
        """Scale implied by a target quantile and a shape."""
        excess_q = xq - threshold
        if excess_q <= 0:
            return None
        if abs(xi) < 1e-8:
            return excess_q / (-np.log(ratio))
        denom = (ratio ** (-xi) - 1.0)
        if abs(denom) < 1e-12:
            return None
        val = excess_q * xi / denom
        return val if val > 0 else None

    def profile_nll(xq):
        """Minimise the NLL over xi with the quantile held fixed."""
        best = np.inf
        for xi_try in np.linspace(-0.45, 0.75, 61):
            sc = scale_from_quantile(xq, xi_try)
            if sc is None:
                continue
            val = gpd_nll([np.log(sc), xi_try], excesses, weights)
            if np.isfinite(val) and val < best:
                best = val
        return best

    crit = stats.chi2.ppf(conf, df=1) / 2.0

    def gap(xq):
        return profile_nll(xq) - nll_hat - crit

    # Expand upward until the likelihood-ratio threshold is crossed.
    lo, hi = x_hat, x_hat
    step = max(0.1 * abs(x_hat - threshold), 1e-3)
    for _ in range(200):
        hi += step
        if gap(hi) > 0:
            break
        step *= 1.35
    else:
        return float(x_hat), float(hi)

    try:
        upper = optimize.brentq(gap, lo, hi, xtol=1e-6, maxiter=200)
    except ValueError:
        upper = hi
    return float(x_hat), float(upper)


# ---------------------------------------------------------------------------
# Seasonal weighting
# ---------------------------------------------------------------------------


def seasonal_weights(doys, target_doy, period=365.25, sharpness=1.0):
    """
    Periodic kernel upweighting calibration points from thermally similar times
    of year, restoring approximate exchangeability within the regime of interest.
    """
    doys = np.asarray(doys, dtype=float)
    phase = 2.0 * np.pi * (doys - target_doy) / period
    w = 0.5 * (1.0 + np.cos(phase)) ** sharpness
    return w / w.mean()


# ---------------------------------------------------------------------------
# The calibrator
# ---------------------------------------------------------------------------


@dataclass
class ECPResult:
    correction: float
    method: str
    finite: bool
    threshold: float | None = None
    xi: float | None = None
    scale: float | None = None


class ExtremeConformalCalibrator:
    """
    Parameters
    ----------
    alpha : miscoverage level (0.1 -> 90% intervals)
    threshold_q : quantile of the calibration scores used as the GPD threshold
    conf : confidence level for the profile-likelihood bound
    """

    def __init__(self, alpha: float = 0.1, threshold_q: float = 0.90,
                 conf: float = 0.95):
        self.alpha = alpha
        self.threshold_q = threshold_q
        self.conf = conf
        self.scores_: np.ndarray | None = None
        self.doys_: np.ndarray | None = None

    def fit(self, scores, doys=None):
        self.scores_ = np.asarray(scores, dtype=float)
        self.doys_ = None if doys is None else np.asarray(doys, dtype=float)
        return self

    # -- baseline ---------------------------------------------------------
    def split_conformal(self, alpha=None) -> ECPResult:
        alpha = self.alpha if alpha is None else alpha
        s = np.sort(self.scores_)
        n = s.size
        k = int(np.ceil((1.0 - alpha) * (n + 1)))
        if k > n:
            # The classic failure: required order statistic does not exist.
            return ECPResult(np.inf, "split", finite=False)
        return ECPResult(float(s[k - 1]), "split", finite=True)

    # -- ECP --------------------------------------------------------------
    def extreme_conformal(self, alpha=None, target_doy=None) -> ECPResult:
        alpha = self.alpha if alpha is None else alpha
        s = self.scores_
        n = s.size

        weights = None
        if target_doy is not None and self.doys_ is not None:
            weights = seasonal_weights(self.doys_, target_doy)

        u = np.quantile(s, self.threshold_q)
        mask = s > u
        excesses = s[mask] - u
        w_ex = None if weights is None else weights[mask]
        zeta_u = (w_ex.sum() / weights.sum() if weights is not None
                  else mask.sum() / n)

        try:
            point, upper = profile_quantile_bound(
                excesses, p_exceed=alpha, zeta_u=zeta_u, threshold=u,
                conf=self.conf, weights=w_ex)
            scale, xi, _ = fit_gpd(excesses, w_ex)
        except (ValueError, RuntimeError) as exc:
            raise RuntimeError(f"ECP calibration failed: {exc}") from exc

        return ECPResult(float(upper), "ecp", finite=np.isfinite(upper),
                         threshold=float(u), xi=float(xi), scale=float(scale))

    def interval(self, prediction, alpha=None, target_doy=None):
        r = self.extreme_conformal(alpha, target_doy)
        return prediction - r.correction, prediction + r.correction, r


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    rng = np.random.default_rng(0)

    # Heavy-tailed residuals, as heat-model errors behave under extremes.
    n = 800
    scores = np.abs(stats.t.rvs(df=3, size=n, random_state=1)) * 1.2
    doys = rng.uniform(120, 260, size=n)

    cal = ExtremeConformalCalibrator(alpha=0.10, threshold_q=0.90).fit(scores, doys)

    print("=" * 62)
    print(f"calibration n = {n}   (split conformal fails when alpha < {1/(n+1):.5f})")
    print("=" * 62)
    print(f"{'alpha':>8} | {'split':>12} | {'ECP':>12} | {'xi':>6}")
    print("-" * 62)
    for a in [0.10, 0.05, 0.01, 0.002, 0.001, 0.0005]:
        sp = cal.split_conformal(a)
        ec = cal.extreme_conformal(a)
        sp_s = f"{sp.correction:12.3f}" if sp.finite else f"{'INFINITE':>12}"
        print(f"{a:8.4f} | {sp_s} | {ec.correction:12.3f} | {ec.xi:6.3f}")

    print("\nSeasonal reweighting (alpha = 0.01):")
    for doy, label in [(160, "mid-June, Hajj window"), (250, "September")]:
        r = cal.extreme_conformal(0.01, target_doy=doy)
        print(f"  target doy {doy:3d} ({label:22s}) -> correction {r.correction:7.3f}")

    print("\nEmpirical coverage check (alpha = 0.10, 400 trials):")
    hits_sp = hits_ec = 0
    trials = 400
    for t in range(trials):
        s_cal = np.abs(stats.t.rvs(df=3, size=300, random_state=100 + t)) * 1.2
        s_new = np.abs(stats.t.rvs(df=3, size=1, random_state=9000 + t))[0] * 1.2
        c = ExtremeConformalCalibrator(alpha=0.10).fit(s_cal)
        hits_sp += s_new <= c.split_conformal().correction
        hits_ec += s_new <= c.extreme_conformal().correction
    print(f"  split conformal : {hits_sp/trials:.3f}  (nominal 0.900)")
    print(f"  ECP             : {hits_ec/trials:.3f}  (nominal 0.900)")
