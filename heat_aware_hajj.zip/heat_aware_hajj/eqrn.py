"""
EQRN -- Extreme Quantile Regression Network (benchmark).

Reference: Pasche, O.C. & Engelke, S. (2024). "Neural networks for extreme
quantile regression with an application to forecasting of flood risk."
Ann. Appl. Stat. 18(4), 2818-2839.

Idea (as adapted here): rather than predicting a quantile directly with pinball
loss, the network predicts the GPD tail PARAMETERS -- scale sigma(x) and shape
xi(x) -- of the exceedance distribution above an intermediate threshold u(x).
Extreme quantiles are then recovered analytically from the fitted tail, which
lets the model EXTRAPOLATE beyond the highest observed quantile. This is the
theoretically-grounded counterpart to the pinball head, and it shares the SAME
GPD tail law as the ECP calibration layer -- so the pipeline is internally
consistent.

This is a faithful, compact re-implementation for benchmarking, not the authors'
exact code. It uses the same AMUN backbone so the comparison is like-for-like:
the ONLY differences from the proposed method are the head (GPD parameters vs
quantile levels) and the loss (GPD orthogonal NLL vs pinball).
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from model import ResBlock, Down, Up


class EQRN(nn.Module):
    """
    AMUN backbone with a GPD-tail head.

    The intermediate threshold u(x) is supplied per pixel (e.g. a high empirical
    quantile of the coarse field, or a fixed level on the baseline). The head
    predicts (log sigma, xi) so that, for exceedances y > u,

        y - u | y > u  ~  GPD(sigma(x), xi(x)).

    Extreme quantiles are recovered by `extreme_quantile`.
    """

    def __init__(self, in_ch: int, base: int = 48, depth: int = 4,
                 dropout: float = 0.05, xi_max: float = 0.6):
        super().__init__()
        self.depth = depth
        self.xi_max = xi_max

        chs = [base * (2 ** i) for i in range(depth + 1)]
        self.stem = ResBlock(in_ch, chs[0], dropout)
        self.downs = nn.ModuleList(
            [Down(chs[i], chs[i + 1], dropout) for i in range(depth)])
        self.ups = nn.ModuleList(
            [Up(chs[i + 1], chs[i], chs[i], dropout)
             for i in reversed(range(depth))])
        self.head = nn.Conv2d(chs[0], 2, 1)            # (log_sigma, xi_raw)
        nn.init.zeros_(self.head.weight)
        nn.init.constant_(self.head.bias[0], 0.0)      # sigma ~ 1
        nn.init.constant_(self.head.bias[1], 0.0)      # xi ~ 0

    def forward(self, x):
        h = self.stem(x)
        skips = [h]
        for d in self.downs:
            h = d(h); skips.append(h)
        h = skips[-1]
        for i, u in enumerate(self.ups):
            h, _ = u(h, skips[-(i + 2)])
        out = self.head(h)
        log_sigma = out[:, 0:1].clamp(-7.0, 5.0)
        # bounded shape: (-xi_max, xi_max), tanh-squashed for stability
        xi = self.xi_max * torch.tanh(out[:, 1:2])
        return log_sigma, xi

    def extreme_quantile(self, log_sigma, xi, u, zeta_u, tau):
        """
        Recover the tau-quantile of the full variable from the GPD tail:

            Q(tau) = u + (sigma/xi) [ ((1-tau)/zeta_u)^(-xi) - 1 ]

        zeta_u = P(Y > u), the exceedance rate at the threshold.
        """
        sigma = torch.exp(log_sigma)
        ratio = (1.0 - tau) / zeta_u
        ratio = torch.as_tensor(ratio, dtype=sigma.dtype, device=sigma.device)
        small = xi.abs() < 1e-4
        gpd = u + (sigma / xi.clamp_min(1e-4)) * (ratio ** (-xi) - 1.0)
        expo = u - sigma * torch.log(ratio)
        return torch.where(small, expo, gpd)


def gpd_nll_orthogonal(log_sigma, xi, excesses, mask):
    """
    Negative log-likelihood of the GPD over threshold exceedances, using the
    orthogonal (sigma, xi) parameterisation for numerical stability. Only pixels
    that (a) are valid and (b) exceed the threshold contribute.

    excesses: (B,1,H,W) = max(y - u, 0)   mask: valid-and-exceeding indicator
    """
    m = mask.float()
    denom = m.sum().clamp_min(1.0)
    sigma = torch.exp(log_sigma)
    z = excesses / sigma
    xi_safe = xi.clamp(min=-0.45)
    arg = 1.0 + xi_safe * z
    arg = arg.clamp_min(1e-6)
    # GPD log-density for xi != 0
    ll = -log_sigma - (1.0 + 1.0 / xi_safe.clamp_min(1e-4)) * torch.log(arg)
    # exponential limit where |xi| tiny
    ll_exp = -log_sigma - z
    small = xi.abs() < 1e-4
    ll = torch.where(small, ll_exp, ll)
    return -(ll * m).sum() / denom


if __name__ == "__main__":
    torch.manual_seed(0)
    net = EQRN(in_ch=11)
    x = torch.randn(2, 11, 128, 128)
    log_sigma, xi = net(x)
    print(f"parameters : {sum(p.numel() for p in net.parameters())/1e6:.2f} M")
    print(f"log_sigma  : {tuple(log_sigma.shape)}  xi: {tuple(xi.shape)}")
    print(f"xi range   : [{float(xi.min()):.3f}, {float(xi.max()):.3f}]  "
          f"(bounded by +/- {net.xi_max})")

    u = torch.zeros_like(log_sigma)
    zeta = 0.10
    for tau in (0.95, 0.99, 0.999):
        q = net.extreme_quantile(log_sigma, xi, u, zeta, tau)
        print(f"  tau={tau:.3f}: mean recovered quantile = {float(q.mean()):+.3f}")
    print("EQRN extrapolates to tau=0.999 (beyond any calibration quantile) "
          "-- the point of the GPD head.")
