"""
Censored EQRN -- GPD-tail downscaling head with an augmented CENSORING channel.

This adapts the augmented-indicator idea of Richards et al. (2024, JMLR 25:1-49,
"Neural Bayes estimators for censored inference with peaks-over-threshold
models") to the extreme-quantile DOWNSCALING setting.

The idea, ported to our problem
-------------------------------
In peaks-over-threshold estimation, below-threshold values bias the tail fit, so
the standard remedy is to CENSOR them -- treat sub-threshold cells as "known to
be below u(x), exact value unimportant". Richards et al. encode this for a neural
network by ADDING AN INDICATOR CHANNEL that marks which cells are exceedances,
and replacing censored values with a constant outside the observable range, so
the network learns to treat the two cell types differently.

Here we do the same for the GPD-headed downscaler:
  * an extra input channel I(s) = 1 if the coarse signal at s is in the tail
    (above a covariate-anchored threshold), else 0;
  * the GPD negative log-likelihood is evaluated ONLY over exceeding (uncensored)
    cells, so censored cells inform the network via the indicator but do not
    enter the tail likelihood.

This is the principled version of the covariate-anchoring fix used earlier: the
indicator tells the network WHERE the tail lives, so the GPD scale/shape are
learned from genuine exceedances only, reducing the "extremes in the wrong
place" failure mode.

NOTE ON SCOPE
-------------
On the quantile (pinball) head this trick is largely unnecessary -- pinball loss
does not suffer the below-threshold contamination that censoring addresses. It
belongs on the GPD/EQRN head, which is where this module puts it. On a small
(single-season) sample with a near-light tail, expect a MODEST effect; the value
is methodological (a principled, citable censoring mechanism), not necessarily a
large metric gain. Report it honestly.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from model import ResBlock, Down, Up


def build_censoring_channel(anchor, margin=0.5):
    """
    Build the censoring indicator from a covariate-driven anchor field.

    anchor : (B,1,H,W) standardized per-pixel threshold proxy u(x)
             (e.g. a cheap linear/quantile fit of the field on covariates).
    margin : how far above the anchor a cell must sit to count as an exceedance.

    Returns (indicator, threshold) where indicator = 1 for tail cells.
    In practice the indicator is computed from the OBSERVED coarse field at train
    time; at inference the same anchor is used so the channel is always available.
    """
    thr = anchor + margin
    return thr


class CensoredEQRN(nn.Module):
    """
    AMUN backbone + GPD-tail head + augmented censoring channel.

    Input:  covariates x (B, c, H, W)  and  a censoring indicator (B,1,H,W).
    The indicator is concatenated as an extra input channel, so the backbone
    sees `in_ch + 1` channels. Output: (log_sigma, xi) fields for the GPD tail.
    """

    def __init__(self, in_ch: int, base: int = 48, depth: int = 4,
                 dropout: float = 0.05, xi_max: float = 0.3):
        super().__init__()
        self.depth = depth
        self.xi_max = xi_max

        chs = [base * (2 ** i) for i in range(depth + 1)]
        # +1 input channel for the censoring indicator
        self.stem = ResBlock(in_ch + 1, chs[0], dropout)
        self.downs = nn.ModuleList(
            [Down(chs[i], chs[i + 1], dropout) for i in range(depth)])
        self.ups = nn.ModuleList(
            [Up(chs[i + 1], chs[i], chs[i], dropout)
             for i in reversed(range(depth))])
        self.head = nn.Conv2d(chs[0], 2, 1)
        nn.init.zeros_(self.head.weight)
        nn.init.constant_(self.head.bias[0], 0.0)   # sigma ~ 1
        nn.init.constant_(self.head.bias[1], 0.0)   # xi ~ 0

    def forward(self, x, indicator):
        # concatenate the censoring indicator as an extra channel
        h = torch.cat([x, indicator], dim=1)
        h = self.stem(h)
        skips = [h]
        for d in self.downs:
            h = d(h); skips.append(h)
        h = skips[-1]
        for i, u in enumerate(self.ups):
            h, _ = u(h, skips[-(i + 2)])
        out = self.head(h)
        log_sigma = out[:, 0:1].clamp(-2.0, 2.0)
        xi = self.xi_max * torch.tanh(out[:, 1:2])
        return log_sigma, xi

    def extreme_quantile(self, log_sigma, xi, u, zeta_u, tau):
        """Recover the tau-quantile of the full variable from the GPD tail."""
        sigma = torch.exp(log_sigma)
        ratio = torch.as_tensor((1.0 - tau) / zeta_u, dtype=sigma.dtype,
                                device=sigma.device)
        xi_c = xi.clamp(-0.3, 0.3)
        small = xi_c.abs() < 1e-4
        gpd = u + (sigma / xi_c.clamp_min(1e-4)) * (ratio ** (-xi_c) - 1.0)
        expo = u - sigma * torch.log(ratio)
        return torch.where(small, expo, gpd)


def censored_gpd_nll(log_sigma, xi, excesses, cens_mask):
    """
    GPD negative log-likelihood over UNCENSORED (exceeding) cells only.

    cens_mask : (B,1,H,W) = 1 for exceeding/uncensored cells that contribute,
                0 for censored (below-threshold) cells that are excluded from
                the tail likelihood (but still seen by the network via the
                indicator channel).
    """
    m = cens_mask.float()
    denom = m.sum().clamp_min(1.0)
    sigma = torch.exp(log_sigma)
    z = (excesses / sigma).clamp_min(0.0)
    xi_safe = xi.clamp(min=-0.3)
    arg = (1.0 + xi_safe * z).clamp_min(1e-6)
    ll = -log_sigma - (1.0 + 1.0 / xi_safe.clamp_min(1e-3)) * torch.log(arg)
    ll_exp = -log_sigma - z
    ll = torch.where(xi.abs() < 1e-3, ll_exp, ll)
    # scale penalty guards against the sigma-collapse degeneracy
    pen = 0.05 * (log_sigma ** 2).mean()
    return -(ll * m).sum() / denom + pen


if __name__ == "__main__":
    torch.manual_seed(0)
    net = CensoredEQRN(in_ch=11)
    x = torch.randn(2, 11, 64, 64)
    # a fake covariate anchor -> indicator
    anchor = torch.randn(2, 1, 64, 64)
    thr = build_censoring_channel(anchor, margin=0.5)
    field = anchor + torch.randn(2, 1, 64, 64).abs()   # pretend target
    indicator = (field > thr).float()

    log_sigma, xi = net(x, indicator)
    print(f"parameters : {sum(p.numel() for p in net.parameters())/1e6:.2f} M")
    print(f"input channels: {11} covariates + 1 censoring indicator")
    print(f"log_sigma {tuple(log_sigma.shape)}  xi {tuple(xi.shape)}")
    print(f"xi range [{float(xi.min()):+.3f}, {float(xi.max()):+.3f}]  "
          f"(bounded +/-{net.xi_max})")

    # loss over exceeding cells only
    excess = (field - thr).clamp_min(0.0)
    nll = censored_gpd_nll(log_sigma, xi, excess, indicator)
    print(f"censored GPD NLL: {float(nll):.4f}")
    frac = float(indicator.mean())
    print(f"fraction of cells uncensored (in tail): {frac:.3f}")
    for tau in (0.95, 0.99):
        q = net.extreme_quantile(log_sigma, xi, thr, 0.10, tau)
        print(f"  tau={tau}: mean recovered quantile {float(q.mean()):+.3f}")
