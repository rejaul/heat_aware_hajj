"""
Export a calibrated exceedance-probability grid P(LST > k) for the routing side.

THE MISSING BRIDGE. Everything downstream of training -- validate_real_network,
ablation, routing -- needs a raster of exceedance probability over config.BBOX.
Nothing in the pipeline produced one. This does.

What it computes
----------------
For a chosen scene (or the mean over several), the trained network gives a
predictive mean mu and, from the heteroscedastic head, a scale sigma. The
conformal calibration then converts the residual scale into a distribution, and
we read off

    P(LST(s) > k)  =  P( mu(s) + sigma(s) * Z > k )  =  P( Z > (k - mu)/sigma )

where Z is the distribution of the NORMALISED nonconformity score, estimated
empirically from the calibration scores. Using the empirical score distribution
rather than a Gaussian is the point: it is what makes the field "calibrated"
rather than an assumed parametric tail.

TWO GRIDS ARE WRITTEN, because the ablation needs both:
    field_raw.npy   uncalibrated index -- min-max normalised (mu - k)/sigma
    field_prob.npy  ECP-calibrated exceedance probability in [0,1]

The difference between routing on these two is exactly the "conformal
contribution" row of the ablation.

IMPORTANT ON THE THRESHOLD k. Our hazard is a SURFACE-thermal exceedance, not a
physiological one. k is therefore a surface-temperature threshold and must be
stated as such in the paper. The default is the q90 of the observed LST across
calibration scenes -- a relative, data-defined level, not a physiological limit.

Usage
-----
    python export_field.py                       # median scene, q90 threshold
    python export_field.py --k 50                # explicit surface threshold, C
    python export_field.py --scene-index 3       # a specific calibration scene
    python export_field.py --aggregate mean      # mean over all calib scenes
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

import numpy as np


def pixel_exceedance(mu, sigma, k, pixel_scores=None):
    """
    P(LST(s) > k) per pixel.

    SCALE NOTE -- this replaces an earlier, incorrect implementation.

    The conformal calibration scores are one number PER SCENE (the q99 of
    |y - mu| / sigma), so they are tail statistics on the order of 2-8. The
    per-pixel standardised distance z = (k - mu)/sigma is O(1). Comparing the
    two put a per-pixel quantity against a distribution of per-scene tail
    statistics: for every pixel |z| fell below the smallest score, the empirical
    exceedance saturated at 1.0, and the field collapsed to a constant 0.5
    everywhere. The bug was the scale mismatch, not the model.

    We therefore separate the two roles, which is also the honest reading:

      * the per-scene conformal scores give calibrated INTERVAL WIDTHS
        (Table 1); they are the exchangeable units and retain the coverage
        guarantee;
      * the routing field is a PREDICTED exceedance probability computed from
        the model's own predictive distribution. It is not conformally
        guaranteed, and the paper should say so.

    If `pixel_scores` is supplied (standardised residuals pooled over
    calibration pixels) the empirical distribution is used; otherwise the
    Gaussian implied by the heteroscedastic head. The empirical option is more
    faithful to the residual shape but pixels are not independent, so it
    describes rather than guarantees.
    """
    z = (k - np.asarray(mu, float)) / np.maximum(np.asarray(sigma, float), 1e-6)

    if pixel_scores is not None and np.size(pixel_scores) > 50:
        ps = np.asarray(pixel_scores, float)
        ps = ps[np.isfinite(ps)]
        # P(Z > z) from the empirical CDF of SIGNED standardised residuals
        srt = np.sort(ps)
        idx = np.searchsorted(srt, z.ravel(), side="right")
        p = 1.0 - idx / srt.size
        return np.clip(p.reshape(z.shape), 0.0, 1.0)

    # Gaussian tail from the predictive distribution
    from math import sqrt
    from scipy.special import erf
    return np.clip(0.5 * (1.0 - erf(z / sqrt(2.0))), 0.0, 1.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", default="checkpoints/amun_best.pt")
    ap.add_argument("--scores", default="residual_scores_calib.json",
                    help="calibration scores from residual_diagnostics.py")
    ap.add_argument("--k", type=float, default=None,
                    help="surface-temperature threshold in C "
                         "(default: q90 of observed LST over the scenes used)")
    ap.add_argument("--scene-index", type=int, default=None,
                    help="which calibration scene to export (default: the one "
                         "with the median q95 LST)")
    ap.add_argument("--aggregate", choices=["none", "mean", "max"], default="none",
                    help="aggregate the probability field over all calib scenes")
    ap.add_argument("--split", default="calib", choices=["calib", "val", "train"])
    ap.add_argument("--out-prob", default="field_prob.npy")
    ap.add_argument("--out-raw", default="field_raw.npy")
    ap.add_argument("--pixel-reference", action="store_true",
                    help="use pooled per-pixel standardised residuals as the\n                          reference distribution instead of a Gaussian")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--tile", type=int, default=512,
                    help="unused for export; scenes are read at native size")
    args = ap.parse_args()

    import torch
    import xarray as xr
    import config
    from model import AMUN
    from dataset import PREDICTORS, TARGET, BASELINE, HeatPairDataset, split_files

    if not Path(args.ckpt).exists():
        raise SystemExit(f"No checkpoint at {args.ckpt}. Run train.py first.")

    tr, va, cal = split_files(verbose=False)
    files = {"train": tr, "val": va, "calib": cal}[args.split]

    ck = torch.load(args.ckpt, map_location=args.device)
    stats = ck.get("stats")
    net = AMUN(in_ch=len(PREDICTORS)).to(args.device)
    net.load_state_dict(ck["model"]); net.eval()

    # calibration scores define the predictive distribution
    if not Path(args.scores).exists():
        raise SystemExit(
            f"No {args.scores}. Run residual_diagnostics.py --split calib first, "
            "then copy residual_scores.json to residual_scores_calib.json.")
    sc = json.load(open(args.scores))
    scores = np.asarray(sc["normalised"], float)
    scores = scores[np.isfinite(scores)]

    print("=" * 74)
    print("EXPORT CALIBRATED EXCEEDANCE FIELD")
    print("=" * 74)
    print(f"  checkpoint      : {args.ckpt}")
    print(f"  calibration n   : {scores.size} scores "
          f"(mean {scores.mean():.3f}, q90 {np.quantile(scores,0.9):.3f})")
    print(f"  scenes ({args.split}) : {len(files)}")

    # de-normalisation constants for the target
    st = (stats or {}).get(TARGET, {"mean": 0.0, "std": 1.0})
    y_mu, y_sd = float(st["mean"]), float(st["std"])
    print(f"  target stats    : mean {y_mu:.2f} C, sd {y_sd:.2f} C")

    # NOTE: we deliberately do NOT use HeatPairDataset here. It crops/pads to a
    # SQUARE tile, so a 234 x 353 corridor scene comes back as 353 x 353 with a
    # NaN-padded y-axis -- a raster whose extent no longer matches config.BBOX.
    # Every downstream sampler assumes the grid spans exactly that box, so the
    # padding would shift every lat/lon lookup. We read the scene at its native
    # size instead and normalise by hand with the checkpoint's statistics.
    def load_scene_native(path):
        with xr.open_dataset(path) as d:
            chans = []
            for v in PREDICTORS:
                a = (d[v].values.astype("float32") if v in d
                     else np.zeros(d[TARGET].shape, "float32"))
                st_v = (stats or {}).get(v)
                a = np.nan_to_num(a)
                if st_v:
                    a = (a - st_v["mean"]) / st_v["std"]
                chans.append(a)
            x = torch.from_numpy(np.ascontiguousarray(np.stack(chans, 0)))[None]

            b = (np.nan_to_num(d[BASELINE].values.astype("float32"))
                 if BASELINE in d else np.zeros(d[TARGET].shape, "float32"))
            b = (b - y_mu) / y_sd
            base = torch.from_numpy(np.ascontiguousarray(b))[None, None]

            yv = d[TARGET].values.astype("float32")
            msk = np.isfinite(yv)
        return x, base, msk

    # ---- pick / iterate scenes ----
    idxs = range(len(files)) if args.aggregate != "none" else None
    if idxs is None:
        if args.scene_index is not None:
            idxs = [args.scene_index]
        else:
            q95 = []
            for f in files:
                with xr.open_dataset(f) as d:
                    a = d[TARGET].values.astype("float32")
                    a = a[np.isfinite(a)]
                    q95.append(np.percentile(a, 95) if a.size else np.nan)
            idxs = [int(np.nanargmin(np.abs(np.array(q95) - np.nanmedian(q95))))]
            print(f"  scene selected  : index {idxs[0]} (median q95 LST)")

    # ---- threshold ----
    if args.k is None:
        allv = []
        for i in idxs:
            with xr.open_dataset(files[i]) as d:
                a = d[TARGET].values.astype("float32")
                allv.append(a[np.isfinite(a)])
        k = float(np.percentile(np.concatenate(allv), 90))
        print(f"  threshold k     : {k:.2f} C  (q90 of observed LST; "
              f"RELATIVE, not physiological)")
    else:
        k = float(args.k)
        print(f"  threshold k     : {k:.2f} C  (user-specified surface temperature)")

    # ---- pooled per-pixel standardised residuals (reference distribution) ----
    pixel_scores = None
    if args.pixel_reference:
        acc = []
        with torch.no_grad():
            for i in idxs:
                xx, bb, mk = load_scene_native(files[i])
                oo = net(xx.to(args.device), baseline=bb.to(args.device))
                m_, ls_ = (oo[0], oo[1]) if isinstance(oo, (tuple, list)) else (oo, None)
                mm = m_[0, 0].cpu().numpy() * y_sd + y_mu
                ss = (np.exp(np.clip(ls_[0, 0].cpu().numpy(), -6, 4)) * y_sd
                      if ls_ is not None else np.full_like(mm, y_sd))
                with xr.open_dataset(files[i]) as dd:
                    yy = dd[TARGET].values.astype("float32")
                good = np.isfinite(yy) & mk
                acc.append(((yy - mm) / np.maximum(ss, 1e-6))[good].ravel()[::17])
        pixel_scores = np.concatenate(acc) if acc else None
        if pixel_scores is not None:
            print(f"  pixel reference : {pixel_scores.size:,} standardised "
                  f"residuals, q01 {np.percentile(pixel_scores,1):+.2f} "
                  f"q99 {np.percentile(pixel_scores,99):+.2f}")

    # ---- predict ----
    probs, raws = [], []
    with torch.no_grad():
        for i in idxs:
            x, base, _mask = load_scene_native(files[i])
            out = net(x.to(args.device), baseline=base.to(args.device))
            if isinstance(out, (tuple, list)):
                mu_n, log_sigma = out[0], out[1]
            elif out.shape[1] >= 2:
                mu_n, log_sigma = out[:, 0:1], out[:, 1:2]
            else:
                mu_n, log_sigma = out, None

            mu = mu_n[0, 0].cpu().numpy() * y_sd + y_mu          # back to C
            if log_sigma is not None:
                sig = np.exp(np.clip(log_sigma[0, 0].cpu().numpy(), -6, 4)) * y_sd
            else:
                sig = np.full_like(mu, y_sd)
            sig = np.maximum(sig, 1e-3)

            probs.append(pixel_exceedance(mu, sig, k, pixel_scores))
            # uncalibrated index: standardised excess over the threshold, so
            # larger = hotter. Kept separate from the probability so the
            # ablation can compare calibrated against uncalibrated edge costs.
            raws.append((mu - k) / np.maximum(sig, 1e-6))

    P = np.stack(probs); R = np.stack(raws)
    if args.aggregate == "mean":
        P, R = P.mean(0), R.mean(0)
    elif args.aggregate == "max":
        P, R = P.max(0), R.max(0)
    else:
        P, R = P[0], R[0]

    # raw index min-max scaled, so the ablation compares ORDERING not units
    Rn = (R - np.nanmin(R)) / max(np.nanmax(R) - np.nanmin(R), 1e-9)

    np.save(args.out_prob, P.astype("float32"))
    np.save(args.out_raw, Rn.astype("float32"))

    print(f"\n  P(LST>k) grid   : shape {P.shape}  "
          f"range [{np.nanmin(P):.3f}, {np.nanmax(P):.3f}]  "
          f"mean {np.nanmean(P):.3f}")
    print(f"  fraction of cells with P > 0.5 : {float((P>0.5).mean()):.3f}")
    print(f"\n  wrote {args.out_prob}   (ECP-calibrated, for routing)")
    print(f"  wrote {args.out_raw}    (uncalibrated index, for the ablation)")

    meta = {"checkpoint": args.ckpt, "threshold_k_C": k, "split": args.split,
            "scene_indices": [int(i) for i in idxs], "aggregate": args.aggregate,
            "calibration_n": int(scores.size), "shape": list(P.shape),
            "bbox": list(config.BBOX),
            "note": "P is a SURFACE-thermal exceedance probability, not a "
                    "physiological index; k is a relative, data-defined level."}
    json.dump(meta, open("field_export_meta.json", "w"), indent=2)
    print("  wrote field_export_meta.json")

    print("\n  NEXT")
    print("    python validate_real_network.py --risk field_prob.npy")
    print("    python ablation.py --risk field_raw.npy --calibrated field_prob.npy \\")
    print("           --people 900000")
    print("\n  Check the grid orientation is NORTH-UP over config.BBOX before")
    print("  routing; the samplers assume row 0 is the northern edge.")


if __name__ == "__main__":
    main()
