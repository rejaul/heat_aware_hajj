"""
Live heat-stress risk heatmap over the Hajj ritual routes and landmarks.

Renders the composite risk surface R(s,t) as a colour overlay on an interactive
map, with the ritual route, landmark markers, tier legend, and optional
auto-refresh for operational use.

    python heatmap.py --demo                 # synthetic field, opens instantly
    python heatmap.py --risk risk.npy        # your model output
    python heatmap.py --demo --refresh 60    # live mode, reload every 60 s

Output: hajj_risk_map.html (self-contained apart from CDN tiles/JS).
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import io
from pathlib import Path

import numpy as np

import config

# --------------------------------------------------------------------------
# Ritual geography
# --------------------------------------------------------------------------

LANDMARKS = {
    "Masjid al-Haram":   (21.4225, 39.8262, "Tawaf and Sa'i; largest chilled facility"),
    "Mina (tent city)":  (21.4133, 39.8933, "Nights of 8, 11-13 Dhul-Hijjah"),
    "Jamarat Bridge":    (21.4225, 39.8729, "Stoning ritual; peak crowd density"),
    "Muzdalifah":        (21.3833, 39.9367, "Open-air overnight stay, minimal shade"),
    "Mount Arafat":      (21.3549, 39.9841, "Wuquf, 9 Dhul-Hijjah; highest exposure"),
    "Namirah Mosque":    (21.3547, 39.9539, "Arafat day sermon"),
}

# Ordered ritual movement (the corridor where exposure accumulates).
ROUTE = [
    ("Masjid al-Haram", "Mina (tent city)", "8 Dhul-Hijjah"),
    ("Mina (tent city)", "Mount Arafat", "9 Dhul-Hijjah (dawn)"),
    ("Mount Arafat", "Muzdalifah", "9 Dhul-Hijjah (sunset)"),
    ("Muzdalifah", "Jamarat Bridge", "10 Dhul-Hijjah (dawn)"),
    ("Jamarat Bridge", "Masjid al-Haram", "10 Dhul-Hijjah"),
]

# Tier thresholds from the paper (WBGT reference bands).
TIERS = [
    (0.00, 0.25, "#2c7bb6", "Tier 0  baseline"),
    (0.25, 0.50, "#ffffbf", "Tier 1  advisory"),
    (0.50, 0.75, "#fdae61", "Tier 2  intervene"),
    (0.75, 1.01, "#d7191c", "Tier 3  emergency"),
]


def tier_colour(v: float) -> str:
    for lo, hi, col, _ in TIERS:
        if lo <= v < hi:
            return col
    return TIERS[-1][2]


# --------------------------------------------------------------------------
# Risk field
# --------------------------------------------------------------------------


def demo_risk(n: int = 220) -> np.ndarray:
    """
    Synthetic but structurally realistic field: hot spots concentrated on the
    open, unshaded sites (Arafat, Muzdalifah) and on the Jamarat approach, with
    the chilled Grand Mosque area cool. For visual testing only.
    """
    west, south, east, north = config.BBOX
    lon = np.linspace(west, east, n)
    lat = np.linspace(south, north, n)
    LON, LAT = np.meshgrid(lon, lat)

    field = np.zeros_like(LON)
    hotspots = [
        (21.3549, 39.9841, 0.95, 0.020),   # Arafat: no natural shade
        (21.3833, 39.9367, 0.72, 0.016),   # Muzdalifah: open ground
        (21.4225, 39.8729, 0.66, 0.010),   # Jamarat: density-driven
        (21.4133, 39.8933, 0.48, 0.018),   # Mina: partially shaded
    ]
    for la, lo_, amp, w in hotspots:
        field += amp * np.exp(-((LAT - la) ** 2 + (LON - lo_) ** 2) / (2 * w ** 2))

    # Chilled Grand Mosque suppresses local risk.
    field -= 0.45 * np.exp(-((LAT - 21.4225) ** 2 + (LON - 39.8262) ** 2)
                           / (2 * 0.006 ** 2))

    rng = np.random.default_rng(7)
    field += 0.05 * rng.standard_normal(field.shape)
    return np.clip(field, 0.0, 1.0)


def risk_to_png(risk: np.ndarray, alpha: float = 0.62) -> str:
    """Render the risk array to a base64 PNG data URI using the tier palette."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.colors import LinearSegmentedColormap, BoundaryNorm
    except ImportError:
        raise SystemExit("matplotlib required: pip install matplotlib")

    cmap = LinearSegmentedColormap.from_list(
        "tiers", [t[2] for t in TIERS], N=256)
    norm = BoundaryNorm([0.0, 0.25, 0.50, 0.75, 1.0], ncolors=256)

    rgba = cmap(norm(risk))
    rgba[..., 3] = alpha * (risk > 0.05)          # transparent where safe

    fig = plt.figure(figsize=(6, 6), dpi=140)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.imshow(np.flipud(rgba), interpolation="bilinear")
    ax.axis("off")
    buf = io.BytesIO()
    fig.savefig(buf, format="png", transparent=True,
                bbox_inches="tight", pad_inches=0)
    plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


# --------------------------------------------------------------------------
# Map
# --------------------------------------------------------------------------


def provenance_banner(meta_path="field_export_meta.json"):
    """
    Read the export metadata so the map states what it is showing.

    An earlier version of this map was generated from a synthetic field and was
    visually indistinguishable from one built on real predictions. The banner
    makes the provenance explicit: which checkpoint, which scenes, what
    threshold, and -- importantly -- that the hazard is a SURFACE-thermal
    exceedance, not a physiological index.
    """
    import json
    from pathlib import Path
    if not Path(meta_path).exists():
        return ("<b>Provenance unknown</b> &mdash; no field_export_meta.json. "
                "This map may be showing synthetic data.")
    m = json.load(open(meta_path))
    k = m.get("threshold_k_C")
    return (
        f"<b>Real ECOSTRESS-derived field.</b> "
        f"P(LST &gt; {k:.1f}&nbsp;&deg;C) over {m.get('shape')} px; "
        f"checkpoint <code>{m.get('checkpoint')}</code>; "
        f"{m.get('calibration_n')} calibration scenes; "
        f"split <code>{m.get('split')}</code>. "
        f"Hazard is a <i>surface</i>-thermal exceedance used as a relative "
        f"spatial index, not a physiological dose."
    )


def build_map(risk: np.ndarray, refresh: int = 0, title: str = "") -> "folium.Map":
    import folium
    from folium.plugins import Fullscreen, MeasureControl

    west, south, east, north = config.BBOX
    m = folium.Map(location=[(south + north) / 2, (west + east) / 2],
                   zoom_start=12, tiles=None, control_scale=True)

    # Basemaps.
    #
    # Two providers had to be abandoned. folium's default "OpenStreetMap" layer
    # points at tile.openstreetmap.org, whose usage policy forbids embedded or
    # application use and which returns HTTP 403 "Access blocked" tiles. CARTO's
    # basemaps now require an API key (folium raises a warning to that effect),
    # so they fail the same way for anyone without an account.
    #
    # Esri's ArcGIS Online basemaps remain open for this use and need no key, so
    # they are the default here. Attribution is required by their terms and is
    # supplied below. If a deployment needs guaranteed availability, self-hosting
    # tiles or an API key from a commercial provider is the durable answer.
    ESRI = "https://server.arcgisonline.com/ArcGIS/rest/services"
    ESRI_ATTR = ("Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ, "
                 "USGS, and the GIS User Community")

    folium.TileLayer(
        tiles=f"{ESRI}/World_Street_Map/MapServer/tile/{{z}}/{{y}}/{{x}}",
        attr=ESRI_ATTR, name="Street", max_zoom=19).add_to(m)

    # A muted base reads far better under a colour-ramped heat overlay than a
    # full-colour street map, which competes with it.
    folium.TileLayer(
        tiles=f"{ESRI}/Canvas/World_Light_Gray_Base/MapServer/tile/{{z}}/{{y}}/{{x}}",
        attr=ESRI_ATTR, name="Light (best under the overlay)",
        max_zoom=16).add_to(m)

    banner = provenance_banner()
    m.get_root().html.add_child(folium.Element(
        '<div style="position:fixed; bottom:12px; left:12px; z-index:9999; '
        'max-width:520px; background:rgba(255,255,255,.93); padding:8px 10px; '
        'border:1px solid #999; border-radius:4px; font:11px/1.45 sans-serif;">'
        + banner +
        ' &mdash; <a href="https://github.com/rejaul/heat_aware_hajj">'
        'github.com/rejaul/heat_aware_hajj</a></div>'))
    folium.TileLayer(
        tiles=f"{ESRI}/World_Imagery/MapServer/tile/{{z}}/{{y}}/{{x}}",
        attr="Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar "
             "Geographics, and the GIS User Community",
        name="Satellite", max_zoom=19).add_to(m)

    # ---- risk overlay ----
    folium.raster_layers.ImageOverlay(
        image=risk_to_png(risk),
        bounds=[[south, west], [north, east]],
        opacity=1.0, name="Heat-stress risk R(s,t)", interactive=False,
    ).add_to(m)

    # ---- ritual route ----
    route_group = folium.FeatureGroup(name="Ritual route", show=True)
    for a, b, when in ROUTE:
        la1, lo1, _ = LANDMARKS[a]
        la2, lo2, _ = LANDMARKS[b]
        folium.PolyLine(
            [(la1, lo1), (la2, lo2)], weight=4, opacity=0.85,
            color="#1a1a1a", dash_array="8,6",
            tooltip=f"{a} \u2192 {b} ({when})",
        ).add_to(route_group)
    route_group.add_to(m)

    # ---- landmarks, coloured by local risk ----
    lm_group = folium.FeatureGroup(name="Landmarks", show=True)
    ny, nx = risk.shape
    for name, (la, lo, note) in LANDMARKS.items():
        iy = int(np.clip((la - south) / (north - south) * (ny - 1), 0, ny - 1))
        ix = int(np.clip((lo - west) / (east - west) * (nx - 1), 0, nx - 1))
        val = float(risk[iy, ix])
        tier = next(lbl for lo_, hi, _, lbl in TIERS if lo_ <= val < hi)

        folium.CircleMarker(
            location=(la, lo), radius=11,
            color="#222", weight=2, fill=True,
            fill_color=tier_colour(val), fill_opacity=0.95,
            popup=folium.Popup(
                f"<b>{name}</b><br>{note}<br><br>"
                f"Risk index: <b>{val:.2f}</b><br>Status: <b>{tier}</b>",
                max_width=260),
            tooltip=f"{name} — {val:.2f}",
        ).add_to(lm_group)
    lm_group.add_to(m)

    Fullscreen().add_to(m)
    MeasureControl(primary_length_unit="meters").add_to(m)
    folium.LayerControl(collapsed=False).add_to(m)

    # ---- legend + optional auto-refresh ----
    stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rows = "".join(
        f'<div><span style="background:{c};width:14px;height:14px;'
        f'display:inline-block;border:1px solid #444;margin-right:6px;">'
        f'</span>{lbl}</div>' for _, _, c, lbl in TIERS)
    meta = f"<meta http-equiv='refresh' content='{refresh}'>" if refresh else ""

    m.get_root().html.add_child(folium.Element(f"""
    {meta}
    <div style="position:fixed;bottom:24px;left:24px;z-index:9999;
                background:rgba(255,255,255,0.94);padding:12px 14px;
                border:1px solid #999;border-radius:6px;
                font:12px/1.5 system-ui,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.2)">
      <div style="font-weight:700;margin-bottom:6px">Heat-stress risk tier</div>
      {rows}
      <div style="margin-top:8px;color:#555;border-top:1px solid #ddd;padding-top:6px">
        {title or 'Composite risk surface'}<br>Updated {stamp}
        {'<br>auto-refresh ' + str(refresh) + ' s' if refresh else ''}
      </div>
    </div>"""))
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", type=str, default=None,
                    help=".npy risk array (rows = south->north)")
    ap.add_argument("--demo", action="store_true", help="synthetic field")
    ap.add_argument("--refresh", type=int, default=0, help="seconds; 0 = off")
    ap.add_argument("--out", type=str, default="hajj_risk_map.html")
    args = ap.parse_args()

    if args.risk:
        risk = np.load(args.risk).astype(float)
        # np.ptp(arr), not arr.ptp(): the ndarray method was removed in
        # NumPy 2.0. nanmin/nanmax also guard against a field containing NaN,
        # which min()/ptp() would propagate through the whole normalisation.
        lo, hi = float(np.nanmin(risk)), float(np.nanmax(risk))
        risk = (risk - lo) / (hi - lo + 1e-9)
        title = f"Model output: {Path(args.risk).name}"
    elif args.demo:
        risk = demo_risk()
        title = "DEMO — synthetic field, not model output"
    else:
        raise SystemExit("Pass --risk <file.npy> or --demo")

    m = build_map(risk, refresh=args.refresh, title=title)
    out = Path(args.out)
    m.save(str(out))
    print(f"wrote {out.resolve()}")
    print(f"risk range: {risk.min():.2f} - {risk.max():.2f}")


if __name__ == "__main__":
    main()
