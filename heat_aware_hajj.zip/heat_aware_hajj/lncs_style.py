"""
LNCS figure geometry.

Why this file exists
--------------------
Every figure script in this pipeline was written with `figsize=(12.2, 3.4)`
inches and `font.size: 8`, then included in the paper at
`width=0.57\\textwidth`. The LNCS text block is 347.12 pt = 4.805 in wide, so
0.57 of it is 2.74 in. A 12.2 in figure squeezed into 2.74 in is scaled by
0.22, and 8 pt axis labels print at 1.8 pt against 10 pt body text. The
figures were illegible in the compiled PDF.

The fix is not to change `width=` in the .tex. Scaling cannot help: even at
`width=\\textwidth` a 12.2 in figure is scaled by 0.39 and the labels print at
3.1 pt. The figure has to be *drawn* at the width it will occupy on the page,
so that the scale factor is 1.0 and a 7 pt label prints at 7 pt.

Usage
-----
    from lncs_style import use_lncs, FIGSIZE_1x3, FIGSIZE_1x2, FIGSIZE_1x1
    use_lncs()
    fig, ax = plt.subplots(1, 3, figsize=FIGSIZE_1x3)
    ...
    fig.savefig("fig.pdf")          # include at width=\textwidth

Then in the .tex use `width=\\textwidth`, never a fraction.
"""
from __future__ import annotations

# LNCS a4paper text block, measured with \the\textwidth / \the\textheight.
TEXTWIDTH_PT = 347.12354
TEXTHEIGHT_PT = 549.13828
BASELINE_PT = 12.0
PT_PER_IN = 72.27          # TeX points

TEXTWIDTH_IN = TEXTWIDTH_PT / PT_PER_IN        # 4.8033 in

# Heights chosen so a figure costs a predictable number of body-text lines.
# A 1x3 row at 1.55 in tall occupies ~112 pt with its caption, about 9 lines.
FIGSIZE_1x3 = (TEXTWIDTH_IN, 1.55)
FIGSIZE_1x2 = (TEXTWIDTH_IN, 1.80)
FIGSIZE_1x1 = (TEXTWIDTH_IN * 0.62, 1.95)
FIGSIZE_2x2 = (TEXTWIDTH_IN, 3.10)
FIGSIZE_2x3 = (TEXTWIDTH_IN, 3.00)


def lines_cost(height_in: float, caption_lines: int = 3) -> float:
    """Body-text lines a figure of this height consumes, caption included."""
    return height_in * PT_PER_IN / BASELINE_PT + caption_lines + 1.0


def use_lncs(base: float = 7.0) -> None:
    """
    Set rcParams for figures drawn at LNCS text width and included 1:1.

    `base` is the printed point size of tick labels and legends. 7 pt against
    10 pt body text is the smallest Springer accepts comfortably; do not go
    below 6.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update({
        "font.size": base,
        "axes.titlesize": base + 0.5,
        "axes.labelsize": base,
        "legend.fontsize": base - 1.0,
        "xtick.labelsize": base - 0.5,
        "ytick.labelsize": base - 0.5,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 2.2,
        "ytick.major.size": 2.2,
        "lines.linewidth": 1.1,
        "legend.frameon": False,
        "legend.handlelength": 1.4,
        "legend.labelspacing": 0.25,
        "legend.borderpad": 0.2,
        "axes.grid": False,
        "grid.linewidth": 0.4,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.015,
        "pdf.fonttype": 42,      # embed TrueType, not Type 3; Springer requires it
        "ps.fonttype": 42,
    })


def check(pdf_path: str, included_at: float = 1.0) -> dict:
    """
    Report the printed text size of a finished figure PDF.

    `included_at` is the fraction of \\textwidth used in the .tex. Returns the
    scale factor and the point sizes as they will appear on paper, so a figure
    can be checked without opening the compiled document.
    """
    import re
    import zlib

    data = open(pdf_path, "rb").read()
    box = re.search(rb"MediaBox\s*\[\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)",
                    data)
    x0, y0, x1, y1 = (float(v) for v in box.groups())
    w_pt = x1 - x0

    import collections

    counts: collections.Counter = collections.Counter()
    for m in re.finditer(rb"stream\r?\n(.*?)endstream", data, re.S):
        chunk = m.group(1)
        try:
            chunk = zlib.decompress(chunk)
        except Exception:
            pass
        for t in re.finditer(rb"/[A-Za-z0-9]+\s+([\d.]+)\s+Tf", chunk):
            counts[float(t.group(1))] += 1

    scale = included_at * TEXTWIDTH_PT / w_pt
    sizes = sorted(counts)
    # Judge legibility on the size most of the text is set in. The smallest
    # size in a matplotlib PDF is usually a mathtext superscript (the 2 in
    # ped/m^2), which is meant to be small and is not the thing to test.
    modal = counts.most_common(1)[0][0] if counts else 0.0
    return {
        "pdf": pdf_path,
        "drawn_width_pt": round(w_pt, 1),
        "drawn_height_pt": round(y1 - y0, 1),
        "scale_on_page": round(scale, 3),
        "font_sizes_drawn": sizes,
        "font_sizes_printed": [round(s * scale, 2) for s in sizes],
        "body_printed_pt": round(modal * scale, 2),
        "smallest_printed_pt": round(min(sizes) * scale, 2) if sizes else 0.0,
        "legible": bool(counts) and modal * scale >= 5.5,
    }


if __name__ == "__main__":
    import sys
    import json

    frac = float(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].startswith("0") else 1.0
    paths = [a for a in sys.argv[1:] if a.endswith(".pdf")]
    if not paths:
        print(__doc__)
        raise SystemExit(0)
    for p in paths:
        r = check(p, included_at=frac)
        flag = "OK " if r["legible"] else "TOO SMALL"
        print(f"{flag}  {p}")
        print(f"        drawn {r['drawn_width_pt']:.0f}x{r['drawn_height_pt']:.0f} pt, "
              f"scale {r['scale_on_page']:.3f} at width={frac}\\textwidth")
        print(f"        printed text {min(r['font_sizes_printed']):.1f}"
              f"-{max(r['font_sizes_printed']):.1f} pt "
              f"(body text is 10 pt)")
