"""
Generate the three figures the restructured paper still needs.

  FIG A  study area and data     -- the corridor, OSM network, ritual sites and
                                    a real exceedance field. Reviewers currently
                                    have no picture of what was analysed.
  FIG B  real calibration        -- replaces the synthetic calib_all.pdf with the
                                    measured Mondrian result: split conformal
                                    diverging while ECP stays finite, plus
                                    leave-one-out conditional coverage.
  FIG C  route-diversity negative -- the finding that route choice cannot reduce
                                    exposure, WITH the mechanism: the thermal
                                    gradient runs along the ritual axis, not
                                    across it.

Everything is drawn from files the pipeline has already produced, so nothing is
re-derived here and nothing is invented.

Inputs expected in the working directory
----------------------------------------
    field_prob.npy               export_field.py
    route_diversity.json         route_diversity.py
    mondrian_results.json        mondrian_calibration.py   (optional)
    residual_scores_calib.json   residual_diagnostics.py   (optional)
    data/corridor_walk.graphml   corridor_network.py

Run:  python make_paper_figures.py
      python make_paper_figures.py --only A
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
                     "legend.fontsize": 6.5, "xtick.labelsize": 7,
                     "ytick.labelsize": 7, "figure.dpi": 150,
                     "savefig.bbox": "tight"})

C_HOT = "#c0392b"; C_COOL = "#1f4e79"; C_OK = "#27ae60"; C_GREY = "#7f8c8d"

SITES = {"Haram": (21.4225, 39.8262), "Jamarat": (21.4222, 39.8728),
         "Mina": (21.4133, 39.8933), "Muzdalifah": (21.3833, 39.9333),
         "Arafat": (21.3547, 39.9843)}


# ===========================================================================
def fig_a_study_area(out="fig_study_area.pdf"):
    """Corridor, network, sites and the exceedance field."""
    import config
    P = np.load("field_prob.npy")
    w, s, e, n = config.BBOX

    fig, ax = plt.subplots(1, 3, figsize=(12.2, 3.6))

    # (a) the field with sites
    im = ax[0].imshow(P, cmap="RdYlGn_r", origin="upper",
                      extent=[w, e, s, n], aspect="auto")
    plt.colorbar(im, ax=ax[0], fraction=.046, label="$P(\\mathrm{LST}>k)$")
    for nm, (la, lo) in SITES.items():
        ax[0].plot(lo, la, "o", ms=7, mfc="white", mec="k", mew=1.3, zorder=6)
        ax[0].annotate(nm, (lo, la), xytext=(5, 4), textcoords="offset points",
                       fontsize=7, fontweight="bold", zorder=7,
                       bbox=dict(boxstyle="round,pad=.15", fc="white",
                                 ec="none", alpha=.8))
    lons = [v[1] for v in SITES.values()]; lats = [v[0] for v in SITES.values()]
    order = ["Haram", "Mina", "Muzdalifah", "Arafat"]
    ax[0].plot([SITES[k][1] for k in order], [SITES[k][0] for k in order],
               "-", color="k", lw=1.2, alpha=.6, zorder=5)
    ax[0].set_xlabel("longitude"); ax[0].set_ylabel("latitude")
    ax[0].set_title("(a) study corridor and exceedance field")

    # (b) the OSM network
    try:
        import networkx as nx
        G = nx.read_graphml("data/corridor_walk.graphml")
        xs, ys = [], []
        for u, v in G.edges():
            try:
                xs += [float(G.nodes[u]["x"]), float(G.nodes[v]["x"]), np.nan]
                ys += [float(G.nodes[u]["y"]), float(G.nodes[v]["y"]), np.nan]
            except KeyError:
                continue
        ax[1].plot(xs, ys, "-", color=C_GREY, lw=.25, alpha=.8)
        ax[1].set_title(f"(b) OSM pedestrian network\n"
                        f"{G.number_of_nodes():,} nodes, {G.number_of_edges():,} edges")
    except Exception as ex:
        ax[1].text(.5, .5, f"network unavailable\n{ex}", ha="center",
                   transform=ax[1].transAxes, fontsize=7)
        ax[1].set_title("(b) OSM pedestrian network")
    for nm, (la, lo) in SITES.items():
        ax[1].plot(lo, la, "o", ms=6, mfc=C_HOT, mec="k", mew=.8, zorder=6)
    ax[1].set_xlabel("longitude"); ax[1].set_ylabel("latitude")

    # (c) field value distribution, with the site values marked
    ax[2].hist(P.ravel(), bins=60, color=C_COOL, alpha=.85)
    H, W = P.shape
    # Site markers: stagger the labels vertically. Stacking them all at the top
    # made five overlapping strings that were illegible at A4 print size.
    vals = []
    for nm, (la, lo) in SITES.items():
        r = int(np.clip((n - la) / (n - s) * (H - 1), 0, H - 1))
        c = int(np.clip((lo - w) / (e - w) * (W - 1), 0, W - 1))
        vals.append((float(P[r, c]), nm))
    vals.sort()
    ymax = ax[2].get_ylim()[1]
    for i, (v, nm) in enumerate(vals):
        ax[2].axvline(v, color=C_HOT, lw=1.0, alpha=.85)
        yy_ = ymax * (0.94 - 0.11 * i)          # step each label down
        ax[2].annotate(f"{nm} {v:.2f}", (v, yy_), xytext=(3, 0),
                       textcoords="offset points", fontsize=6,
                       ha="left", va="center", color=C_HOT,
                       bbox=dict(boxstyle="round,pad=.12", fc="white",
                                 ec="none", alpha=.75))
    ax[2].set_xlabel("$P(\\mathrm{LST}>k)$"); ax[2].set_ylabel("pixels")
    ax[2].set_title("(c) field distribution, ritual sites marked")
    ax[2].grid(alpha=.25, axis="y")

    fig.tight_layout(); fig.savefig(out); plt.close(fig)
    print(f"  {out}")


# ===========================================================================
def fig_b_calibration(out="fig_calibration.pdf"):
    """Measured Mondrian calibration: split diverges, ECP stays finite."""
    p = Path("mondrian_results.json")
    if not p.exists():
        print("  [skip] mondrian_results.json not found -- run "
              "mondrian_calibration.py first")
        return
    rows = json.load(open(p))

    strata = sorted({r["stratum"] for r in rows if r["stratum"] != "pooled"})
    fig, ax = plt.subplots(1, 3, figsize=(12.0, 3.3))

    # (a) interval half-width vs alpha, per stratum
    for k, c in zip(strata + ["pooled"], [C_HOT, C_COOL, C_GREY]):
        sub = sorted([r for r in rows if r["stratum"] == k],
                     key=lambda r: -r["alpha"])
        if not sub:
            continue
        al = [r["alpha"] for r in sub]
        sp = [r["split"] if np.isfinite(r["split"]) else np.nan for r in sub]
        ep = [r["ecp"] if np.isfinite(r["ecp"]) else np.nan for r in sub]
        ax[0].plot(al, sp, "o--", color=c, ms=4, alpha=.65, label=f"{k} split")
        ax[0].plot(al, ep, "s-", color=c, ms=4, label=f"{k} ECP")
        # mark where split diverges
        for r in sub:
            if not np.isfinite(r["split"]) and np.isfinite(r["ecp"]):
                ax[0].plot(r["alpha"], r["ecp"], "x", color=c, ms=9, mew=1.8)
                break
    ax[0].set_xscale("log"); ax[0].invert_xaxis()
    ax[0].set_xlabel(r"$\alpha$ (decreasing)")
    ax[0].set_ylabel("interval half-width")
    ax[0].set_title("(a) split conformal diverges, ECP does not\n"
                    "($\\times$ = first $\\alpha$ where split is infinite)")
    ax[0].legend(frameon=False, fontsize=6); ax[0].grid(alpha=.25)

    # (b) degeneracy threshold vs n
    ns = sorted({r["n"] for r in rows})
    nn = np.arange(5, max(ns) * 2)
    ax[1].plot(nn, 1.0 / (nn + 1), "-", color="k", lw=1.4)
    for k, c in zip(strata + ["pooled"], [C_HOT, C_COOL, C_GREY]):
        sub = [r for r in rows if r["stratum"] == k]
        if sub:
            n_ = sub[0]["n"]
            ax[1].plot(n_, 1.0 / (n_ + 1), "o", color=c, ms=8,
                       label=f"{k} (n={n_})")
    ax[1].axhline(0.05, ls=":", color=C_HOT, lw=1)
    ax[1].annotate("conventional 95%", (max(ns) * 1.4, .052), fontsize=6,
                   color=C_HOT)
    ax[1].set_xlabel("calibration sample size $n$")
    ax[1].set_ylabel(r"smallest attainable $\alpha$")
    ns_lbl = ", ".join(f"{r['stratum']} n={r['n']}"
                       for r in rows if r["stratum"] != "pooled"
                       and r["alpha"] == rows[0]["alpha"])
    ax[1].set_title(r"(b) split conformal fails below $\alpha=1/(n{+}1)$"
                    + f"\n{ns_lbl}", fontsize=7.5)
    ax[1].legend(frameon=False); ax[1].grid(alpha=.25)

    # (c) conditional coverage under a pooled interval
    # Leave-one-out conditional coverage. Read from disk if available so the
    # figure cannot silently disagree with the table; the fallback is the
    # measured calibration-only run and is flagged in the console.
    cov_path = Path("mondrian_coverage.json")
    if cov_path.exists():
        meas = {k: {float(a): v for a, v in d.items()}
                for k, d in json.load(open(cov_path)).items()}
    else:
        meas = {"day": {0.10: 0.872, 0.05: 0.949},
                "night": {0.10: 0.947, 0.05: 0.974}}
        print("     [note] using hard-coded coverage from the n=33 "
              "calibration-only run; write mondrian_coverage.json to override")
    x = np.arange(2); wbar = .36
    for i, (k, c) in enumerate(zip(["day", "night"], [C_HOT, C_COOL])):
        vals = [meas[k][a] for a in (0.10, 0.05)]
        ax[2].bar(x + (i - .5) * wbar, vals, wbar, color=c, label=k)
    for j, a in enumerate((0.10, 0.05)):
        ax[2].hlines(1 - a, j - .5, j + .5, color="k", ls="--", lw=1.2)
    ax[2].set_xticks(x); ax[2].set_xticklabels([r"$\alpha$=0.10", r"$\alpha$=0.05"])
    ax[2].set_ylim(.8, 1.02); ax[2].set_ylabel("empirical coverage")
    ax[2].set_title("(c) a pooled interval under-covers by day\n"
                    "(dashed = nominal)")
    ax[2].legend(frameon=False); ax[2].grid(alpha=.25, axis="y")

    fig.tight_layout(); fig.savefig(out); plt.close(fig)
    print(f"  {out}")


# ===========================================================================
def fig_c_route_diversity(out="fig_route_diversity.pdf", min_spread=0.02):
    """The negative result, and the mechanism behind it."""
    p = Path("route_diversity.json")
    if not p.exists():
        print("  [skip] route_diversity.json not found -- run "
              "route_diversity.py first")
        return
    rows = json.load(open(p))
    import config
    P = np.load("field_prob.npy")
    w, s, e, n = config.BBOX

    fig, ax = plt.subplots(1, 3, figsize=(12.2, 3.5))

    # (a) exposure spread per leg, per field, against the usability threshold
    legs = []
    for r in rows:
        if r["leg"] not in legs:
            legs.append(r["leg"])
    fields = sorted({r["field"] for r in rows})
    x = np.arange(len(legs)); wbar = .8 / max(len(fields), 1)
    for i, f in enumerate(fields):
        vals = [next((r["exp_spread"] for r in rows
                      if r["leg"] == L and r["field"] == f), np.nan)
                for L in legs]
        ax[0].bar(x + (i - (len(fields) - 1) / 2) * wbar, vals, wbar,
                  label=Path(f).stem)
    ax[0].axhline(min_spread, ls="--", color=C_HOT, lw=1.3,
                  label=f"usable threshold {min_spread}")
    ax[0].set_yscale("log")
    ax[0].set_xticks(x)
    ax[0].set_xticklabels([L.replace("->", "\u2192") for L in legs],
                          rotation=35, ha="right", fontsize=6)
    ax[0].set_ylabel("exposure spread\nacross 20 shortest paths")
    ax[0].set_title("(a) no leg offers an exploitable trade-off")
    ax[0].legend(frameon=True, framealpha=.9, fontsize=6,
                 loc="lower right", ncol=2)
    ax[0].grid(alpha=.25, axis="y")
    ax[0].set_ylim(top=min_spread * 3)          # keep the threshold line visible

    # (b) the mechanism: gradient runs ALONG the ritual axis
    im = ax[1].imshow(P, cmap="RdYlGn_r", origin="upper",
                      extent=[w, e, s, n], aspect="auto", alpha=.95)
    plt.colorbar(im, ax=ax[1], fraction=.046)
    order = ["Haram", "Jamarat", "Mina", "Muzdalifah", "Arafat"]
    ax[1].plot([SITES[k][1] for k in order], [SITES[k][0] for k in order],
               "-o", color="k", lw=1.8, ms=5, zorder=6)
    for k in order:
        la, lo = SITES[k]
        ax[1].annotate(k[:4], (lo, la), xytext=(4, 4),
                       textcoords="offset points", fontsize=6.5, zorder=7)
    ax[1].set_xlabel("longitude"); ax[1].set_ylabel("latitude")
    ax[1].set_title("(b) the gradient runs ALONG the ritual axis")

    # (c) field value at each site: endpoints differ, paths cannot
    H, W = P.shape
    names, vals = [], []
    for nm in order:
        la, lo = SITES[nm]
        r = int(np.clip((n - la) / (n - s) * (H - 1), 0, H - 1))
        c = int(np.clip((lo - w) / (e - w) * (W - 1), 0, W - 1))
        names.append(nm[:4]); vals.append(float(P[r, c]))
    ax[2].bar(names, vals, color=C_COOL, width=.6)
    q5, q50, q95 = np.percentile(P, [5, 50, 95])
    ax[2].axhspan(q5, q95, color=C_GREY, alpha=.2, label="field 5-95th pct")
    ax[2].axhline(q50, ls=":", color="k", lw=1, label="field median")
    ax[2].set_ylabel("$P(\\mathrm{LST}>k)$ at the site")
    ax[2].set_ylim(min(vals) * .95, max(vals) * 1.05)
    ax[2].set_title("(c) endpoints differ by 0.11;\nroutes between them by 0.001")
    ax[2].legend(frameon=False, fontsize=6); ax[2].grid(alpha=.25, axis="y")

    fig.tight_layout(); fig.savefig(out); plt.close(fig)
    print(f"  {out}")


# ===========================================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=["A", "B", "C"], default=None)
    args = ap.parse_args()

    print("generating paper figures ...")
    if args.only in (None, "A"):
        fig_a_study_area()
    if args.only in (None, "B"):
        fig_b_calibration()
    if args.only in (None, "C"):
        fig_c_route_diversity()
    print("\n  Together with capacity_analysis.pdf these are the four figures")
    print("  the restructured paper needs. The older synthetic-corridor figures")
    print("  (routes_map, theta_sweep, convergence, circuit) support a")
    print("  contribution that did not survive on real data -- drop them.")


if __name__ == "__main__":
    main()
