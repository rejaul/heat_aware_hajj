"""
Metrics and diagnostics for comparing extreme-field predictors.

The central methodological point: MEAN-oriented methods (plain U-Net, regression
kriging) do well on RMSE but under-predict the tail, while TAIL-oriented methods
(quantile AMUN, EQRN, boosting-quantile) trade a little central accuracy for far
better tail behaviour. These metrics are designed to expose exactly that.

Metric groups
-------------
central     : RMSE, MAE, bias                      (mean accuracy)
tail        : peak bias, high-quantile pinball,     (does it capture extremes?)
              exceedance detection (precision/recall at a danger threshold)
calibration : empirical coverage vs nominal,        (are intervals honest?)
              mean interval width
"""
from __future__ import annotations

import numpy as np


# ---------------------------------------------------------------------------
# Central accuracy (on a point estimate; use the median quantile if needed)
# ---------------------------------------------------------------------------


def rmse(pred, target):
    return float(np.sqrt(np.mean((pred - target) ** 2)))


def mae(pred, target):
    return float(np.mean(np.abs(pred - target)))


def bias(pred, target):
    return float(np.mean(pred - target))


# ---------------------------------------------------------------------------
# Tail accuracy
# ---------------------------------------------------------------------------


def peak_bias(pred, target, top_frac=0.02):
    """
    Mean signed error over the hottest `top_frac` of TRUE pixels. Negative means
    the model under-predicts the extremes -- the failure mode of mean regression.
    """
    n = len(target)
    k = max(1, int(top_frac * n))
    idx = np.argsort(target)[::-1][:k]
    return float(np.mean(pred[idx] - target[idx]))


def pinball(pred_q, target, tau):
    """Pinball loss of a single predicted quantile (lower is better)."""
    u = target - pred_q
    return float(np.mean(np.maximum(tau * u, (tau - 1.0) * u)))


def exceedance_scores(pred_q, target, threshold):
    """
    Treat 'predicted quantile exceeds threshold' as a danger alarm and score it
    against 'true value exceeds threshold'. Returns precision, recall, F1.
    """
    pred_hot = pred_q >= threshold
    true_hot = target >= threshold
    tp = np.sum(pred_hot & true_hot)
    fp = np.sum(pred_hot & ~true_hot)
    fn = np.sum(~pred_hot & true_hot)
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
    return float(prec), float(rec), float(f1)


# ---------------------------------------------------------------------------
# Calibration
# ---------------------------------------------------------------------------


def coverage(lower, upper, target):
    """Empirical fraction of targets inside [lower, upper]."""
    return float(np.mean((target >= lower) & (target <= upper)))


def interval_width(lower, upper):
    return float(np.mean(upper - lower))


def quantile_calibration(pred_q, target, tau):
    """
    Fraction of targets at or below the predicted tau-quantile. Should be ~tau
    if the quantile is well-calibrated.
    """
    return float(np.mean(target <= pred_q))


# ---------------------------------------------------------------------------
# One-call evaluation for a method's quantile predictions
# ---------------------------------------------------------------------------


def evaluate_quantile_method(pred_quantiles, quantiles, target,
                             danger_threshold=None, band=(0.05, 0.95)):
    """
    pred_quantiles : (N, Q) predicted quantiles
    quantiles      : the Q tau levels (sorted ascending)
    target         : (N,) truth

    Returns a flat dict of metrics.
    """
    quantiles = list(quantiles)
    q = np.asarray(pred_quantiles)

    # central point estimate = median (or nearest to 0.5)
    med_i = int(np.argmin(np.abs(np.array(quantiles) - 0.5)))
    point = q[:, med_i]

    out = {
        "RMSE": rmse(point, target),
        "MAE": mae(point, target),
        "bias": bias(point, target),
        "peak_bias": peak_bias(point, target),
    }

    # tail pinball at the highest quantile
    hi_i = len(quantiles) - 1
    out[f"pinball@{quantiles[hi_i]}"] = pinball(q[:, hi_i], target, quantiles[hi_i])

    # calibration of each quantile (deviation from nominal)
    cal_dev = []
    for i, tau in enumerate(quantiles):
        emp = quantile_calibration(q[:, i], target, tau)
        cal_dev.append(abs(emp - tau))
    out["cal_dev_mean"] = float(np.mean(cal_dev))

    # central interval coverage/width from band quantiles if present
    lo_i = int(np.argmin(np.abs(np.array(quantiles) - band[0])))
    up_i = int(np.argmin(np.abs(np.array(quantiles) - band[1])))
    if lo_i != up_i:
        out["coverage"] = coverage(q[:, lo_i], q[:, up_i], target)
        out["width"] = interval_width(q[:, lo_i], q[:, up_i])

    # exceedance detection at a danger threshold, using the high quantile
    if danger_threshold is not None:
        prec, rec, f1 = exceedance_scores(q[:, hi_i], target, danger_threshold)
        out["exc_precision"] = prec
        out["exc_recall"] = rec
        out["exc_F1"] = f1

    return out


def evaluate_mean_method(mean, std, target, quantiles=(0.05, 0.5, 0.95),
                         danger_threshold=None):
    """
    For MEAN predictors (kriging, plain U-Net) that output (mean, std). Builds
    Gaussian quantiles and scores them the same way, so the comparison is fair.
    """
    from scipy.stats import norm
    q = np.column_stack([mean + norm.ppf(t) * std for t in quantiles])
    return evaluate_quantile_method(q, quantiles, target,
                                    danger_threshold=danger_threshold)


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    from scipy.stats import t as tdist
    N = 5000
    target = np.abs(tdist.rvs(df=3, size=N, random_state=1)) * 2 + 25

    # a MEAN method: unbiased centrally but under-predicts the tail
    mean_pred = np.full(N, np.median(target))
    std_pred = np.full(N, target.std())

    # a TAIL method: predicts good quantiles
    taus = (0.05, 0.5, 0.9, 0.95, 0.99)
    tail_q = np.column_stack([np.quantile(target, t) + 0 * target for t in taus])

    thr = np.quantile(target, 0.95)
    print("MEAN method (Gaussian from mean+std):")
    m = evaluate_mean_method(mean_pred, std_pred, target,
                             quantiles=taus, danger_threshold=thr)
    for k, v in m.items():
        print(f"  {k:16s}: {v:.3f}")

    print("\nTAIL method (direct quantiles):")
    t_ = evaluate_quantile_method(tail_q, taus, target, danger_threshold=thr)
    for k, v in t_.items():
        print(f"  {k:16s}: {v:.3f}")

    print("\nNote how peak_bias and tail pinball separate the two families.")


# ===========================================================================
# EXTREME-VALUE-SPECIFIC DIAGNOSTICS
# ---------------------------------------------------------------------------
# The metrics above include central measures (RMSE, mid-band coverage) that do
# NOT test the tail. The block below interrogates extreme-prediction capability
# directly: return levels, tail-only coverage, deep-quantile calibration,
# tail-weighted loss, threshold-swept skill, and spatial extremal coincidence.
# ===========================================================================


def return_level_error(pred_quantiles, quantiles, target, periods=(10, 100, 1000)):
    """
    Return-level accuracy -- THE core EVT deliverable.

    For a return period T, the target level is the (1 - 1/T) empirical quantile
    of the TRUTH. We compare it to the model's predicted quantile at the nearest
    available tau (or, if the highest predicted tau is below 1-1/T, we flag that
    the model cannot reach that return level at all).

    Returns dict: {T: {'true_level', 'pred_level', 'abs_err', 'reachable'}}.
    """
    quantiles = np.asarray(quantiles)
    q = np.asarray(pred_quantiles)
    out = {}
    for T in periods:
        p = 1.0 - 1.0 / T
        true_level = float(np.quantile(target, p))
        reachable = p <= quantiles.max() + 1e-9
        i = int(np.argmin(np.abs(quantiles - p)))
        # spatial max of that quantile field is the model's return-level estimate
        pred_level = float(np.quantile(q[:, i], p)) if reachable else float(q[:, -1].max())
        out[T] = {
            "true_level": true_level,
            "pred_level": pred_level,
            "abs_err": abs(pred_level - true_level),
            "reachable": bool(reachable),
        }
    return out


def tail_coverage(pred_lower, pred_upper, target, tail_quantile=0.90):
    """
    Coverage computed ONLY over pixels whose TRUE value exceeds a high quantile.

    A method can score well on whole-field coverage while failing on the tail;
    this isolates the tail. Returns (coverage_on_tail, n_tail).
    """
    thr = np.quantile(target, tail_quantile)
    m = target >= thr
    if m.sum() == 0:
        return float("nan"), 0
    cov = np.mean((target[m] >= pred_lower[m]) & (target[m] <= pred_upper[m]))
    return float(cov), int(m.sum())


def deep_quantile_calibration(pred_quantiles, quantiles, target):
    """
    Empirical coverage at each tau, focusing on the tail. Returns a dict
    {tau: empirical_fraction_below}. A well-calibrated tail has emp ~ tau at
    tau = 0.95, 0.99, 0.999 -- NOT just on average.
    """
    q = np.asarray(pred_quantiles)
    return {float(t): float(np.mean(target <= q[:, i]))
            for i, t in enumerate(quantiles)}


def tail_weighted_pinball(pred_quantiles, quantiles, target, tail_from=0.9):
    """
    Mean pinball loss over ONLY the high quantiles (tau >= tail_from), so the
    score rewards tail accuracy and ignores the easy median.
    """
    q = np.asarray(pred_quantiles)
    losses = []
    for i, tau in enumerate(quantiles):
        if tau >= tail_from:
            u = target - q[:, i]
            losses.append(np.mean(np.maximum(tau * u, (tau - 1) * u)))
    return float(np.mean(losses)) if losses else float("nan")


def threshold_swept_skill(pred_quantile_hi, target, base_quantile=0.9,
                          steps=6, span=0.099):
    """
    Exceedance F1 as the danger threshold is pushed DEEPER into the tail.

    Uses the model's highest quantile field to alarm, and sweeps the threshold
    from the base_quantile up toward the extreme. Reveals whether skill holds as
    events get rarer, or collapses. Returns list of (threshold_quantile, F1).
    """
    out = []
    for k in range(steps):
        tq = base_quantile + span * k / max(steps - 1, 1)
        thr = np.quantile(target, tq)
        _, _, f1 = exceedance_scores(pred_quantile_hi, target, thr)
        out.append((round(float(tq), 4), float(f1)))
    return out


def extremal_coincidence(pred_quantile_hi, target, tail_quantile=0.95):
    """
    Do the model's predicted extremes occur WHERE the true extremes are?

    Computes (a) Pearson correlation between the predicted high-quantile field
    and truth, and (b) the Jaccard overlap between predicted-hot and true-hot
    pixel sets. This is the spatial-extreme check that caught the EQRN anchor
    bug (corr was -0.71 before the fix); nothing else in the suite detects it.
    """
    corr = float(np.corrcoef(pred_quantile_hi, target)[0, 1])
    thr_p = np.quantile(pred_quantile_hi, tail_quantile)
    thr_t = np.quantile(target, tail_quantile)
    pred_hot = pred_quantile_hi >= thr_p
    true_hot = target >= thr_t
    inter = np.sum(pred_hot & true_hot)
    union = np.sum(pred_hot | true_hot)
    jaccard = float(inter / union) if union else 0.0
    return {"tail_corr": corr, "tail_jaccard": jaccard}


def evaluate_extremes(pred_quantiles, quantiles, target,
                      periods=(10, 100), tail_from=0.9):
    """
    One-call EXTREME-VALUE diagnostic bundle. Complements
    evaluate_quantile_method (which mixes in central metrics).
    """
    q = np.asarray(pred_quantiles)
    quantiles = list(quantiles)
    hi = q[:, -1]

    out = {}
    # return levels
    rl = return_level_error(q, quantiles, target, periods)
    for T, d in rl.items():
        out[f"RL{T}_err"] = d["abs_err"]
        out[f"RL{T}_reach"] = float(d["reachable"])
    # tail-only coverage from the widest available band
    lo_i = 0
    up_i = len(quantiles) - 1
    tc, n_tail = tail_coverage(q[:, lo_i], q[:, up_i], target)
    out["tail_coverage"] = tc
    # deep calibration at the top quantile
    dc = deep_quantile_calibration(q, quantiles, target)
    top_tau = quantiles[-1]
    out[f"cal@{top_tau}"] = dc[float(top_tau)]
    out[f"cal_dev@{top_tau}"] = abs(dc[float(top_tau)] - top_tau)
    # tail-weighted pinball
    out["tail_pinball"] = tail_weighted_pinball(q, quantiles, target, tail_from)
    # spatial extremal coincidence
    ec = extremal_coincidence(hi, target)
    out["tail_corr"] = ec["tail_corr"]
    out["tail_jaccard"] = ec["tail_jaccard"]
    return out
