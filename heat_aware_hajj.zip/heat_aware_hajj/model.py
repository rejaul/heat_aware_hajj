"""
AMUN -- Attention-Mechanism U-Net for heat-field downscaling.

Maps a coarse predictor stack (ERA5-Land / CHI, upsampled to the fine grid) to a
high-resolution near-surface heat field supervised by satellite LST.

Modernised relative to the 2018 Attention U-Net:
  * GroupNorm instead of BatchNorm  -- stable at the small batch sizes forced by
    large tiles; batch statistics are unreliable with batch=4.
  * SiLU activations.
  * Residual conv blocks.
  * Attention gates on every skip connection (the "AM" in AMUN).
  * Optional heteroscedastic head predicting (mu, log_sigma) so the network
    reports its own uncertainty, which the conformal layer then calibrates.

Sized for a 32 GB GPU: the default width (base=48, depth=4) trains at
512x512 tiles with batch=8 in mixed precision using roughly 18-22 GB.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


def gn(ch: int, max_groups: int = 8) -> nn.GroupNorm:
    groups = max(1, min(max_groups, ch // 8))
    while ch % groups != 0 and groups > 1:
        groups -= 1
    return nn.GroupNorm(groups, ch)


class ResBlock(nn.Module):
    """Two 3x3 convolutions with a residual connection."""

    def __init__(self, cin: int, cout: int, dropout: float = 0.0):
        super().__init__()
        self.c1 = nn.Conv2d(cin, cout, 3, padding=1, bias=False)
        self.n1 = gn(cout)
        self.c2 = nn.Conv2d(cout, cout, 3, padding=1, bias=False)
        self.n2 = gn(cout)
        self.drop = nn.Dropout2d(dropout) if dropout > 0 else nn.Identity()
        self.skip = (nn.Identity() if cin == cout
                     else nn.Conv2d(cin, cout, 1, bias=False))
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        h = self.act(self.n1(self.c1(x)))
        h = self.drop(h)
        h = self.n2(self.c2(h))
        return self.act(h + self.skip(x))


class AttentionGate(nn.Module):
    """
    Additive attention gate (Oktay et al., 2018).

    Uses the decoder signal `g` to weight the encoder skip `x`, so that
    irrelevant coarse structure is suppressed before concatenation.

        alpha   = sigma( psi^T ReLU(W_x x + W_g g + b) )
        x_tilde = alpha * x
    """

    def __init__(self, ch_x: int, ch_g: int, ch_int: int):
        super().__init__()
        self.wx = nn.Conv2d(ch_x, ch_int, 1, bias=False)
        self.wg = nn.Conv2d(ch_g, ch_int, 1, bias=False)
        self.psi = nn.Conv2d(ch_int, 1, 1)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x, g):
        if g.shape[-2:] != x.shape[-2:]:
            g = F.interpolate(g, size=x.shape[-2:], mode="bilinear",
                              align_corners=False)
        a = torch.sigmoid(self.psi(self.act(self.wx(x) + self.wg(g))))
        return x * a, a


class Down(nn.Module):
    def __init__(self, cin, cout, dropout=0.0):
        super().__init__()
        self.pool = nn.MaxPool2d(2)
        self.block = ResBlock(cin, cout, dropout)

    def forward(self, x):
        return self.block(self.pool(x))


class Up(nn.Module):
    def __init__(self, cin, cskip, cout, dropout=0.0):
        super().__init__()
        self.up = nn.ConvTranspose2d(cin, cin // 2, 2, stride=2)
        self.gate = AttentionGate(cskip, cin // 2, max(cskip // 2, 8))
        self.block = ResBlock(cin // 2 + cskip, cout, dropout)

    def forward(self, x, skip):
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear",
                              align_corners=False)
        skip, attn = self.gate(skip, x)
        return self.block(torch.cat([x, skip], dim=1)), attn


class AMUN(nn.Module):
    """
    Parameters
    ----------
    in_ch : number of coarse predictor channels (see config.PREDICTORS)
    base  : width of the first level
    depth : number of downsampling stages
    heteroscedastic : if True the model outputs (mu, log_sigma)

    Notes
    -----
    The network predicts a *residual* on top of the bilinearly upsampled coarse
    heat index, which is passed as `baseline`. Learning the correction rather
    than the absolute field converges far faster and keeps the model physically
    anchored when supervision is sparse.
    """

    def __init__(self, in_ch: int, base: int = 48, depth: int = 4,
                 dropout: float = 0.05, heteroscedastic: bool = True):
        super().__init__()
        self.heteroscedastic = heteroscedastic
        self.depth = depth

        chs = [base * (2 ** i) for i in range(depth + 1)]
        self.stem = ResBlock(in_ch, chs[0], dropout)
        self.downs = nn.ModuleList(
            [Down(chs[i], chs[i + 1], dropout) for i in range(depth)]
        )
        self.ups = nn.ModuleList(
            [Up(chs[i + 1], chs[i], chs[i], dropout)
             for i in reversed(range(depth))]
        )
        out_ch = 2 if heteroscedastic else 1
        self.head = nn.Conv2d(chs[0], out_ch, 1)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)   # start as identity on the baseline

    def forward(self, x, baseline=None, return_attention: bool = False):
        h = self.stem(x)
        skips = [h]
        for d in self.downs:
            h = d(h)
            skips.append(h)

        attns = []
        h = skips[-1]
        for i, u in enumerate(self.ups):
            h, a = u(h, skips[-(i + 2)])
            attns.append(a)

        out = self.head(h)
        if self.heteroscedastic:
            mu, log_sigma = out[:, :1], out[:, 1:2]
            log_sigma = log_sigma.clamp(-7.0, 3.0)
        else:
            mu, log_sigma = out, None

        if baseline is not None:
            mu = mu + baseline           # residual formulation

        if return_attention:
            return mu, log_sigma, attns
        return mu, log_sigma


# ---------------------------------------------------------------------------
# Losses
# ---------------------------------------------------------------------------


def masked_l1(pred, target, mask):
    m = mask.float()
    denom = m.sum().clamp_min(1.0)
    return ((pred - target).abs() * m).sum() / denom


def gaussian_nll(pred, log_sigma, target, mask):
    """
    Heteroscedastic negative log-likelihood. Lets the network flag where it is
    unsure (cloud edges, sparse supervision), which gives the conformal layer a
    far better nonconformity score than a bare residual.
    """
    m = mask.float()
    denom = m.sum().clamp_min(1.0)
    inv_var = torch.exp(-2.0 * log_sigma)
    nll = 0.5 * (inv_var * (pred - target) ** 2) + log_sigma
    return (nll * m).sum() / denom


def gradient_loss(pred, target, mask):
    """
    Penalises mismatch in spatial gradients. Downscaling is judged on sharpness
    of the thermal structure (heat-island edges), not only on pointwise error.
    """
    def dx(t):
        return t[..., :, 1:] - t[..., :, :-1]

    def dy(t):
        return t[..., 1:, :] - t[..., :-1, :]

    mx, my = mask[..., :, 1:] * mask[..., :, :-1], mask[..., 1:, :] * mask[..., :-1, :]
    lx = ((dx(pred) - dx(target)).abs() * mx).sum() / mx.float().sum().clamp_min(1.0)
    ly = ((dy(pred) - dy(target)).abs() * my).sum() / my.float().sum().clamp_min(1.0)
    return lx + ly


if __name__ == "__main__":
    torch.manual_seed(0)
    net = AMUN(in_ch=11, base=48, depth=4)
    n_par = sum(p.numel() for p in net.parameters())
    x = torch.randn(2, 11, 256, 256)
    base = torch.randn(2, 1, 256, 256)
    mu, ls = net(x, baseline=base)
    print(f"parameters : {n_par/1e6:.2f} M")
    print(f"input      : {tuple(x.shape)}")
    print(f"mu         : {tuple(mu.shape)}")
    print(f"log_sigma  : {tuple(ls.shape)}")
    print(f"identity at init (mu == baseline): "
          f"{torch.allclose(mu, base, atol=1e-5)}")
