"""
AMUN with a QUANTILE head -- the proposed extreme-quantile field predictor.

This is the corrected objective. Instead of predicting the conditional MEAN
(which regresses toward typical values and under-predicts peaks), the network
predicts a set of high conditional quantiles tau = {0.5, 0.9, 0.95, 0.99}
directly, trained with the pinball (quantile) loss. The tau=0.95/0.99 outputs
are the extreme-heat field; ECP then extends them past the observed range.

The attention U-Net backbone is imported unchanged from model.py -- only the
head and loss differ, so the proposed method and the plain-mean baseline share
an identical backbone and differ ONLY in objective. That is what makes the
comparison clean.
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from model import ResBlock, Down, Up   # shared backbone pieces

DEFAULT_QUANTILES = (0.5, 0.9, 0.95, 0.99)


class AMUNQuantile(nn.Module):
    """
    AMUN backbone with a multi-quantile head.

    Output: (B, Q, H, W) -- one channel per quantile in `quantiles`.

    A softplus-cumulative parameterisation guarantees the quantiles are
    monotonically non-decreasing in tau (no quantile crossing), which is
    essential: a 0.99 field must never dip below the 0.95 field.
    """

    def __init__(self, in_ch: int, base: int = 48, depth: int = 4,
                 dropout: float = 0.05, quantiles=DEFAULT_QUANTILES):
        super().__init__()
        self.quantiles = tuple(quantiles)
        self.n_q = len(self.quantiles)
        self.depth = depth

        chs = [base * (2 ** i) for i in range(depth + 1)]
        self.stem = ResBlock(in_ch, chs[0], dropout)
        self.downs = nn.ModuleList(
            [Down(chs[i], chs[i + 1], dropout) for i in range(depth)])
        self.ups = nn.ModuleList(
            [Up(chs[i + 1], chs[i], chs[i], dropout)
             for i in reversed(range(depth))])

        # Head predicts a base level + non-negative increments between quantiles.
        self.head_base = nn.Conv2d(chs[0], 1, 1)
        self.head_incr = nn.Conv2d(chs[0], self.n_q - 1, 1)
        nn.init.zeros_(self.head_base.weight); nn.init.zeros_(self.head_base.bias)
        nn.init.zeros_(self.head_incr.weight); nn.init.zeros_(self.head_incr.bias)

    def forward(self, x, baseline=None):
        h = self.stem(x)
        skips = [h]
        for d in self.downs:
            h = d(h); skips.append(h)
        h = skips[-1]
        for i, u in enumerate(self.ups):
            h, _ = u(h, skips[-(i + 2)])

        base = self.head_base(h)                       # (B,1,H,W)
        incr = torch.nn.functional.softplus(self.head_incr(h))  # >=0
        # cumulative sum -> monotone quantiles
        cum = torch.cumsum(incr, dim=1)
        q0 = base
        qs = torch.cat([q0, q0 + cum], dim=1)          # (B,Q,H,W)
        if baseline is not None:
            qs = qs + baseline                         # residual on coarse field
        return qs


def pinball_loss(pred, target, quantiles, mask):
    """
    Multi-quantile pinball (quantile) loss over valid pixels.

        L_tau(u) = max(tau*u, (tau-1)*u),  u = y - q_tau

    pred:   (B,Q,H,W)   target: (B,1,H,W)   mask: (B,1,H,W)
    """
    m = mask.float()
    denom = m.sum().clamp_min(1.0) * len(quantiles)
    total = 0.0
    for i, tau in enumerate(quantiles):
        u = target[:, 0:1] - pred[:, i:i + 1]
        loss = torch.maximum(tau * u, (tau - 1.0) * u)
        total = total + (loss * m).sum()
    return total / denom


if __name__ == "__main__":
    torch.manual_seed(0)
    net = AMUNQuantile(in_ch=11, quantiles=DEFAULT_QUANTILES)
    x = torch.randn(2, 11, 128, 128)
    base = torch.randn(2, 1, 128, 128)
    out = net(x, baseline=base)
    print(f"parameters : {sum(p.numel() for p in net.parameters())/1e6:.2f} M")
    print(f"output     : {tuple(out.shape)}  (B, Q={net.n_q}, H, W)")
    # monotonicity check across the quantile axis
    diffs = out[:, 1:] - out[:, :-1]
    print(f"monotone quantiles (all increments >= 0): "
          f"{bool((diffs >= -1e-6).all())}")
    y = torch.randn(2, 1, 128, 128)
    m = torch.ones(2, 1, 128, 128)
    print(f"pinball loss: {float(pinball_loss(out, y, net.quantiles, m)):.4f}")
