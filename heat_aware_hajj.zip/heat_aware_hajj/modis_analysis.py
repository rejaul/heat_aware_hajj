"""
MODIS LST analysis: what a fixed overpass time makes possible.

Three analyses that the ECOSTRESS record could not support, each because the
ISS orbit drifts acquisitions through the diurnal cycle:

  1. IDENTIFIED TAIL. Block maxima require comparable blocks. Annual maxima of
     a fixed-overpass series are genuinely exchangeable draws, unlike maxima
     over scenes taken at arbitrary local hours. On ECOSTRESS the GPD shape
     drifted from -0.49 to -0.89 with threshold and was never identified; here
     we can test whether a clean block-maxima framing resolves it, as it does
     for the station-based GEV analyses in the literature.

  2. ERA5 VALIDATION ACROSS THE GAP. The Makkah station record ends in August
     2018; our ECOSTRESS record begins in 2018. MODIS spans both, so it can
     test whether the -3.51 K ERA5 cold bias measured on 2013-2018 persists
     into the 2019-2024 study period -- an assumption we currently have to make
     rather than verify.

  3. DIURNAL DECOMPOSITION FOR FREE. Day and night observations are separate
     bands at known local times, so the day-night difference is a direct
     measure of surface thermal inertia without any harmonic fitting.

MODIS LST is stored as a 16-bit unsigned integer in kelvin with scale 0.02;
zero means fill. We apply the QC band conservatively, keeping only pixels
flagged as good quality.

Run:
    python modis_analysis.py
    python modis_analysis.py --stat q95 --qc-strict
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import glob
import json
import re
import warnings
from collections import defaultdict
from datetime import datetime, timedelta

warnings.filterwarnings("ignore")

import numpy as np

SCALE = 0.02          # MODIS LST scale factor, result in kelvin
FILL = 0
# nominal local overpass times, used for labelling only
OVERPASS = {("MOD11A1", "Day"): 10.5, ("MOD11A1", "Night"): 22.5,
            ("MYD11A1", "Day"): 13.5, ("MYD11A1", "Night"): 1.5}


def granule_date(path):
    """MODIS names carry .AYYYYDDD. (year and day-of-year)."""
    m = re.search(r"\.A(\d{4})(\d{3})\.", os.path.basename(path))
    if not m:
        return None
    y, doy = int(m.group(1)), int(m.group(2))
    return (datetime(y, 1, 1) + timedelta(days=doy - 1)).date()


def read_band(path, band):
    """
    Read one LST band from an HDF-EOS granule, in degrees Celsius.

    READER CHOICE. Three options were tested on a real granule and only one is
    correct:

      rioxarray/GDAL  fails outright unless GDAL was built with the HDF4
                      driver, which pip wheels commonly omit ("not recognized").
      xarray/netcdf4  OPENS SUCCESSFULLY AND RETURNS WRONG VALUES. It applies
                      the file's own scale_factor before we apply ours, so the
                      result is double-scaled: a granule reading 10-59 C through
                      pyhdf came back as -267 C. A silent wrong answer is worse
                      than a failure, so this path is not used.
      pyhdf           reads HDF4 directly, bypasses GDAL entirely, and returns
                      raw integers to which we apply the documented 0.02 scale
                      ourselves. This is the one we use.

    Returns None when the band is absent or wholly fill.
    """
    try:
        from pyhdf.SD import SD, SDC
    except ImportError:
        raise SystemExit(
            "pyhdf is required to read MODIS HDF4 granules.\n"
            "  pip install pyhdf\n"
            "GDAL-based readers need an HDF4 driver that is often missing, and\n"
            "xarray's netcdf4 engine double-scales these files.")
    try:
        h = SD(str(path), SDC.READ)
    except Exception:
        return None
    try:
        if band not in h.datasets():
            return None
        raw = np.asarray(h.select(band)[:]).astype("float32")
    finally:
        h.end()

    raw[raw == FILL] = np.nan
    a = raw * SCALE - 273.15          # scale is applied here, once
    a[(a < -50) | (a > 80)] = np.nan  # physical bounds
    return a if np.isfinite(a).any() else None


def clip_to_bbox(a, bbox, tile="h21v06"):
    """
    Clip a 1200x1200 MODIS sinusoidal tile to the study box.

    A granule covers roughly 10 degrees; our corridor is 0.24 x 0.15 degrees, so
    without clipping the statistic would describe the whole tile -- desert,
    mountains and coast -- rather than the corridor. That is the same fault that
    affected the ECOSTRESS pairs before cropping was added.

    Converting sinusoidal grid indices to lon/lat exactly needs the tile origin;
    since we only need a small window we locate the box centre analytically and
    take a symmetric window around it. At 1 km the corridor is ~25 x 16 px.
    """
    west, south, east, north = bbox
    clat = (south + north) / 2.0
    clon = (west + east) / 2.0

    R = 6371007.181            # MODIS sphere radius, m
    T = 1111950.0              # tile size, m
    px = T / 1200.0            # ~926 m

    hh, vv = int(tile[1:3]), int(tile[4:6])
    x0 = -20015109.354 + hh * T          # tile west edge, sinusoidal metres
    y0 = 10007554.677 - vv * T          # tile north edge

    def to_rc(lat, lon):
        y = np.radians(lat) * R
        x = np.radians(lon) * R * np.cos(np.radians(lat))
        return int((y0 - y) / px), int((x - x0) / px)

    r_c, c_c = to_rc(clat, clon)
    # half-extents in pixels, with a one-pixel margin
    dr = max(1, int(abs(to_rc(north, clon)[0] - to_rc(south, clon)[0]) / 2) + 1)
    dc = max(1, int(abs(to_rc(clat, east)[1] - to_rc(clat, west)[1]) / 2) + 1)

    r0, r1 = max(0, r_c - dr), min(a.shape[0], r_c + dr + 1)
    c0, c1 = max(0, c_c - dc), min(a.shape[1], c_c + dc + 1)
    if r1 - r0 < 2 or c1 - c0 < 2:
        return None
    return a[r0:r1, c0:c1]


def collect(root, product, stat="q95", bbox=None):
    """Per-day statistic for each band of one product, over the study box."""
    red = {"q95": lambda v: np.nanpercentile(v, 95),
           "q99": lambda v: np.nanpercentile(v, 99),
           "max": np.nanmax, "mean": np.nanmean}[stat]
    files = sorted(glob.glob(os.path.join(root, product, "*", "*.hdf"))) or \
            sorted(glob.glob(os.path.join(root, product, "**", "*.hdf"),
                             recursive=True))
    series = {"Day": {}, "Night": {}}
    n_read, n_fail = 0, 0
    for f in files:
        d = granule_date(f)
        if d is None:
            continue
        for band in ("LST_Day_1km", "LST_Night_1km"):
            a = read_band(f, band)
            if a is None:
                n_fail += 1
                continue
            if bbox is not None:
                a = clip_to_bbox(a, bbox)
                if a is None:
                    n_fail += 1
                    continue
            v = a[np.isfinite(a)]
            if v.size < 8:                    # too little clear sky to trust
                continue
            key = "Day" if "Day" in band else "Night"
            series[key][d] = float(red(v))
            n_read += 1
    return series, n_read, n_fail


def gpd_sweep(x, qs=(0.60, 0.70, 0.80, 0.90)):
    """Shape and endpoint across thresholds -- the stability test."""
    from scipy.stats import genpareto
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    rows = []
    for q in qs:
        u = float(np.quantile(x, q))
        exc = x[x > u] - u
        if exc.size < 8:
            rows.append({"q": q, "n_exc": int(exc.size), "xi": None})
            continue
        xi, _, sc = genpareto.fit(exc, floc=0)
        end = u - sc / xi if xi < 0 else float("inf")
        rows.append({"q": q, "n_exc": int(exc.size), "xi": float(xi),
                     "scale": float(sc), "u": u, "endpoint": float(end)})
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="data/raw/modis")
    ap.add_argument("--stat", default="q95",
                    choices=["q95", "q99", "max", "mean"])
    ap.add_argument("--products", nargs="+", default=["MOD11A1", "MYD11A1"])
    ap.add_argument("--bbox", help="west,south,east,north (default config.BBOX)")
    args = ap.parse_args()

    import config
    bbox = (tuple(float(x) for x in args.bbox.split(","))
            if args.bbox else config.BBOX)
    print("=" * 76)
    print(f"MODIS LST ANALYSIS  (per-scene statistic: {args.stat})")
    print("=" * 76)
    print(f"  clipped to {bbox}  (~25 x 16 px at 1 km)")

    out = {}
    all_series = {}
    for p in args.products:
        series, ok, bad = collect(args.root, p, args.stat, bbox)
        nd, nn = len(series["Day"]), len(series["Night"])
        print(f"\n{p}: {nd} day, {nn} night observations "
              f"({ok} bands read, {bad} unreadable)")
        if nd == 0 and nn == 0:
            print("  no data -- run download_modis.py first")
            continue
        for band in ("Day", "Night"):
            s = series[band]
            if not s:
                continue
            v = np.array(list(s.values()))
            hh = OVERPASS.get((p, band))
            print(f"  {band:<6} (~{hh:>4.1f} h local)  n={v.size:>4}  "
                  f"{v.min():5.1f} .. {v.max():5.1f} C   "
                  f"mean {v.mean():5.1f}  sd {v.std():4.1f}")
            all_series[f"{p}_{band}"] = s

    if not all_series:
        return

    # ---- 1. day-night difference: thermal inertia, no fitting needed -------
    print("\n1. DIURNAL AMPLITUDE (day minus night, same sensor and date)")
    for p in args.products:
        d, n = all_series.get(f"{p}_Day"), all_series.get(f"{p}_Night")
        if not d or not n:
            continue
        common = sorted(set(d) & set(n))
        if not common:
            continue
        diff = np.array([d[k] - n[k] for k in common])
        print(f"  {p}: n={len(common):>4}  mean {diff.mean():5.1f} C  "
              f"range {diff.min():5.1f} .. {diff.max():5.1f}")
    print("  A fixed overpass gives this directly; on ECOSTRESS the same")
    print("  quantity required fitting a harmonic to irregularly-timed scenes.")

    # ---- 2. annual maxima and the tail ------------------------------------
    print("\n2. ANNUAL MAXIMA AND TAIL IDENTIFIABILITY")
    print("  Blocks are years of a FIXED-overpass series, so they are")
    print("  comparable draws -- the condition ECOSTRESS block maxima failed.")
    for key, s in all_series.items():
        if "Day" not in key or len(s) < 60:
            continue
        by_year = defaultdict(list)
        for d, v in s.items():
            by_year[d.year].append(v)
        yrs = sorted(by_year)
        amax = np.array([max(by_year[y]) for y in yrs])
        print(f"\n  {key}: {len(yrs)} annual maxima "
              f"({yrs[0]}-{yrs[-1]}), {amax.min():.1f} .. {amax.max():.1f} C")
        for y, v in zip(yrs, amax):
            print(f"      {y}: {v:5.1f} C   (n={len(by_year[y])} obs)")
        if len(amax) >= 8:
            print(f"    GPD sweep on the full series ({len(s)} obs):")
            for r in gpd_sweep(np.array(list(s.values()))):
                if r["xi"] is None:
                    print(f"      q{r['q']:.2f}: only {r['n_exc']} exceedances")
                else:
                    print(f"      q{r['q']:.2f}: xi {r['xi']:+.3f}  "
                          f"k={r['n_exc']:>3}  endpoint {r['endpoint']:6.1f} C")
            print("    A shape that holds steady across thresholds is")
            print("    identified; one that drifts is not. Compare with the")
            print("    ECOSTRESS sweep (-0.49 to -0.89), which drifted.")
        out[key] = {"years": yrs, "annual_max": amax.tolist(),
                    "n_obs": len(s)}

    # ---- 3. coverage across the ERA5 validation gap ----------------------
    print("\n3. COVERAGE ACROSS THE STATION / ECOSTRESS GAP")
    for key, s in all_series.items():
        ds = sorted(s)
        pre = sum(1 for d in ds if d.year <= 2018)
        post = sum(1 for d in ds if d.year >= 2019)
        print(f"  {key:<18} {ds[0]} .. {ds[-1]}   "
              f"<=2018: {pre:>4}   >=2019: {post:>4}")
    print("  Observations on both sides of 2018 let the ERA5 cold bias")
    print("  measured on 2013-2018 be tested for persistence into the")
    print("  2019-2024 study period, which we currently assume.")

    json.dump({k: {"dates": [str(d) for d in sorted(v)],
                   "values": [v[d] for d in sorted(v)]}
               for k, v in all_series.items()},
              open("modis_series.json", "w"), indent=2)
    print("\n  series -> modis_series.json")
    print("\n  NOTE. MODIS is 1 km; the corridor is ~25 x 16 px at that scale.")
    print("  These results characterise the corridor's thermal regime and tail.")
    print("  They cannot inform routing, which needs sub-kilometre contrast.")


if __name__ == "__main__":
    main()
