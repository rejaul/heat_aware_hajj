"""
Why can MODIS granules not be read?

modis_analysis.py reported "3672 unreadable", which means the .hdf files were
FOUND but every open failed. The script swallowed the underlying exception,
which was unhelpful. This prints the real error and tries four readers in turn,
so the cause is identified rather than guessed.

MODIS MOD11A1/MYD11A1 are HDF-EOS2, which is HDF4 underneath. The usual cause of
a total read failure is a GDAL build without HDF4 support: conda-forge's GDAL
normally has it, pip wheels frequently do not. The fallbacks below do not depend
on GDAL at all.

Run:  python modis_debug.py
      python modis_debug.py --file path/to/one.hdf
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import argparse
import glob
import warnings

warnings.filterwarnings("ignore")

import numpy as np

BANDS = ("LST_Day_1km", "LST_Night_1km")
GRID = "MODIS_Grid_Daily_1km_LST"


def try_gdal_list(path):
    """List subdatasets via GDAL. Tells us whether HDF4 support exists at all."""
    try:
        from osgeo import gdal
    except ImportError:
        return None, "osgeo/GDAL not installed"
    gdal.UseExceptions()
    try:
        ds = gdal.Open(path)
    except Exception as e:
        return None, f"gdal.Open failed: {str(e)[:90]}"
    if ds is None:
        return None, "gdal.Open returned None (HDF4 driver likely missing)"
    subs = ds.GetSubDatasets()
    return [s[0] for s in subs], f"{len(subs)} subdatasets"


def try_rioxarray(path, band):
    try:
        import rioxarray
    except ImportError:
        return None, "rioxarray not installed"
    sub = f'HDF4_EOS:EOS_GRID:"{path}":{GRID}:{band}'
    try:
        da = rioxarray.open_rasterio(sub, masked=False).squeeze()
        return np.asarray(da.values), "ok"
    except Exception as e:
        return None, str(e)[:110]


def try_pyhdf(path, band):
    """pyhdf reads HDF4 directly, with no GDAL involved."""
    try:
        from pyhdf.SD import SD, SDC
    except ImportError:
        return None, "pyhdf not installed (pip install pyhdf)"
    try:
        h = SD(path, SDC.READ)
        names = list(h.datasets().keys())
        if band not in names:
            h.end()
            return None, f"band absent; have {names[:4]}"
        a = h.select(band)[:]
        h.end()
        return np.asarray(a), "ok"
    except Exception as e:
        return None, str(e)[:110]


def try_xarray(path, band):
    try:
        import xarray as xr
    except ImportError:
        return None, "xarray not installed"
    for eng in ("netcdf4", "h5netcdf", None):
        try:
            ds = xr.open_dataset(path, engine=eng) if eng else xr.open_dataset(path)
            if band in ds:
                return np.asarray(ds[band].values), f"ok (engine={eng})"
            ds.close()
        except Exception:
            continue
    return None, "no xarray engine could open it"


def summarise(a, label):
    if a is None:
        return
    a = a.astype("float64")
    v = a[(a != 0) & np.isfinite(a)]
    if v.size == 0:
        print(f"      {label}: all fill/zero")
        return
    c = v * 0.02 - 273.15
    print(f"      {label}: shape {a.shape}, {v.size} valid, "
          f"{c.min():.1f} .. {c.max():.1f} C after scale 0.02 and K->C")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="data/raw/modis")
    ap.add_argument("--file", default=None)
    args = ap.parse_args()

    if args.file:
        files = [args.file]
    else:
        files = sorted(glob.glob(os.path.join(args.root, "**", "*.hdf"),
                                 recursive=True))
    print("=" * 74)
    print("MODIS READ DIAGNOSIS")
    print("=" * 74)
    print(f"  .hdf files found: {len(files)}")
    other = sorted(glob.glob(os.path.join(args.root, "**", "*.*"),
                             recursive=True))
    exts = {}
    for f in other:
        exts[os.path.splitext(f)[1].lower()] = exts.get(
            os.path.splitext(f)[1].lower(), 0) + 1
    print(f"  extensions present: {dict(sorted(exts.items(), key=lambda x:-x[1])[:6])}")
    if not files:
        print("\n  No .hdf files. If the download produced .jpg browse images,")
        print("  earthaccess selected the wrong asset: filter data_links() to")
        print("  entries ending in .hdf before calling download().")
        return

    f = files[0]
    print(f"\n  testing: {os.path.basename(f)}")
    print(f"  size: {os.path.getsize(f):,} bytes")
    if os.path.getsize(f) < 100_000:
        print("  [warn] very small for a MODIS granule (expect ~1-6 MB);")
        print("  this may be a browse image or a truncated download.")

    with open(f, "rb") as fh:
        magic = fh.read(8)
    print(f"  magic bytes: {magic[:4]!r}  "
          f"({'HDF4' if magic[:4] == b'\\x0e\\x03\\x13\\x01' else 'HDF5/NetCDF4' if magic[:4] == b'\\x89HDF' else 'JPEG' if magic[:2] == b'\\xff\\xd8' else 'unknown'})")

    print("\n  1. GDAL subdataset listing")
    subs, msg = try_gdal_list(f)
    print(f"     {msg}")
    if subs:
        for s in subs[:4]:
            print(f"       {s[:100]}")

    for band in BANDS:
        print(f"\n  band {band}")
        for name, fn in (("rioxarray", try_rioxarray),
                         ("pyhdf", try_pyhdf),
                         ("xarray", try_xarray)):
            a, msg = fn(f, band)
            print(f"    {name:<10} {'OK' if a is not None else 'FAIL'}  {msg}")
            summarise(a, name)

    print("\n" + "=" * 74)
    print("LIKELY REMEDY")
    print("=" * 74)
    if subs is None:
        print("  GDAL is absent or lacks the HDF4 driver. Either")
        print("    conda install -c conda-forge gdal libgdal-hdf4")
        print("  or bypass GDAL entirely:")
        print("    pip install pyhdf")
        print("  pyhdf reads HDF4 directly and is the more reliable route on")
        print("  Windows. modis_analysis.py can be pointed at it.")
    else:
        print("  GDAL can list subdatasets, so the driver exists. If rioxarray")
        print("  still fails, the subdataset NAME is wrong -- compare the")
        print("  listing above against the string modis_analysis.py builds.")


if __name__ == "__main__":
    main()
