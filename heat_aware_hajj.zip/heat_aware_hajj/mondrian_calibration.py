"""
Mondrian (stratified) conformal calibration in two diurnal strata.

WHY. residual_diagnostics.py showed the nonconformity scores are heteroscedastic
across time of day: raw scores span 3.78x between the easiest and hardest bin,
2.35x after variance normalisation. Midday is hardest (strongest spatial thermal
contrast between shaded and sunlit surfaces); evening is easiest.

Marginal conformal prediction assumes exchangeable scores. With this structure it
would OVER-cover at night and UNDER-cover at midday -- the interval would be
valid on average while being wrong exactly when it matters, since heat risk is a
midday problem.

FIX. Mondrian conformal: partition the calibration set into strata and calibrate
independently within each. Coverage then holds CONDITIONALLY on the stratum.
Two strata are the most 33 scenes can support; five would leave ~7 each.

THE COST, AND WHY IT HELPS THE ARGUMENT. Splitting reduces per-stratum n, and
split conformal returns an infinite interval whenever alpha < 1/(n+1). With
n ~ 14-19 per stratum it degenerates at alpha < 0.05-0.07, i.e. it fails even at
the conventional 95% level, while the extreme-value calibrator stays finite. The
correct conditionally-valid treatment therefore makes the ECP result stronger,
not weaker.

Run (after residual_diagnostics.py has written residual_scores.json):
    python mondrian_calibration.py
    python mondrian_calibration.py --score raw --day 8 19
    python mondrian_calibration.py --alphas 0.10 0.05 0.02 0.01
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import warnings

warnings.filterwarnings("ignore")

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
def split_conformal_width(scores, alpha):
    """
    Classical split-conformal half-width: the ceil((1-alpha)(n+1))-th order
    statistic. Returns +inf when that index exceeds n, which is the degeneracy
    the extreme-value calibrator is designed to remove.
    """
    s = np.sort(np.asarray(scores, float))
    n = s.size
    k = int(np.ceil((1.0 - alpha) * (n + 1)))
    return float(s[k - 1]) if k <= n else float("inf")


def ecp_width(scores, alpha, threshold_q=0.80):
    """
    Extreme conformal: fit a GPD to the upper tail of the scores and read the
    required extreme quantile from the fitted tail, so the width stays finite
    for any alpha > 0.

    Falls back to the empirical quantile below the threshold. Returns
    (width, xi, n_exceed) with xi NaN if too few exceedances to fit.
    """
    from scipy.stats import genpareto

    s = np.asarray(scores, float)
    s = s[np.isfinite(s)]
    n = s.size
    p = 1.0 - alpha
    u = float(np.quantile(s, threshold_q))
    exc = s[s > u] - u
    zeta = exc.size / n

    if p <= 1.0 - zeta:                       # inside the body: empirical
        return float(np.quantile(s, p)), float("nan"), int(exc.size)
    if exc.size < 5:                          # cannot fit a tail
        return float("nan"), float("nan"), int(exc.size)

    xi, _, sc = genpareto.fit(exc, floc=0)
    r = (1.0 - p) / max(zeta, 1e-12)
    if abs(xi) < 1e-6:
        w = u - sc * np.log(r)
    else:
        w = u + (sc / xi) * (r ** (-xi) - 1.0)
    return float(w), float(xi), int(exc.size)


def stratify(hours, day_lo, day_hi):
    """Boolean day mask on local solar hour."""
    h = np.asarray(hours, float)
    return (h >= day_lo) & (h < day_hi)


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scores", default="residual_scores.json")
    ap.add_argument("--score", default="normalised",
                    choices=["raw", "normalised"])
    ap.add_argument("--day", nargs=2, type=float, default=[8.0, 19.0],
                    metavar=("LO", "HI"), help="local-hour bounds of the day stratum")
    ap.add_argument("--alphas", nargs="+", type=float,
                    default=[0.10, 0.05, 0.02, 0.01, 0.005])
    ap.add_argument("--threshold-q", type=float, default=0.80)
    args = ap.parse_args()

    d = json.load(open(args.scores))
    s = np.asarray(d[args.score], float)
    h = np.asarray(d["hour"], float)
    ok = np.isfinite(s) & np.isfinite(h)
    s, h = s[ok], h[ok]

    day = stratify(h, *args.day)
    strata = {"day": s[day], "night": s[~day]}

    print("=" * 78)
    print(f"MONDRIAN CONFORMAL  ({args.score} scores, "
          f"day = {args.day[0]:.0f}-{args.day[1]:.0f}h local)")
    print("=" * 78)
    print(f"  pooled n = {s.size}")
    for k, v in strata.items():
        if v.size:
            print(f"  {k:<6} n = {v.size:3d}   mean {v.mean():6.3f}  "
                  f"sd {v.std():6.3f}  max {v.max():6.3f}")
    ratio = (strata["day"].mean() / max(strata["night"].mean(), 1e-9)
             if strata["day"].size and strata["night"].size else np.nan)
    print(f"  day/night mean score ratio = {ratio:.2f}")

    # Do NOT assert that the strata differ -- test it. An earlier version
    # printed "the two strata are genuinely different populations"
    # unconditionally, which was false on a run where the ratio came out 0.99.
    # Whether stratification is warranted is an empirical question, and if the
    # scores are homogeneous then marginal calibration is the correct choice
    # and Mondrian has nothing to fix.
    if np.isfinite(ratio):
        lo, hi = min(ratio, 1 / ratio), max(ratio, 1 / ratio)
        try:
            from scipy import stats as _st
            tt = _st.mannwhitneyu(strata["day"], strata["night"],
                                  alternative="two-sided")
            pval = float(tt.pvalue)
        except Exception:
            pval = float("nan")
        pstr = "" if not np.isfinite(pval) else f", Mann-Whitney p = {pval:.3f}"
        if hi < 1.15:
            print(f"  -> the strata are NOT distinguishable{pstr}.")
            print("     Stratification is unwarranted on this sample: report the")
            print("     POOLED result and say that no diurnal heteroscedasticity")
            print("     was detected. Do not claim a conditional-validity fix")
            print("     for a problem the data does not exhibit.")
        elif hi < 1.4:
            print(f"  -> the strata differ modestly{pstr}. Stratification is")
            print("     defensible but the effect is small; report both pooled")
            print("     and stratified results.")
        else:
            print(f"  -> the strata differ substantially{pstr}: pooling would")
            print("     over-cover in the low-score stratum and under-cover in")
            print("     the high-score one.")

    print("\n  degeneracy thresholds (split conformal is infinite below these):")
    for k, v in strata.items():
        if v.size:
            print(f"    {k:<6} n={v.size:3d}  alpha < {1.0/(v.size+1):.4f}")
    print(f"    pooled n={s.size:3d}  alpha < {1.0/(s.size+1):.4f}")

    # ---- the table ----
    for k, v in strata.items():
        if v.size:
            n_exc = int((v > np.quantile(v, args.threshold_q)).sum())
            if n_exc < 5:
                print(f"  [warn] stratum '{k}' has {n_exc} exceedances at "
                      f"q{args.threshold_q:.2f} (n={v.size}); the GPD cannot be "
                      f"fitted and ECP will report n/a. Lower --threshold-q, "
                      f"merge the strata, or report the pooled result.")

    print("\n" + "-" * 78)
    hdr = f"{'alpha':>7} | {'stratum':>7} | {'n':>4} | {'split':>10} | {'ECP':>10} | {'xi':>7}"
    print(hdr); print("-" * 78)
    rows = []
    for a in args.alphas:
        for k, v in strata.items():
            if v.size == 0:
                continue
            sw = split_conformal_width(v, a)
            ew, xi, nex = ecp_width(v, a, args.threshold_q)
            rows.append({"alpha": a, "stratum": k, "n": int(v.size),
                         "split": sw, "ecp": ew, "xi": xi, "n_exceed": nex})
            sw_s = "INFINITE" if not np.isfinite(sw) else f"{sw:10.3f}"
            ew_s = "  n/a" if not np.isfinite(ew) else f"{ew:10.3f}"
            xi_s = "   --" if not np.isfinite(xi) else f"{xi:+7.3f}"
            print(f"{a:>7.3f} | {k:>7} | {v.size:>4} | {sw_s:>10} | {ew_s:>10} | {xi_s}")
        # pooled, for comparison
        sw = split_conformal_width(s, a)
        ew, xi, nex = ecp_width(s, a, args.threshold_q)
        sw_s = "INFINITE" if not np.isfinite(sw) else f"{sw:10.3f}"
        ew_s = "  n/a" if not np.isfinite(ew) else f"{ew:10.3f}"
        print(f"{a:>7.3f} | {'pooled':>7} | {s.size:>4} | {sw_s:>10} | {ew_s:>10} |"
              f" {'   --' if not np.isfinite(xi) else f'{xi:+7.3f}'}")
        print("-" * 78)

    # ---- empirical conditional coverage of a POOLED interval ----
    print("\n  what pooling would do (leave-one-out, pooled interval, per stratum):")
    for a in [x for x in args.alphas if x >= 0.05]:
        cov = {}
        for k, v in strata.items():
            if v.size < 3:
                continue
            hit = 0
            for i in range(v.size):
                others = np.concatenate([s[:0], np.delete(s, np.where(s == v[i])[0][:1])])
                w = split_conformal_width(others, a)
                hit += int(v[i] <= w)
            cov[k] = hit / v.size
        if cov:
            line = "   ".join(f"{k} {c:.3f}" for k, c in cov.items())
            print(f"    alpha={a:.2f} (nominal coverage {1-a:.2f}):  {line}")
    print("    -> deviation between strata is the conditional-validity failure")
    print("       that Mondrian calibration removes.")

    # flag boundary fits: xi far below the MLE regularity bound means the GPD
    # has collapsed onto the sample maximum rather than estimating a tail
    xis = [r["xi"] for r in rows if np.isfinite(r.get("xi", np.nan))]
    if xis and min(xis) < -0.5:
        print(f"\n  [warn] fitted GPD shape reaches {min(xis):+.2f}, below the "
              f"xi > -0.5 regularity bound.")
        print("  The fit has collapsed onto the sample maximum: ECP widths")
        print("  approach the largest observed score rather than extrapolating.")
        print("  Report widths, not tail indices, and give the exceedance count.")

    json.dump(rows, open("mondrian_results.json", "w"), indent=2)

    # ---- figure ----
    fig, ax = plt.subplots(1, 2, figsize=(9.4, 3.3))
    ax[0].scatter(h[day], s[day], s=26, color="#c0392b", label=f"day (n={day.sum()})")
    ax[0].scatter(h[~day], s[~day], s=26, color="#2c3e50",
                  label=f"night (n={(~day).sum()})")
    for b in args.day:
        ax[0].axvline(b, ls="--", color="k", lw=.8)
    ax[0].set_xlabel("local solar hour"); ax[0].set_ylabel(f"{args.score} score")
    ax[0].set_title("(a) two diurnal strata"); ax[0].legend(frameon=False, fontsize=7)
    ax[0].grid(alpha=.25)

    al = np.array([r["alpha"] for r in rows if r["stratum"] == "day"])
    for k, c in (("day", "#c0392b"), ("night", "#2c3e50")):
        sub = [r for r in rows if r["stratum"] == k]
        if not sub:
            continue
        aa = [r["alpha"] for r in sub]
        sp = [r["split"] for r in sub]; ep = [r["ecp"] for r in sub]
        fin = np.isfinite(sp)
        ax[1].plot(np.array(aa)[fin], np.array(sp)[fin], "o--", color=c, ms=4,
                   alpha=.6, label=f"{k} split")
        ax[1].plot(aa, ep, "s-", color=c, ms=4, label=f"{k} ECP")
    ax[1].set_xscale("log"); ax[1].invert_xaxis()
    ax[1].set_xlabel(r"$\alpha$ (decreasing)"); ax[1].set_ylabel("interval half-width")
    ax[1].set_title("(b) split degenerates, ECP does not")
    ax[1].legend(frameon=False, fontsize=6.5); ax[1].grid(alpha=.25)
    fig.tight_layout(); fig.savefig("mondrian_calibration.png", dpi=140)

    print("\n  results -> mondrian_results.json")
    print("  figure  -> mondrian_calibration.png")
    print("\n  Report the per-stratum table as Table 1. The point to make: the")
    print("  conditionally-valid treatment REDUCES per-stratum n, and it is")
    print("  exactly in that regime that split conformal degenerates while the")
    print("  extreme-value calibrator remains finite.")


if __name__ == "__main__":
    main()
