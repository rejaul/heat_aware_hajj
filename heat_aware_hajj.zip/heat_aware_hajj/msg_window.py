"""
Map the study corridor to SEVIRI grid rows and columns.

WHY THIS IS NEEDED. SEVIRI images are not on a lat/lon grid. MSG is
geostationary, so the native grid is the satellite's own scanning geometry: a
pixel is identified by the scan angles from the satellite to that point on the
Earth ellipsoid. Converting a lat/lon box to rows and columns therefore needs
the projection constants (CFAC, LFAC, COFF, LOFF) from the LRIT/HRIT global
specification, not a simple linear interpolation.

Getting this wrong fails silently: the script would happily compute statistics
over a window somewhere else entirely. That is the same class of fault as the
uncropped ECOSTRESS tiles, so it is worth doing explicitly and checking.

GEOMETRY CAVEAT FOR MAKKAH. MSG sits at 0 degrees longitude; Makkah is at
39.89 E, 21.42 N. The resulting viewing zenith angle is large (this script
computes it), so the nominal 3 km sub-satellite resolution degrades
substantially here, and the pixel footprint is elongated. The script reports
both so the effective resolution is stated rather than assumed.

Run:
    python msg_window.py                      # corridor window, full-disk grid
    python msg_window.py --file one_granule.h5   # read constants from the file
    python msg_window.py --sub-lon 9.5        # MSG at 9.5 E (IODC service)
"""
from __future__ import annotations

import argparse
import json
import math
import warnings

warnings.filterwarnings("ignore")

import numpy as np

# WGS-84-ish constants used by the LRIT/HRIT global specification
R_EQ = 6378.1690          # km, equatorial radius
R_POL = 6356.5838         # km, polar radius
H_SAT = 42164.0           # km, satellite distance from Earth centre
E2 = 1.0 - (R_POL ** 2) / (R_EQ ** 2)

# Full-disk SEVIRI (non-HRV) nominal constants
CFAC_FD = -781648343.0
LFAC_FD = -781648343.0
COFF_FD = 1856.0
LOFF_FD = 1856.0


def geo_to_pixel(lat, lon, sub_lon=0.0,
                 cfac=CFAC_FD, lfac=LFAC_FD, coff=COFF_FD, loff=LOFF_FD):
    """
    Latitude/longitude to SEVIRI column and line.

    Follows the LRIT/HRIT Global Specification (CGMS 03). Returns
    (column, line, visible) where visible is False if the point lies behind the
    Earth's limb as seen from the satellite.
    """
    lat = math.radians(float(lat))
    lon = math.radians(float(lon) - float(sub_lon))

    # geodetic to geocentric latitude on the reference ellipsoid
    c_lat = math.atan(((R_POL ** 2) / (R_EQ ** 2)) * math.tan(lat))
    r_l = R_POL / math.sqrt(1.0 - E2 * (math.cos(c_lat) ** 2))

    r1 = H_SAT - r_l * math.cos(c_lat) * math.cos(lon)
    r2 = -r_l * math.cos(c_lat) * math.sin(lon)
    r3 = r_l * math.sin(c_lat)
    rn = math.sqrt(r1 * r1 + r2 * r2 + r3 * r3)

    # limb test: the point must be on the near side of the Earth
    visible = (r1 * (r1 - H_SAT) + r2 * r2 + r3 * r3) <= 0.0

    # Scan-angle UNITS depend on how the file scales CFAC/LFAC, and the two
    # conventions in circulation differ by a factor of 180/pi:
    #
    #   CFAC ~ -781648343  the LRIT/HRIT global specification, angles in RADIANS
    #   CFAC ~  +13642337  the LSA SAF HDF5 products, angles in DEGREES
    #
    # Choosing wrongly does not fail loudly: it returns a pixel that is simply
    # somewhere else. With the LSA SAF files the radian form puts Makkah at
    # column 1878, essentially at nadir over the Atlantic, where LST is fill
    # because the product is land-only, and every read silently returns None.
    # We therefore pick the convention from the magnitude of CFAC.
    use_degrees = abs(cfac) < 1e8
    x = math.atan(-r2 / r1)
    y = math.asin(-r3 / rn)
    if use_degrees:
        x, y = math.degrees(x), math.degrees(y)

    col = coff + x * (2.0 ** -16) * cfac
    line = loff + y * (2.0 ** -16) * lfac
    return col, line, visible


def viewing_zenith(lat, lon, sub_lon=0.0):
    """Satellite zenith angle at the target, which sets effective resolution."""
    lat_r, lon_r = math.radians(lat), math.radians(lon - sub_lon)
    cos_psi = math.cos(lat_r) * math.cos(lon_r)
    re = R_EQ
    num = H_SAT * math.sqrt(1.0 - cos_psi ** 2)
    den = math.sqrt(H_SAT ** 2 + re ** 2 - 2.0 * H_SAT * re * cos_psi)
    return math.degrees(math.asin(min(1.0, num / den)))


def read_constants(path):
    """Pull projection constants from an LSA SAF granule if present."""
    try:
        import h5py
    except ImportError:
        return None
    out = {}
    try:
        with h5py.File(path, "r") as f:
            for k, v in f.attrs.items():
                ku = k.upper()
                for name in ("CFAC", "LFAC", "COFF", "LOFF",
                             "SUB_SATELLITE_POINT", "NC", "NL", "REGION"):
                    if name in ku:
                        try:
                            out[name] = (v.decode() if isinstance(v, bytes)
                                         else (float(v) if np.isscalar(v) else v))
                        except Exception:
                            out[name] = v
            out["_datasets"] = list(f.keys())[:10]
            for k in f.keys():
                if "LST" in k.upper():
                    out["_shape"] = f[k].shape
                    break
    except Exception as e:
        out["_error"] = str(e)[:90]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bbox", help="west,south,east,north (default config.BBOX)")
    ap.add_argument("--sub-lon", type=float, default=0.0,
                    help="sub-satellite longitude: 0 for MSG prime, 9.5 for IODC")
    ap.add_argument("--file", default=None,
                    help="an LSA SAF granule, to read its constants and shape")
    ap.add_argument("--pad", type=int, default=1, help="pixels of margin")
    args = ap.parse_args()

    if args.bbox:
        bbox = tuple(float(x) for x in args.bbox.split(","))
    else:
        try:
            import config
            bbox = config.BBOX
        except Exception:
            bbox = (39.786, 21.315, 40.024, 21.462)
    west, south, east, north = bbox

    cfac, lfac, coff, loff = CFAC_FD, LFAC_FD, COFF_FD, LOFF_FD
    shape = None
    print("=" * 74)
    print("MSG / SEVIRI GRID WINDOW FOR THE CORRIDOR")
    print("=" * 74)
    print(f"  bbox      : {bbox}")
    print(f"  sub-sat   : {args.sub_lon:.1f} deg E")

    if args.file:
        c = read_constants(args.file)
        print(f"\n  constants read from {args.file}:")
        for k, v in (c or {}).items():
            print(f"    {k}: {v}")
        if c:
            cfac = float(c.get("CFAC", cfac)); lfac = float(c.get("LFAC", lfac))
            coff = float(c.get("COFF", coff)); loff = float(c.get("LOFF", loff))
            shape = c.get("_shape")
        print("\n  NOTE: a REGIONAL subset (NAfr, Euro...) has its own COFF/LOFF")
        print("  offsets relative to the full disk. If the file supplies them,")
        print("  they are used above; if not, the window below is in FULL-DISK")
        print("  coordinates and must be shifted by the subset's origin.")

    print(f"\n  using CFAC {cfac:.0f}  LFAC {lfac:.0f}  COFF {coff:.0f}  LOFF {loff:.0f}")

    corners = [("SW", south, west), ("SE", south, east),
               ("NW", north, west), ("NE", north, east)]
    print(f"\n  {'corner':>7}{'lat':>9}{'lon':>9}{'column':>10}{'line':>10}{'visible':>9}")
    cols, lines = [], []
    for nm, la, lo in corners:
        c_, l_, vis = geo_to_pixel(la, lo, args.sub_lon, cfac, lfac, coff, loff)
        cols.append(c_); lines.append(l_)
        print(f"  {nm:>7}{la:>9.3f}{lo:>9.3f}{c_:>10.2f}{l_:>10.2f}{str(vis):>9}")

    c0, c1 = int(math.floor(min(cols))) - args.pad, int(math.ceil(max(cols))) + args.pad
    l0, l1 = int(math.floor(min(lines))) - args.pad, int(math.ceil(max(lines))) + args.pad

    # sanity: nadir must land on COFF/LOFF, or the convention is wrong
    nc, nl, _ = geo_to_pixel(0.0, args.sub_lon, args.sub_lon, cfac, lfac, coff, loff)
    conv = "degrees" if abs(cfac) < 1e8 else "radians"
    print(f"\n  scan-angle convention: {conv} (from |CFAC|)")
    print(f"  check: sub-satellite point maps to column {nc:.1f}, line {nl:.1f}"
          f"  (should equal COFF/LOFF = {coff:.0f}/{loff:.0f})")

    vz = viewing_zenith((south + north) / 2, (west + east) / 2, args.sub_lon)
    # footprint stretches roughly as 1/cos(zenith) along the view direction
    nadir_km = 3.0
    eff_km = nadir_km / max(math.cos(math.radians(vz)), 1e-3)

    print(f"\n  WINDOW (full-disk coordinates, {args.pad} px margin)")
    print(f"    columns {c0} .. {c1}   ({c1 - c0} px)")
    print(f"    lines   {l0} .. {l1}   ({l1 - l0} px)")
    if shape:
        print(f"    granule shape from file: {shape}")
        if l1 > shape[0] or c1 > shape[1]:
            print("    [warn] window exceeds the granule: this is a REGIONAL")
            print("    subset, so subtract the subset origin from both.")

    print(f"\n  VIEWING GEOMETRY")
    print(f"    satellite zenith angle at the corridor: {vz:.1f} deg")
    print(f"    nominal resolution {nadir_km:.1f} km at nadir")
    print(f"    effective along-view footprint ~{eff_km:.1f} km here")
    print("    The corridor is roughly 25 x 16 km, so it spans only a few")
    print("    pixels. Adequate for a corridor-aggregate tail statistic;")
    print("    not usable for routing.")

    print(f"\n  Run the analysis with:")
    print(f"    python seviri_tail.py --window {l0} {l1} {c0} {c1}")

    json.dump({"bbox": list(bbox), "sub_lon": args.sub_lon,
               "window": {"line0": l0, "line1": l1, "col0": c0, "col1": c1},
               "zenith_deg": vz, "effective_km": eff_km},
              open("msg_window.json", "w"), indent=2)
    print("\n  saved -> msg_window.json")


if __name__ == "__main__":
    main()
