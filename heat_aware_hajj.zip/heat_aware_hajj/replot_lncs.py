"""
Redraw the paper figures at LNCS text width so their labels print legibly.

The originals were drawn 12.2 in wide and included at 0.57\\textwidth (2.74 in),
a scale factor of 0.22 that printed 8 pt labels at 1.8 pt. See lncs_style.py.

This script redraws the figures whose inputs are self-contained or survive as
JSON. Figures needing the heavy artefacts (field_prob.npy, the cached network,
the MODIS and ERA5 result files) must be redrawn on the machine that holds
them; add `use_lncs()` and `figsize=FIGSIZE_1x3` to their scripts and rerun.

Run:  python replot_lncs.py --out ../camera_ready/figs
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lncs_style import use_lncs, FIGSIZE_1x3, check            # noqa: E402

use_lncs(base=7.0)
import matplotlib.pyplot as plt                                 # noqa: E402

from capacity_analysis import (MODELS, fd_weidmann, optimum)     # noqa: E402

RHO_CRIT = 4.0
RHO_OBS = (6.0, 10.0)
WIDTH_M = 8.0
LENGTH_M = 12000.0
EXPOSURE = 0.61
N_PED = 100_000.0


def fig_capacity(out: str) -> str:
    """(a) flow across five relations, (b) thermal dose, (c) clearance time."""
    r_s, v_s, q_s = optimum(fd_weidmann)
    fig, ax = plt.subplots(1, 3, figsize=FIGSIZE_1x3)
    r = np.linspace(0.05, 6.0, 800)

    short = {"Weidmann (1993)": "Weidmann", "Older (1968)": "Older",
             "Greenshields-type": "Greenshields", "SFPE / Nelson-Mowrer": "SFPE",
             "exponential": "exponential"}
    for nm, fd in MODELS.items():
        ax[0].plot(r, r * fd(r), lw=1.0, label=short.get(nm, nm))
    ax[0].axvline(RHO_CRIT, ls="--", color="#c0392b", lw=0.8)
    ax[0].axvspan(min(RHO_OBS), max(RHO_OBS), color="#c0392b", alpha=.12)
    ax[0].set_xlabel(r"density $\rho$ (ped/m$^2$)")
    ax[0].set_ylabel(r"flow $q$ (ped/m/s)")
    ax[0].set_title("(a) flow peaks below crush onset")
    ax[0].legend(fontsize=5.4, loc="lower right", handlelength=1.0,
                 borderaxespad=0.2, labelspacing=0.18)
    ax[0].grid(alpha=.25)
    # x out to 10 so the shaded band of reported Hajj densities, which the
    # caption refers to, is actually on the axes
    ax[0].set_xlim(0, 10)
    ax[0].set_xticks([0, 2, 4, 6, 8, 10])
    ax[0].annotate("reported\nHajj densities", xy=(8.0, 1.55), ha="center",
                   fontsize=5.2, color="#c0392b")

    v = np.maximum(fd_weidmann(r), 1e-3)
    dose = EXPOSURE * LENGTH_M / v
    valid = fd_weidmann(r) >= 0.05
    ax[1].semilogy(r[valid], dose[valid], color="#8e44ad", lw=1.3)
    ax[1].axvspan(r[valid].max(), r.max(), color="k", alpha=.08)
    ax[1].text(r[valid].max() + .12, dose[valid].max() * .45,
               "model\nnot valid", fontsize=5.4, color="k", va="top")
    ax[1].axvline(r_s, ls="-", color="#27ae60", lw=1.0, label=r"$\rho^*$")
    ax[1].axvline(RHO_CRIT, ls="--", color="#c0392b", lw=0.8,
                  label="crush onset")
    ax[1].set_xlabel(r"density $\rho$ (ped/m$^2$)")
    ax[1].set_ylabel("thermal dose (log)")
    ax[1].set_title("(b) crowding multiplies dose")
    ax[1].legend(fontsize=5.6, loc="upper left", handlelength=1.0,
                 borderaxespad=0.2, labelspacing=0.18)
    ax[1].grid(alpha=.25)
    ax[1].set_xlim(0, 6)

    flow = r * v * WIDTH_M
    tclear = N_PED / np.maximum(flow, 1e-9) / 3600.0
    ax[2].plot(r[valid], tclear[valid], color="#1f4e79", lw=1.3)
    ax[2].axvspan(r[valid].max(), r.max(), color="k", alpha=.08)
    ax[2].axvline(r_s, ls="-", color="#27ae60", lw=1.0)
    ax[2].axvline(RHO_CRIT, ls="--", color="#c0392b", lw=0.8)
    ax[2].set_ylim(0, tclear[np.argmin(np.abs(r - r_s))] * 6)
    ax[2].set_xlabel(r"density $\rho$ (ped/m$^2$)")
    ax[2].set_ylabel("hours to clear")
    ax[2].set_title(r"(c) clearance minimised at $\rho^*$")
    ax[2].grid(alpha=.25)
    ax[2].set_xlim(0, 6)

    fig.tight_layout(pad=0.35, w_pad=0.9)
    fig.savefig(out)
    plt.close(fig)
    return out


def fig_dwell(out: str, src: str = "dwell_dose.json") -> str | None:
    """Travel versus stationary share of cumulative exposure."""
    if not os.path.exists(src):
        return None
    d = json.load(open(src))
    fig, ax = plt.subplots(1, 2, figsize=(FIGSIZE_1x3[0] * 0.68, 1.55))

    walk = _num(d, ["walk_hours", "travel_hours", "hours_walking"])
    stat = _num(d, ["dwell_hours", "stationary_hours", "hours_stationary"])
    share = _num(d, ["travel_share", "share", "travel_fraction"])
    lo = _num(d, ["ci_low", "share_low", "lo"])
    hi = _num(d, ["ci_high", "share_high", "hi"])
    if None in (walk, stat):
        return None

    ax[0].bar(["walking", "stationary"], [walk, stat],
              color=["#1f4e79", "#c0392b"], width=.6)
    for i, val in enumerate([walk, stat]):
        ax[0].text(i, val, f"{val:.1f} h", ha="center", va="bottom",
                   fontsize=6)
    ax[0].set_ylabel("hours over five days")
    ax[0].set_title("(a) where the time goes")
    ax[0].set_ylim(0, max(walk, stat) * 1.22)
    ax[0].grid(alpha=.25, axis="y")

    if share is not None:
        ax[1].bar(["travel"], [share * 100], color="#1f4e79", width=.45)
        if lo is not None and hi is not None:
            ax[1].errorbar([0], [share * 100], color="k", lw=0.9, capsize=2.5,
                           yerr=[[(share - lo) * 100], [(hi - share) * 100]])
        ax[1].set_ylabel("% of cumulative dose")
        ax[1].set_title("(b) share routing can act on")
        ax[1].set_ylim(0, 100)
        ax[1].grid(alpha=.25, axis="y")

    fig.tight_layout(pad=0.35, w_pad=0.9)
    fig.savefig(out)
    plt.close(fig)
    return out


def _num(d: dict, keys: list[str]):
    for k in keys:
        if k in d and isinstance(d[k], (int, float)):
            return float(d[k])
    for v in d.values():
        if isinstance(v, dict):
            got = _num(v, keys)
            if got is not None:
                return got
    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="../camera_ready/figs")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    made = [fig_capacity(os.path.join(args.out, "capacity_analysis.pdf"))]
    made.append(fig_dwell(os.path.join(args.out, "fig_dwell.pdf")))

    print("redrawn at LNCS text width, include at width=\\textwidth:\n")
    for p in made:
        if not p:
            continue
        r = check(p, included_at=1.0)
        tag = "OK       " if r["legible"] else "TOO SMALL"
        print(f"  {tag} {os.path.basename(p)}  "
              f"drawn {r['drawn_width_pt']:.0f}x{r['drawn_height_pt']:.0f} pt, "
              f"scale {r['scale_on_page']:.2f}, "
              f"labels print at {r['body_printed_pt']:.1f} pt "
              f"(body text 10 pt)")

    print("\nstill drawn at 12 in and illegible on the page "
          "(redraw where the data lives):")
    for f in ("fig_era5_bias.pdf", "fig_diagnostics.pdf", "fig_modis.pdf",
              "fig_negative.pdf"):
        p = os.path.join(args.out, f)
        if not os.path.exists(p):
            continue
        r = check(p, included_at=0.53)
        print(f"  TOO SMALL {f}  labels print at "
              f"{r['body_printed_pt']:.1f} pt at 0.53\\textwidth")


if __name__ == "__main__":
    main()
