"""
Residual diagnostics: the bridge between the trained downscaler and ECP.

WHY THIS EXISTS. run_tail_check.py analyses raw `lst_fine`, but extreme conformal
prediction does not model LST -- it models the NONCONFORMITY SCORES. So the tail
question that matters for the paper is "are the model residuals heavy-tailed?",
not "is LST heavy-tailed?". The bounded tail found in raw LST is largely the
ceiling of the diurnal cycle (time of day explains ~94% of the variance) and may
say nothing about the residual distribution. Residuals can be heavy-tailed even
when the raw field is bounded, if the model fails badly on a few scenes.

WHAT IT CHECKS, in the order that matters:

  1. EXCHANGEABILITY OF SCORES. Conformal needs the scores exchangeable, not the
     raw data. If the model conditions on solar geometry and predicts equally
     well at every hour, residuals may be exchangeable even though LST plainly
     is not. Tested as: is residual spread flat across local solar hour?

  2. HETEROSCEDASTICITY REMEDY. If spread grows at midday (likely -- more
     spatial thermal contrast), the fix is a normalised score
     s = |y - mu| / sigma using the heteroscedastic head, which is exactly what
     that head is for. Both raw and normalised scores are reported so you can
     see whether normalisation restores homoscedasticity.

  3. TAIL BEHAVIOUR OF THE SCORES. Runs the same GPD/Hill/MRL machinery, but on
     the scores that ECP will actually consume.

  4. ONE SCORE PER SCENE. Pixels within a scene are far too correlated to count
     as independent draws, so each calibration scene is reduced to a single
     score. n = number of calibration scenes, and that is the n that decides
     where split conformal goes infinite.

Run (after train.py):
    python residual_diagnostics.py
    python residual_diagnostics.py --score normalised --reduce q99
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import re
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TS = re.compile(r"(\d{8})T(\d{6})")
UTC_OFFSET_H = 3.0


def local_hour(path):
    m = TS.search(str(path))
    if not m:
        return np.nan
    tm = m.group(2)
    utc = int(tm[:2]) + int(tm[2:4]) / 60.0
    return (utc + UTC_OFFSET_H) % 24.0


# ---------------------------------------------------------------------------
def scene_scores(files, ckpt_path, device="cpu", reduce="q99", tile=512):
    """
    Predict on each scene and reduce to ONE nonconformity score per scene.

    Returns dict of arrays: raw |y-mu|, normalised |y-mu|/sigma, sigma, hour.
    """
    import torch
    import xarray as xr
    from model import AMUN
    from dataset import PREDICTORS, TARGET, BASELINE, HeatPairDataset

    ck = torch.load(ckpt_path, map_location=device)
    stats = ck.get("stats")
    hetero = ck.get("args", {}).get("heteroscedastic", True)
    net = AMUN(in_ch=len(PREDICTORS), heteroscedastic=hetero).to(device)
    net.load_state_dict(ck["model"])
    net.eval()

    ds_helper = HeatPairDataset(files, tile=tile, stats=stats, augment=False,
                                samples_per_file=1)

    raw, norm, sig, hrs, keep = [], [], [], [], []
    red = {"q99": lambda a: np.percentile(a, 99),
           "q95": lambda a: np.percentile(a, 95),
           "max": np.max, "mean": np.mean}[reduce]

    with torch.no_grad():
        for i, f in enumerate(files):
            x, base, y, mask = ds_helper[i]
            x = x[None].to(device); base = base[None].to(device)
            out = net(x, baseline=base)
            if isinstance(out, (tuple, list)):
                mu, log_sigma = out[0], out[1]
            elif out.shape[1] >= 2 and hetero:
                mu, log_sigma = out[:, 0:1], out[:, 1:2]
            else:
                mu, log_sigma = out, None

            m = mask[None].to(device).bool()
            if m.sum() == 0:
                continue
            resid = (y[None].to(device) - mu).abs()[m].cpu().numpy()
            if log_sigma is not None:
                s = torch.exp(log_sigma.clamp(-6, 4))[m].cpu().numpy()
            else:
                s = np.ones_like(resid)

            raw.append(float(red(resid)))
            norm.append(float(red(resid / np.maximum(s, 1e-6))))
            sig.append(float(np.median(s)))
            hrs.append(local_hour(f))
            keep.append(str(f))

    return {"raw": np.array(raw), "normalised": np.array(norm),
            "sigma": np.array(sig), "hour": np.array(hrs), "files": keep}


# ---------------------------------------------------------------------------
def homoscedasticity(hour, score, n_bins=5):
    """Is score spread flat across local hour? Returns per-bin stats + a ratio."""
    ok = np.isfinite(hour) & np.isfinite(score)
    hour, score = hour[ok], score[ok]
    if hour.size < 10:
        return [], np.nan, np.nan
    qs = np.quantile(hour, np.linspace(0, 1, n_bins + 1))
    rows = []
    for lo, hi in zip(qs[:-1], qs[1:]):
        sel = (hour >= lo) & (hour <= hi)
        if sel.sum() >= 3:
            rows.append({"lo": float(lo), "hi": float(hi), "n": int(sel.sum()),
                         "mean": float(score[sel].mean()),
                         "sd": float(score[sel].std())})
    if len(rows) < 2:
        return rows, np.nan, np.nan
    means = [r["mean"] for r in rows]
    ratio = max(means) / max(min(means), 1e-9)
    r = float(np.corrcoef(hour, score)[0, 1])
    return rows, ratio, r


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", default="checkpoints/amun_best.pt")
    ap.add_argument("--reduce", default="q99", choices=["q99", "q95", "max", "mean"])
    ap.add_argument("--score", default="both",
                    choices=["raw", "normalised", "both"])
    ap.add_argument("--split", default="calib", choices=["calib", "val", "train"])
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--tile", type=int, default=512)
    args = ap.parse_args()

    from dataset import split_files
    tr, va, cal = split_files(verbose=False)
    files = {"train": tr, "val": va, "calib": cal}[args.split]

    if not Path(args.ckpt).exists():
        raise SystemExit(f"No checkpoint at {args.ckpt}. Run train.py first.")

    print("=" * 74)
    print(f"RESIDUAL DIAGNOSTICS  ({args.split} split, {len(files)} scenes, "
          f"reduce={args.reduce})")
    print("=" * 74)
    print("  NOTE: ECP consumes these SCORES, not raw LST. The tail question")
    print("  that matters for the paper is answered here, not in run_tail_check.")

    d = scene_scores(files, args.ckpt, args.device, args.reduce, args.tile)
    n = d["raw"].size
    if n == 0:
        raise SystemExit("No usable scenes produced a score.")

    dates = {TS.search(f).group(1) for f in d["files"] if TS.search(f)}
    print(f"\n  scenes scored : {n}")
    print(f"  distinct dates: {len(dates)}")
    print(f"  local hours   : {np.nanmin(d['hour']):.1f} .. {np.nanmax(d['hour']):.1f}")
    print(f"\n  *** split conformal returns an INFINITE interval when")
    print(f"      alpha < 1/(n+1) = {1.0/(n+1):.4f}  (n = {n}) ***")

    which = ["raw", "normalised"] if args.score == "both" else [args.score]
    summaries = {}

    for key in which:
        s = d[key]
        print("\n" + "-" * 74)
        print(f"  SCORE = {key}")
        print("-" * 74)
        print(f"    range {s.min():.4f} .. {s.max():.4f}   "
              f"mean {s.mean():.4f}  sd {s.std():.4f}")

        rows, ratio, r = homoscedasticity(d["hour"], s)
        print("    spread across local hour:")
        for rr in rows:
            print(f"      {rr['lo']:5.1f}-{rr['hi']:5.1f}h  n={rr['n']:3d}  "
                  f"mean {rr['mean']:8.4f}  sd {rr['sd']:7.4f}")
        if np.isfinite(ratio):
            print(f"    max/min bin mean = {ratio:.2f}   corr(hour, score) = {r:+.3f}")
            if ratio < 1.5 and abs(r) < 0.3:
                print("    -> approximately HOMOSCEDASTIC: scores look exchangeable")
                print("       across time of day. Pooling all scenes is defensible.")
            else:
                print("    -> HETEROSCEDASTIC across hour. Raw residuals are NOT")
                print("       exchangeable. Use the normalised score, or calibrate")
                print("       within time bins (Mondrian conformal).")

        # tail behaviour OF THE SCORES
        try:
            from tail_diagnostics import run_tail_diagnostics
            print(f"\n    tail diagnostics on the {key} scores:")
            summ = run_tail_diagnostics(
                s, name=f"{key} scores (n={n})", threshold_q=0.90,
                out_png=f"residual_tail_{key}.png", verbose=False)
            g = summ["gpd_shape"]
            print(f"      GPD xi = {g['xi']:+.3f}  scale {g['scale']:.4f}  "
                  f"u=q90 {g['u']:.4f}  exceedances {g['n_exceed']}")
            print(f"      Hill xi = {summ['hill']['hill_xi']:+.3f}   "
                  f"QQ corr {summ['gof']['qq_corr']:.4f}")
            if np.isfinite(g["xi"]) and g["xi"] > 0.05:
                print("      -> HEAVY-tailed SCORES: the EVT calibration layer is")
                print("         justified on the quantity ECP actually models.")
            elif np.isfinite(g["xi"]) and g["xi"] < -0.05:
                print("      -> bounded score tail. ECP still guarantees finite")
                print("         intervals (that is a sample-size property, not a")
                print("         tail property), but do not claim heavy tails.")
            else:
                print("      -> ~exponential score tail.")
            if g["n_exceed"] < 15:
                print(f"      [caution] only {g['n_exceed']} exceedances; xi is")
                print("      indicative, not estimated.")
            summaries[key] = {"xi": g["xi"], "n_exceed": g["n_exceed"],
                              "ratio": ratio, "corr_hour": r}
        except Exception as e:
            print(f"      [tail diagnostics skipped: {e}]")

    # ---- figure ----
    fig, ax = plt.subplots(1, 3, figsize=(12.6, 3.4))
    ax[0].scatter(d["hour"], d["raw"], s=18, color="#c0392b", label="raw")
    if "normalised" in which:
        ax[0].scatter(d["hour"], d["normalised"], s=18, color="#1f4e79",
                      label="normalised")
    ax[0].set_xlabel("local solar hour"); ax[0].set_ylabel("scene score")
    ax[0].set_title("(a) score vs time of day"); ax[0].legend(frameon=False, fontsize=7)
    ax[0].grid(alpha=.25)

    ax[1].hist(d["raw"], bins=min(30, max(8, n // 3)), color="#c0392b", alpha=.8)
    ax[1].set_xlabel("raw score"); ax[1].set_ylabel("scenes")
    ax[1].set_title("(b) raw score distribution"); ax[1].grid(alpha=.25, axis="y")

    xs = np.sort(d["raw"]); sv = 1 - np.arange(1, xs.size + 1) / xs.size
    pos = xs > 0
    ax[2].loglog(xs[pos], sv[pos], ".", ms=4, color="#8e44ad")
    ax[2].set_xlabel("score"); ax[2].set_ylabel("P(S > s)")
    ax[2].set_title("(c) score survival (log-log)"); ax[2].grid(alpha=.25, which="both")
    fig.tight_layout(); fig.savefig("residual_diagnostics.png", dpi=140)
    print(f"\n  figure -> residual_diagnostics.png")

    out = {"n_scenes": int(n), "n_dates": len(dates),
           "alpha_split_fails_below": 1.0 / (n + 1),
           "reduce": args.reduce, "split": args.split, "scores": summaries,
           "raw": d["raw"].tolist(), "normalised": d["normalised"].tolist(),
           "hour": d["hour"].tolist(), "sigma": d["sigma"].tolist(),
           "files": [str(f) for f in d["files"]]}
    json.dump(out, open("residual_scores.json", "w"), indent=2)
    print("  scores -> residual_scores.json  (feed these to ecp.py)")

    print("\n" + "=" * 74)
    print("NEXT")
    print("=" * 74)
    print("  Fit ECP on the score array in residual_scores.json, passing the")
    print("  day-of-year for seasonal reweighting, and report THAT table as")
    print("  Table 1 -- not the synthetic n=800 self-test.")


if __name__ == "__main__":
    main()
