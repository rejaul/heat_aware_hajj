"""
Composite heat-stress risk surface R(s, t | A).

Implements Eq. (9) of the paper:

    R(s,t | A) = sum_g  p_k(s,t) * rho_g(s,t) * v_g(s,t)

where
    p_k   ECP-calibrated probability that the effective heat field exceeds
          danger threshold tau_k,
    rho_g density of cohort g,
    v_g   cumulative incidence for cohort g from a Cox model,
    A     the set of inputs actually available at run time.

Uncertainty from the AMUN residual, the GPD parameters and the conformal
correction is propagated by Monte Carlo, and dispatch acts on the upper credible
bound Rbar, never the point estimate.

IMPORTANT
---------
The cohort hazard ratios below are PRIORS derived from published aggregate
epidemiology, not coefficients fitted to individual records (which are not
public). They are placeholders with the right ordering and rough magnitude.
Refit them before making any empirical claim.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

# ---------------------------------------------------------------------------
# Cohorts
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Cohort:
    name: str
    share: float          # fraction of the pilgrim population
    age_band: str
    registered: bool
    # log-hazard contributions (PRIORS -- refit before publication)
    beta_age: float
    beta_status: float

    @property
    def log_hazard(self) -> float:
        return self.beta_age + self.beta_status


# Priors reflecting published patterns:
#   * the 55-74 band dominated severe cases,
#   * the overwhelming majority of 2024 deaths were unregistered pilgrims,
#     who lack cooled accommodation, official water points and organised care.
COHORTS = [
    Cohort("18-54 registered",   0.34, "18-54", True,  0.00, 0.00),
    Cohort("55-74 registered",   0.38, "55-74", True,  0.85, 0.00),
    Cohort("75+   registered",   0.10, "75+",   True,  1.25, 0.00),
    Cohort("18-54 unregistered", 0.07, "18-54", False, 0.00, 1.55),
    Cohort("55-74 unregistered", 0.09, "55-74", False, 0.85, 1.55),
    Cohort("75+   unregistered", 0.02, "75+",   False, 1.25, 1.55),
]


# ---------------------------------------------------------------------------
# Vulnerability: Cox proportional hazards
# ---------------------------------------------------------------------------


def cox_cumulative_incidence(cohort: Cohort, exposure_hours: float,
                             baseline_rate: float = 0.004,
                             exposure_scale: float = 1.0) -> float:
    """
    Cumulative incidence over an exposure window under a Cox model.

        h_g(t) = h0(t) exp(x^T delta)
        F_g(T) = 1 - exp( -integral_0^T h_g )

    `baseline_rate` is the hourly baseline hazard h0 at reference exposure;
    `exposure_scale` multiplies it to reflect local heat intensity.
    """
    h = baseline_rate * exposure_scale * np.exp(cohort.log_hazard)
    return float(1.0 - np.exp(-h * exposure_hours))


# ---------------------------------------------------------------------------
# Anthropogenic heat island
# ---------------------------------------------------------------------------


def delta_ahi(density, d_ref: float = 7.0, max_delta: float = 2.2):
    """
    Crowd-induced increase in effective wet-bulb temperature (deg C).

    Saturating in density: airflow suppression and trapped metabolic heat
    plateau once the crowd is dense enough to block ventilation entirely.
    Reported magnitudes are of order 2.1-2.3 C at peak density.
    """
    d = np.asarray(density, dtype=float)
    return max_delta * (1.0 - np.exp(-d / d_ref))


# ---------------------------------------------------------------------------
# Availability set
# ---------------------------------------------------------------------------


@dataclass
class Availability:
    """
    Which inputs are present this cycle. Absent inputs fall back to priors with
    inflated uncertainty -- the mechanism behind graceful degradation.
    """
    satellite: bool = True          # always required (Mode A minimum)
    measured_density: bool = False  # operator crowd feed
    ground_sensors: bool = False    # in-situ met stations
    cohort_mix: bool = False        # observed registration mix

    @property
    def mode(self) -> str:
        if self.measured_density and self.cohort_mix:
            return "C. Integrated"
        if self.measured_density or self.ground_sensors:
            return "B. Augmented"
        return "A. Autonomous"

    def as_set(self) -> frozenset:
        return frozenset(k for k, v in self.__dict__.items() if v)


# Extra multiplicative uncertainty when an input is missing.
_PRIOR_INFLATION = {
    "measured_density": 2.4,
    "ground_sensors": 1.6,
    "cohort_mix": 1.5,
}


def uncertainty_inflation(avail: Availability) -> float:
    """Total uncertainty multiplier implied by the missing inputs."""
    infl = 1.0
    for key, factor in _PRIOR_INFLATION.items():
        if not getattr(avail, key):
            infl *= factor
    return infl


# ---------------------------------------------------------------------------
# Risk surface
# ---------------------------------------------------------------------------


@dataclass
class RiskSurface:
    """
    Parameters
    ----------
    heat        effective heat index field (2-D), deg C
    heat_sigma  1-sigma predictive uncertainty on `heat` (from AMUN + ECP)
    density     persons per m^2 (measured, or planned-occupancy prior)
    tau         danger threshold on the heat index
    exposure_h  hours of exposure in the horizon
    """
    heat: np.ndarray
    heat_sigma: np.ndarray
    density: np.ndarray
    tau: float = 32.2
    exposure_h: float = 6.0
    cohorts: list = field(default_factory=lambda: list(COHORTS))

    # -- exceedance ------------------------------------------------------
    def exceedance_prob(self, heat=None, sigma=None) -> np.ndarray:
        """
        P(Z_eff > tau). Gaussian on the calibrated predictive distribution; the
        conformal correction enters through `sigma`, so a wider interval raises
        the exceedance probability toward 0.5 rather than shrinking it.
        """
        from scipy.stats import norm
        heat = self.heat if heat is None else heat
        sigma = self.heat_sigma if sigma is None else sigma
        z = (heat + delta_ahi(self.density) - self.tau) / np.maximum(sigma, 1e-6)
        return norm.cdf(z)

    # -- composite -------------------------------------------------------
    def compute(self, avail: Availability, n_mc: int = 400, q: float = 0.90,
                rng=None):
        """
        Monte Carlo the risk surface under input uncertainty.

        Returns (R_mean, R_upper) where R_upper is the q-quantile credible
        bound used by dispatch.
        """
        rng = rng or np.random.default_rng(0)
        infl = uncertainty_inflation(avail)
        sigma_eff = self.heat_sigma * infl

        # Density uncertainty: small if measured, large if a planned prior.
        dens_cv = 0.10 if avail.measured_density else 0.45
        # Cohort mix uncertainty: the unregistered share is the least known.
        mix_cv = 0.10 if avail.cohort_mix else 0.40

        draws = np.empty((n_mc, *self.heat.shape), dtype="float32")
        for i in range(n_mc):
            heat_i = self.heat + rng.normal(0.0, 1.0, self.heat.shape) * sigma_eff
            dens_i = np.maximum(
                self.density * (1.0 + rng.normal(0.0, dens_cv, self.density.shape)),
                0.0)

            z = (heat_i + delta_ahi(dens_i) - self.tau) / np.maximum(sigma_eff, 1e-6)
            from scipy.stats import norm
            p_k = norm.cdf(z)

            total = np.zeros_like(self.heat, dtype="float32")
            for c in self.cohorts:
                share = max(c.share * (1.0 + rng.normal(0.0, mix_cv)), 0.0)
                # local heat intensity scales the baseline hazard
                scale = np.clip((heat_i - self.tau) / 5.0 + 1.0, 0.2, 4.0)
                v_g = 1.0 - np.exp(
                    -0.004 * scale * np.exp(c.log_hazard) * self.exposure_h)
                total += (p_k * dens_i * share * v_g).astype("float32")
            draws[i] = total

        return draws.mean(0), np.quantile(draws, q, axis=0)


# ---------------------------------------------------------------------------
# Demonstration of the degradation property
# ---------------------------------------------------------------------------


def _synthetic_scene(n: int = 96, seed: int = 3):
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:n, 0:n] / n
    heat = (30.0 + 6.0 * np.exp(-((y - 0.30) ** 2 + (x - 0.72) ** 2) / 0.02)
            + 3.5 * np.exp(-((y - 0.62) ** 2 + (x - 0.38) ** 2) / 0.03)
            + 0.6 * rng.standard_normal((n, n)))
    sigma = 0.7 + 0.4 * np.abs(rng.standard_normal((n, n)))
    dens = np.clip(3.0 + 5.0 * np.exp(-((y - 0.30) ** 2 + (x - 0.72) ** 2) / 0.03)
                   + rng.normal(0, 0.4, (n, n)), 0.2, 9.0)
    return heat, sigma, dens


if __name__ == "__main__":
    heat, sigma, dens = _synthetic_scene()
    rs = RiskSurface(heat=heat, heat_sigma=sigma, density=dens)

    print("=" * 68)
    print("Cohort vulnerability (6 h exposure, reference intensity)")
    print("=" * 68)
    print(f"{'cohort':<22}{'share':>8}{'HR':>8}{'incidence':>12}")
    print("-" * 68)
    for c in COHORTS:
        hr = np.exp(c.log_hazard)
        inc = cox_cumulative_incidence(c, 6.0)
        print(f"{c.name:<22}{c.share:>8.2f}{hr:>8.2f}{inc:>11.3%}")

    print("\n" + "=" * 68)
    print("Graceful degradation:  A' subset of A  =>  Rbar(A') >= Rbar(A)")
    print("=" * 68)

    modes = [
        ("C. Integrated", Availability(True, True, True, True)),
        ("B. Augmented",  Availability(True, True, False, False)),
        ("A. Autonomous", Availability(True, False, False, False)),
    ]

    results = []
    for label, av in modes:
        mean, upper = rs.compute(av, n_mc=250, rng=np.random.default_rng(11))
        results.append((label, av, mean, upper))
        print(f"{label:<16} inflation x{uncertainty_inflation(av):<5.2f} "
              f"mean {mean.mean():.5f}   Rbar {upper.mean():.5f}   "
              f"max Rbar {upper.max():.5f}")

    print("\nMonotonicity check (pairwise, cell-wise fraction satisfying):")
    ok_all = True
    for i in range(len(results) - 1):
        richer, poorer = results[i], results[i + 1]
        frac = float((poorer[3] >= richer[3]).mean())
        mean_ok = poorer[3].mean() >= richer[3].mean()
        ok_all &= mean_ok
        print(f"  Rbar[{poorer[0]}] >= Rbar[{richer[0]}] : "
              f"{frac:.1%} of cells, mean holds = {mean_ok}")

    print(f"\nProperty holds on the mean bound for all pairs: {ok_all}")
    print("Losing a feed cannot silently reduce protection -- only make the")
    print("system more conservative, and less efficient.")
