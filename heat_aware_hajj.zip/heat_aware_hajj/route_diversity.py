"""
Does any ritual leg offer an exploitable heat-distance trade-off?

BACKGROUND. On Mina->Arafat the 20 shortest paths differ by 30 m in length
(12.58-12.61 km) and by 0.0007 in mean exceedance (0.6092-0.6099), against a
field spanning 0.445-0.788. With no spread across alternatives there is nothing
for heat-aware routing to choose between, which is why cohort doses under
lexicographic assignment differed by 0.19% and the dispatch window had no effect
on dose. Those were not bugs; the problem simply had no degrees of freedom.

Before reporting that as a general negative result, two things must be checked:

  1. OTHER LEGS. Mina->Arafat crosses open terrain between two fixed points, so
     candidate paths run in a narrow parallel band and sample the same surface.
     Mina->Jamarat is shorter and passes through built-up ground where genuinely
     distinct alternatives may exist.

  2. OTHER SCENES. The field is a single acquisition. Shading patterns differ
     through the day, so a midday scene may show contrast that this one lacks.

This script measures route diversity per leg, and optionally across several
exported fields, and reports whether any combination is worth routing on.

Metrics per leg
---------------
  length spread      max-min over the k shortest paths, km and %
  exposure spread    max-min of the length-weighted mean exceedance
  best trade-off     the largest exposure reduction available, and its detour
  usable             exposure spread > --min-spread (default 0.02)

Run
---
    python route_diversity.py --risk field_prob.npy
    python route_diversity.py --risk field_prob.npy --k 40
    python route_diversity.py --risk f1.npy f2.npy f3.npy      # several scenes
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import networkx as nx

LEGS = [("Haram", "Mina"), ("Mina", "Arafat"), ("Arafat", "Muzdalifah"),
        ("Muzdalifah", "Mina"), ("Mina", "Jamarat"), ("Jamarat", "Haram")]


def simple_graph(rg):
    S = nx.DiGraph()
    for u, v, d in rg.S.edges(data=True):
        if not S.has_edge(u, v) or d["length"] < S[u][v]["w"]:
            S.add_edge(u, v, w=float(d["length"]), E=float(d["E"]))
    return S


def path_stats(S, p):
    L = sum(S[a][b]["w"] for a, b in zip(p[:-1], p[1:]))
    if L <= 0:
        return 0.0, 0.0
    E = sum(S[a][b]["E"] * S[a][b]["w"] for a, b in zip(p[:-1], p[1:])) / L
    return L, E


def leg_diversity(S, src, dst, k=20):
    """k shortest paths by distance; report length and exposure spread."""
    try:
        gen = nx.shortest_simple_paths(S, src, dst, weight="w")
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return None
    rows = []
    for i, p in enumerate(gen):
        L, E = path_stats(S, p)
        rows.append((L / 1000.0, E))
        if i + 1 >= k:
            break
    if len(rows) < 2:
        return None
    L = np.array([r[0] for r in rows]); E = np.array([r[1] for r in rows])

    # best available trade: lowest-exposure path, and what it costs in distance
    j = int(np.argmin(E))
    detour = 100.0 * (L[j] - L[0]) / max(L[0], 1e-9)
    reduction = 100.0 * (E[0] - E[j]) / max(E[0], 1e-9)

    return {"n_paths": len(rows),
            "len_km_min": float(L.min()), "len_km_max": float(L.max()),
            "len_spread_km": float(L.max() - L.min()),
            "len_spread_pct": float(100 * (L.max() - L.min()) / max(L.min(), 1e-9)),
            "exp_min": float(E.min()), "exp_max": float(E.max()),
            "exp_spread": float(E.max() - E.min()),
            "best_exp_reduction_pct": float(reduction),
            "best_detour_pct": float(detour)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", nargs="+", required=True,
                    help="one or more exported .npy exceedance grids")
    ap.add_argument("--bbox")
    ap.add_argument("--k", type=int, default=20, help="paths per leg")
    ap.add_argument("--min-spread", type=float, default=0.02,
                    help="exposure spread below which a leg offers no trade-off")
    args = ap.parse_args()

    from corridor_network import fetch, snap_sites
    from routing_equilibrium import prepare_edges
    from routing_scalarized import RoutingGraph
    import config

    bbox = (tuple(float(x) for x in args.bbox.split(",")) if args.bbox
            else config.BBOX)

    G0 = fetch()
    snapped = snap_sites(G0)
    node = {k: v["node"] for k, v in snapped.items()}

    print("=" * 92)
    print("ROUTE DIVERSITY: is there a heat-distance trade-off to exploit?")
    print("=" * 92)
    print(f"  {args.k} shortest paths per leg; a leg is 'usable' if the exposure")
    print(f"  spread across alternatives exceeds {args.min_spread}")

    all_rows = []
    for risk_path in args.risk:
        field = np.load(risk_path)
        G = fetch()
        prepare_edges(G, field, bbox)
        rg = RoutingGraph(G)
        S = simple_graph(rg)

        print(f"\n  field {risk_path}: range "
              f"[{np.nanmin(field):.3f}, {np.nanmax(field):.3f}]  "
              f"sd {np.nanstd(field):.3f}")
        print(f"  {'leg':<24}{'km':>14}{'len spr':>9}"
              f"{'exposure':>18}{'exp spr':>10}{'best cut':>10}"
              f"{'detour':>9}  usable")
        print("  " + "-" * 88)

        for a, b in LEGS:
            if a not in node or b not in node:
                continue
            r = leg_diversity(S, node[a], node[b], args.k)
            if r is None:
                print(f"  {a+' -> '+b:<24}{'no path':>14}")
                continue
            usable = r["exp_spread"] > args.min_spread
            r.update({"leg": f"{a}->{b}", "field": risk_path,
                      "usable": bool(usable)})
            all_rows.append(r)
            print(f"  {a+' -> '+b:<24}"
                  f"{r['len_km_min']:6.2f}-{r['len_km_max']:<7.2f}"
                  f"{r['len_spread_pct']:>8.2f}%"
                  f"{r['exp_min']:9.4f}-{r['exp_max']:<8.4f}"
                  f"{r['exp_spread']:>10.4f}"
                  f"{r['best_exp_reduction_pct']:>9.2f}%"
                  f"{r['best_detour_pct']:>8.2f}%"
                  f"  {'YES' if usable else 'no'}")

    print("\n" + "=" * 92)
    print("READING THIS")
    print("=" * 92)
    usable = [r for r in all_rows if r["usable"]]
    if usable:
        print(f"  {len(usable)} of {len(all_rows)} leg/field combinations offer an")
        print("  exploitable trade-off. Route the framework on those, and report")
        print("  the others as legs where alternatives are thermally equivalent.")
        for r in sorted(usable, key=lambda x: -x["exp_spread"])[:5]:
            print(f"    {r['leg']:<22} spread {r['exp_spread']:.4f}  "
                  f"best cut {r['best_exp_reduction_pct']:.1f}% for "
                  f"{r['best_detour_pct']:.1f}% detour  [{r['field']}]")
    else:
        print("  NO leg offers an exploitable heat-distance trade-off.")
        print("  This is a negative result, not a bug: candidate paths between")
        print("  fixed ritual sites run in a narrow parallel band and sample")
        print("  equivalent surface conditions, so heat-aware routing, cohort")
        print("  prioritisation and dispatch-window choice all have nothing to")
        print("  act on. Report it as a scope condition -- the framework needs")
        print("  route diversity that this corridor does not provide -- and")
        print("  note that the calibration and capacity layers still apply.")

    if all_rows:
        worst = min(all_rows, key=lambda r: r["exp_spread"])
        best = max(all_rows, key=lambda r: r["exp_spread"])
        print(f"\n  exposure spread ranges {worst['exp_spread']:.4f} "
              f"({worst['leg']}) to {best['exp_spread']:.4f} ({best['leg']})")

    json.dump(all_rows, open("route_diversity.json", "w"), indent=2)
    print("\n  results -> route_diversity.json")


if __name__ == "__main__":
    main()
