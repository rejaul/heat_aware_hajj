"""
Heat-aware routing over the REAL Hajj pedestrian network.

Attaches your predicted/calibrated heat-risk field to the OSM edges from
corridor_network.py and compares five routing policies:

  1. shortest        -- minimise distance (the pilgrim default baseline)
  2. coolest-mean    -- minimise exposure dose using the median field
  3. risk-averse     -- minimise dose using a HIGH QUANTILE (tau=0.95) field
  4. cohort-specific -- dose weighted by cohort vulnerability v_g
  5. congestion-coupled -- flow split over k-best paths with the crowd
                           heat-island feedback (density raises effective heat)

Cost model
----------
The physiologically relevant quantity is cumulative thermal DOSE: heat stress
integrated over time exposed. With walking speed v, time on an edge is l/v, so

    dose_ij = E_ij * l_ij / v

Following the threshold-exceedance formulation used in the thermal-routing
literature (integrating index EXCEEDANCE above a danger threshold along segment
length, rather than the raw index), we take

    E_ij = P(WBGT_ij > k)          # calibrated exceedance probability

which is what the ECP layer produces. Routing on a CALIBRATED PROBABILITY
(and on a high quantile, for the risk-averse policy) is the novel part: the
existing literature routes on deterministic index values.

A blended objective exposes the risk-aversion dial:

    c_ij = [ lambda * E_ij + (1 - lambda) ] * l_ij

lambda=0 recovers the shortest path; lambda=1 is pure exposure minimisation.

Usage
-----
    python routing.py --risk field.npy                 # your predicted field
    python routing.py --risk field.npy --tau-risk q95.npy   # risk-averse too
    python routing.py --demo                           # runs on a stub graph
"""
from __future__ import annotations

import argparse
import json
import os
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import networkx as nx

WALK_SPEED = 1.1          # m/s, typical dense-crowd pilgrim walking speed
DANGER_WBGT = 32.2        # Tier-3 threshold used elsewhere in the pipeline

# cohort vulnerability weights (same convention as risk.py)
COHORTS = {
    "reg_18_54":    0.4,
    "reg_55_74":    1.0,
    "unreg_55_74":  2.2,
    "unreg_75plus": 3.1,
}


# ---------------------------------------------------------------------------
# 1. attach a raster field to graph edges
# ---------------------------------------------------------------------------

def sample_raster(field, bbox, lat, lon):
    """
    Sample a raster `field` (2-D, north-up) at (lat, lon).
    bbox = (west, south, east, north) in degrees, matching the raster extent.
    """
    west, south, east, north = bbox
    H, W = field.shape
    fx = (lon - west) / (east - west)
    fy = (north - lat) / (north - south)          # row 0 = north
    if not (0 <= fx <= 1 and 0 <= fy <= 1):
        return np.nan
    r = min(H - 1, max(0, int(fy * (H - 1))))
    c = min(W - 1, max(0, int(fx * (W - 1))))
    return float(field[r, c])


def attach_field(G, field, bbox, attr="E", samples=3):
    """
    Attach a field value to every edge, sampled at `samples` points along the
    edge (endpoints + midpoint) and averaged. Edges outside the raster get NaN,
    which is then filled with the graph-wide median so routing stays connected.
    """
    vals = []
    for u, v, k, d in G.edges(keys=True, data=True):
        y1, x1 = G.nodes[u]["y"], G.nodes[u]["x"]
        y2, x2 = G.nodes[v]["y"], G.nodes[v]["x"]
        pts = [(y1 + (y2 - y1) * t, x1 + (x2 - x1) * t)
               for t in np.linspace(0, 1, samples)]
        s = [sample_raster(field, bbox, la, lo) for la, lo in pts]
        s = [x for x in s if np.isfinite(x)]
        e = float(np.mean(s)) if s else np.nan
        d[attr] = e
        vals.append(e)

    finite = [x for x in vals if np.isfinite(x)]
    if not finite:
        raise ValueError("No edge fell inside the raster: check bbox alignment.")
    med = float(np.median(finite))
    n_fill = 0
    for _, _, _, d in G.edges(keys=True, data=True):
        if not np.isfinite(d.get(attr, np.nan)):
            d[attr] = med
            n_fill += 1
    print(f"  attached '{attr}': {len(finite)} edges sampled, "
          f"{n_fill} filled with median {med:.3f}")
    return G


# ---------------------------------------------------------------------------
# 2. edge costs and routing
# ---------------------------------------------------------------------------

def set_cost(G, lam=1.0, attr="E", weight_scale=1.0, cost_attr="cost"):
    """c_ij = [lam*E + (1-lam)] * length ; weight_scale multiplies E (cohort)."""
    for _, _, _, d in G.edges(keys=True, data=True):
        L = float(d.get("length", 1.0))
        E = float(d.get(attr, 0.0)) * weight_scale
        d[cost_attr] = max(1e-9, (lam * E + (1.0 - lam)) * L)
    return G


def cohort_lambda(cohort, lo=0.25, hi=1.0):
    """
    Map cohort vulnerability to a risk-aversion weight lambda in [lo, hi].

    A uniform multiplicative weight on the field cannot change the optimal path
    (argmin is scale-invariant), so cohort vulnerability must enter through the
    distance/exposure TRADE-OFF instead: the more vulnerable the cohort, the
    more detour it is worth accepting to reduce exposure.
    """
    v = COHORTS[cohort]
    vmin, vmax = min(COHORTS.values()), max(COHORTS.values())
    frac = (v - vmin) / max(vmax - vmin, 1e-9)
    return float(lo + frac * (hi - lo))


def route(G, src, dst, cost_attr="cost"):
    return nx.shortest_path(G, src, dst, weight=cost_attr)


def path_metrics(G, path, attr="E", danger_attr=None):
    """Distance, exposure dose, peak exposure, time in danger."""
    dist = 0.0; dose = 0.0; peak = 0.0; t_danger = 0.0
    for u, v in zip(path[:-1], path[1:]):
        d = min(G[u][v].values(), key=lambda x: x.get("cost", x.get("length", 1)))
        L = float(d.get("length", 0.0))
        E = float(d.get(attr, 0.0))
        dist += L
        dose += E * L / WALK_SPEED
        peak = max(peak, E)
        if danger_attr is not None and float(d.get(danger_attr, 0.0)) > 0.5:
            t_danger += L / WALK_SPEED
    return {"distance_m": dist, "dose": dose, "peak_E": peak,
            "minutes": dist / WALK_SPEED / 60.0,
            "danger_minutes": t_danger / 60.0}


# ---------------------------------------------------------------------------
# 3. congestion-coupled routing (the novel part)
# ---------------------------------------------------------------------------

def congestion_coupled(G, src, dst, n_flow=1.0, k=4, iters=6,
                       heat_per_density=2.1, capacity_attr="capacity",
                       attr="E", verbose=True):
    """
    Split flow over k shortest paths, then let density RAISE the effective heat
    on loaded edges (crowd heat-island), and re-solve. Existing thermal-routing
    work treats the field as exogenous; at a mass gathering it is not.

    heat_per_density: effective-temperature offset per unit normalised density
                      (the crowd heat-island term, ~2.1 C in the literature).
    Returns (paths, flows, history).
    """
    for _, _, _, d in G.edges(keys=True, data=True):
        d["E_eff"] = float(d.get(attr, 0.0))
        d.setdefault(capacity_attr, 1.0)

    hist = []
    paths, flows = [], []
    for it in range(iters):
        set_cost(G, lam=1.0, attr="E_eff")
        # nx.shortest_simple_paths does not support MultiDiGraph (what osmnx
        # returns), so project to a simple DiGraph keeping the cheapest parallel
        # edge between each node pair.
        S = nx.DiGraph()
        S.add_nodes_from(G.nodes(data=True))
        for u, v, d in G.edges(data=True):
            c = float(d["cost"])
            if not S.has_edge(u, v) or c < S[u][v]["cost"]:
                S.add_edge(u, v, cost=c)
        try:
            gen = nx.shortest_simple_paths(S, src, dst, weight="cost")
            cand = []
            for i, p in enumerate(gen):
                cand.append(p)
                if i + 1 >= k:
                    break
        except nx.NetworkXNoPath:
            return [], [], hist
        if not cand:
            return [], [], hist
        # inverse-cost flow split (more flow on cheaper paths)
        costs = []
        for p in cand:
            c = sum(min(G[u][v].values(), key=lambda x: x["cost"])["cost"]
                    for u, v in zip(p[:-1], p[1:]))
            costs.append(c)
        costs = np.array(costs, float)
        w = 1.0 / np.maximum(costs, 1e-9)
        flows = (w / w.sum()) * n_flow
        paths = cand

        # reset then load densities
        load = {}
        for p, f in zip(paths, flows):
            for u, v in zip(p[:-1], p[1:]):
                load[(u, v)] = load.get((u, v), 0.0) + f

        maxload = max(load.values()) if load else 0.0
        for (u, v), f in load.items():
            for kk, d in G[u][v].items():
                cap = float(d.get(capacity_attr, 1.0))
                dens = f / max(cap, 1e-9)
                d["E_eff"] = float(d.get(attr, 0.0)) + heat_per_density * dens * 0.01
        hist.append({"iter": it, "n_paths": len(paths),
                     "max_edge_load": float(maxload),
                     "spread": float(np.max(flows) - np.min(flows))})
        if verbose:
            print(f"    iter {it}: {len(paths)} paths, max edge load "
                  f"{maxload:.3f}, flow spread {hist[-1]['spread']:.3f}")
    return paths, flows, hist


# ---------------------------------------------------------------------------
# 4. policy comparison
# ---------------------------------------------------------------------------

def compare_policies(G, src, dst, field_attr="E", tau_attr=None,
                     cohort="unreg_75plus", lam=1.0):
    res = {}

    set_cost(G, lam=0.0, attr=field_attr)                     # pure distance
    p = route(G, src, dst); res["shortest"] = path_metrics(G, p, field_attr); res["shortest"]["path"] = p

    set_cost(G, lam=lam, attr=field_attr)                     # dose, median field
    p = route(G, src, dst); res["coolest_mean"] = path_metrics(G, p, field_attr); res["coolest_mean"]["path"] = p

    if tau_attr:                                              # dose, high quantile
        set_cost(G, lam=lam, attr=tau_attr)
        p = route(G, src, dst)
        m = path_metrics(G, p, field_attr); m["path"] = p
        res["risk_averse"] = m

    # Cohort-specific routing.
    # NOTE: multiplying the field by a CONSTANT cohort weight does not change
    # which path is cheapest (argmin is scale-invariant), so vulnerability must
    # enter as RISK AVERSION, not as a uniform gain. We map the cohort weight to
    # lambda: a more vulnerable pilgrim is routed more conservatively, accepting
    # a longer detour to cut exposure. (A fully physiological alternative is a
    # cohort-specific danger threshold k_g, which changes the field itself.)
    lam_g = cohort_lambda(cohort)
    set_cost(G, lam=lam_g, attr=field_attr)
    p = route(G, src, dst)
    m = path_metrics(G, p, field_attr)
    m["path"] = p; m["cohort"] = cohort; m["lambda"] = lam_g
    res["cohort"] = m

    paths, flows, hist = congestion_coupled(G, src, dst, attr=field_attr, verbose=False)
    if paths:
        agg = {"distance_m": 0.0, "dose": 0.0, "peak_E": 0.0, "minutes": 0.0}
        for p_, f in zip(paths, flows):
            m = path_metrics(G, p_, field_attr)
            for kk in agg:
                agg[kk] += m[kk] * f if kk != "peak_E" else 0
            agg["peak_E"] = max(agg["peak_E"], m["peak_E"])
        agg["path"] = paths[0]; agg["n_paths"] = len(paths)
        agg["flows"] = [float(x) for x in flows]
        res["congestion_coupled"] = agg

    # relative to shortest
    base = res["shortest"]
    for k_, v in res.items():
        if k_ == "shortest":
            v["dose_reduction_pct"] = 0.0; v["detour_pct"] = 0.0; continue
        v["dose_reduction_pct"] = 100.0 * (base["dose"] - v["dose"]) / max(base["dose"], 1e-9)
        v["detour_pct"] = 100.0 * (v["distance_m"] - base["distance_m"]) / max(base["distance_m"], 1e-9)
    return res


def pareto(G, src, dst, field_attr="E", lams=(0, .1, .25, .5, .75, .9, 1.0)):
    out = []
    for lam in lams:
        set_cost(G, lam=lam, attr=field_attr)
        p = route(G, src, dst)
        m = path_metrics(G, p, field_attr)
        m["lambda"] = lam
        out.append(m)
    return out


def print_table(res):
    print("\n" + "=" * 88)
    print("ROUTING POLICY COMPARISON (real OSM corridor)")
    print("=" * 88)
    print(f"{'Policy':<22}{'dist (m)':>10}{'minutes':>9}{'dose':>10}"
          f"{'peak E':>9}{'dose red.%':>12}{'detour %':>10}")
    print("-" * 88)
    for k, v in res.items():
        print(f"{k:<22}{v['distance_m']:>10.0f}{v['minutes']:>9.1f}{v['dose']:>10.1f}"
              f"{v['peak_E']:>9.3f}{v['dose_reduction_pct']:>12.1f}{v['detour_pct']:>10.2f}")
    print("-" * 88)
    print("dose = exceedance-probability integrated over exposure time (lower better)")
    print("Literature benchmark: thermal routing typically buys large exposure")
    print("reductions for detours of only ~1-3% in length.")


# ---------------------------------------------------------------------------
# demo graph (structure mimics osmnx: nodes have x/y, edges have length)
# ---------------------------------------------------------------------------

def stub_graph(n=26, seed=0, jitter=0.35, drop=0.12):
    """
    IRREGULAR graph in lat/lon over the corridor bbox, for logic testing only.

    A regular grid is a poor test: all monotone staircase paths have identical
    length, so heat can be dodged at zero detour cost and the Pareto frontier
    collapses. We therefore jitter node positions and randomly drop edges, which
    reproduces the irregular geometry of a real OSM network and makes the
    distance/exposure trade-off non-degenerate.
    """
    rng = np.random.default_rng(seed)
    G = nx.MultiDiGraph(crs="epsg:4326")
    west, south, east, north = 39.81, 21.34, 39.99, 21.43
    lats = np.linspace(south, north, n); lons = np.linspace(west, east, n)
    dlat = (north - south) / (n - 1); dlon = (east - west) / (n - 1)
    idx = lambda i, j: i * n + j
    pos = {}
    for i, la in enumerate(lats):
        for j, lo in enumerate(lons):
            jy = float(la + rng.normal(0, jitter * dlat))
            jx = float(lo + rng.normal(0, jitter * dlon))
            pos[idx(i, j)] = (jy, jx)
            G.add_node(idx(i, j), y=jy, x=jx)
    for i in range(n):
        for j in range(n):
            for di, dj in ((0, 1), (1, 0), (1, 1)):     # add diagonals too
                a, b = i + di, j + dj
                if a < n and b < n:
                    if rng.random() < drop:              # missing links
                        continue
                    (y1, x1), (y2, x2) = pos[idx(i, j)], pos[idx(a, b)]
                    dy = (y2 - y1) * 111320.0
                    dx = (x2 - x1) * 111320.0 * 0.93
                    L = float(np.hypot(dx, dy)) or 30.0
                    G.add_edge(idx(i, j), idx(a, b), length=L)
                    G.add_edge(idx(a, b), idx(i, j), length=L)
    # keep only the largest connected component (as osmnx does)
    und = G.to_undirected()
    comp = max(nx.connected_components(und), key=len)
    G = G.subgraph(comp).copy()
    nodes = sorted(G.nodes())
    return G, (west, south, east, north), nodes[0], nodes[-1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", help=".npy of the predicted median/exceedance field")
    ap.add_argument("--tau-risk", help=".npy of the tau=0.95 field (risk-averse)")
    ap.add_argument("--bbox", help="west,south,east,north of the raster")
    ap.add_argument("--from", dest="src", default="Mina")
    ap.add_argument("--to", dest="dst", default="Arafat")
    ap.add_argument("--cohort", default="unreg_75plus", choices=list(COHORTS))
    ap.add_argument("--demo", action="store_true", help="run on a stub grid graph")
    args = ap.parse_args()

    if args.demo or not args.risk:
        print("DEMO MODE: stub grid graph (logic check only, not real geography)\n")
        G, bbox, src, dst = stub_graph()
        H, W = 96, 96
        yy, xx = np.mgrid[0:H, 0:W] / H
        field = (0.15 + 0.8 * np.exp(-((yy - .45) ** 2 + (xx - .55) ** 2) / .02)
                 + 0.5 * np.exp(-((yy - .7) ** 2 + (xx - .3) ** 2) / .01))
        field = np.clip(field, 0, 1)
        tau = np.clip(field * 1.25, 0, 1)
    else:
        import osmnx as ox
        from corridor_network import fetch, snap_sites
        G = fetch()
        snapped = snap_sites(G)
        src, dst = snapped[args.src]["node"], snapped[args.dst]["node"]
        field = np.load(args.risk)
        tau = np.load(args.tau_risk) if args.tau_risk else None
        if args.bbox:
            bbox = tuple(float(x) for x in args.bbox.split(","))
        else:
            import config
            bbox = config.BBOX
        print(f"routing {args.from_ if hasattr(args,'from_') else args.src} -> {args.dst}")

    print("attaching field to edges ...")
    attach_field(G, field, bbox, attr="E")
    tau_attr = None
    if tau is not None:
        attach_field(G, tau, bbox, attr="E95"); tau_attr = "E95"

    res = compare_policies(G, src, dst, field_attr="E", tau_attr=tau_attr,
                           cohort=args.cohort)
    print_table(res)

    print("\nPareto frontier (risk-aversion sweep):")
    for m in pareto(G, src, dst):
        print(f"  lambda={m['lambda']:.2f}  dist {m['distance_m']:8.0f} m  "
              f"dose {m['dose']:8.1f}  peak {m['peak_E']:.3f}")

    out = {k: {kk: vv for kk, vv in v.items() if kk != "path"}
           for k, v in res.items()}
    with open("routing_results.json", "w") as f:
        json.dump(out, f, indent=2)
    print("\nsaved -> routing_results.json")


if __name__ == "__main__":
    main()
