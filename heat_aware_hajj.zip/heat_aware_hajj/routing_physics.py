"""
Physics core for heat- and congestion-aware pilgrim routing.

Three pieces that the simpler routing.py got wrong or omitted:

1. LINE-INTEGRAL exposure sampling (not 3-point). An edge is rasterised across
   the risk grid and exposure is integrated over the length spent in each cell:

       dose_ij = (1/v) * sum_c  E_c * l_ij^(c),     sum_c l^(c) = l_ij

   This matters most for long edges crossing a sharp thermal gradient --
   exactly the hotspot boundaries the router must detect.

2. SPEED-DENSITY coupling (Weidmann fundamental diagram). Pedestrian speed
   collapses as density rises:

       v(rho) = v_free * [1 - exp(-gamma (1/rho - 1/rho_jam))]

   Because dose = E * l / v, crowding LENGTHENS exposure. Congestion and heat
   casualty are therefore the same failure mode -- a coupling absent from the
   thermal-routing literature, which treats the field as exogenous.

3. GENERALIZED COST with an explicit heat toll (the "toll road" formulation):

       c_ij = t_ij + theta_g * E_ij * t_ij + phi * Psi(rho_ij)
              travel time   heat toll        crush penalty

   theta_g is the value of avoiding heat, in minutes of extra walking accepted
   per unit dose. It is cohort-specific and is the parameter we sweep, because
   no literature value exists for it.

Parameter provenance is documented in PARAMS below. Values with a literature
basis are marked [lit]; values we assume are marked [assumed] and must be
reported as such.
"""
from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------

PARAMS = {
    # --- pedestrian fundamental diagram (Weidmann 1993) ---
    "v_free":      1.34,   # [lit] free-flow walking speed, m/s
    "rho_jam":     5.40,   # [lit] jam density, ped/m^2
    "gamma_fd":    1.913,  # [lit] Weidmann shape parameter, ped/m^2
    "v_min":       0.05,   # [assumed] numerical floor, m/s (avoid div by zero)

    # --- crowd heat island ---
    "beta_heat":   2.1,    # [lit] effective-temperature offset at high density, C
    "rho_ref":     4.0,    # [assumed] density at which beta_heat is realised

    # --- crush risk ---
    "rho_crit":    4.0,    # [lit-ish] density above which crush risk rises sharply
    "phi_crush":   60.0,   # [assumed] penalty weight, seconds per (ped/m^2)^2

    # --- corridor geometry (effective walkable widths, metres) ---
    # [assumed] keyed by OSM highway tag; the Mashaer walkways are wide, but OSM
    # rarely records width, so these are engineering estimates. REPORT AS ASSUMED.
    "width_default": 8.0,
    "width_by_tag": {
        "pedestrian": 20.0, "footway": 6.0, "path": 4.0, "steps": 3.0,
        "primary": 20.0, "secondary": 15.0, "tertiary": 12.0,
        "residential": 8.0, "service": 6.0, "track": 5.0, "unclassified": 8.0,
    },

    # --- demand (historic scale) ---
    # [lit] ~1.8-2.0 million pilgrims perform the Hajj; the Mina->Arafat and
    # Muzdalifah->Mina movements are near-simultaneous mass transfers.
    "n_pilgrims":  1_800_000,
    # [assumed] fraction walking (rest use buses/train/Mashaer metro)
    "walk_fraction": 0.45,
    # [assumed] hours over which a leg's demand is spread
    "leg_window_h": 6.0,
}


# ---------------------------------------------------------------------------
# 1. Line-integral exposure sampling
# ---------------------------------------------------------------------------

def cells_along_segment(lat1, lon1, lat2, lon2, bbox, shape, max_steps=4096):
    """
    Rasterise a geodesic-ish segment onto the risk grid and return
    [(row, col, fraction_of_edge_length), ...].

    Uses uniform arc-length stepping at ~half-cell resolution, which is exact in
    the limit and far more accurate than endpoint/midpoint sampling. Returns
    fractions that sum to 1 over the in-grid portion.
    """
    west, south, east, north = bbox
    H, W = shape
    dlat = (north - south) / max(H - 1, 1)
    dlon = (east - west) / max(W - 1, 1)

    # number of steps ~ 2x the number of cells the segment spans
    nlat = abs(lat2 - lat1) / max(dlat, 1e-12)
    nlon = abs(lon2 - lon1) / max(dlon, 1e-12)
    n = int(min(max_steps, max(2, 2 * np.ceil(max(nlat, nlon)) + 2)))

    ts = (np.arange(n) + 0.5) / n          # midpoints of n equal sub-segments
    lats = lat1 + (lat2 - lat1) * ts
    lons = lon1 + (lon2 - lon1) * ts

    fx = (lons - west) / max(east - west, 1e-12)
    fy = (north - lats) / max(north - south, 1e-12)
    inside = (fx >= 0) & (fx <= 1) & (fy >= 0) & (fy <= 1)
    if not inside.any():
        return []

    rows = np.clip((fy * (H - 1)).astype(int), 0, H - 1)
    cols = np.clip((fx * (W - 1)).astype(int), 0, W - 1)
    frac = 1.0 / n

    acc = {}
    for r, c, ok in zip(rows, cols, inside):
        if ok:
            acc[(int(r), int(c))] = acc.get((int(r), int(c)), 0.0) + frac
    return [(r, c, f) for (r, c), f in acc.items()]


def edge_exposure(field, bbox, lat1, lon1, lat2, lon2):
    """
    Length-weighted mean exposure along an edge (the line integral divided by
    edge length). Returns (E_bar, covered_fraction).
    """
    cells = cells_along_segment(lat1, lon1, lat2, lon2, bbox, field.shape)
    if not cells:
        return np.nan, 0.0
    tot_f = sum(f for _, _, f in cells)
    E = sum(field[r, c] * f for r, c, f in cells) / max(tot_f, 1e-12)
    return float(E), float(tot_f)


# ---------------------------------------------------------------------------
# 2. Fundamental diagram: speed from density
# ---------------------------------------------------------------------------

def speed_from_density(rho, p=PARAMS):
    """
    Weidmann pedestrian fundamental diagram.
        v(rho) = v_free * [1 - exp(-gamma (1/rho - 1/rho_jam))]
    At rho >= rho_jam the exponent is <= 0 and speed collapses to the floor.
    """
    rho = np.maximum(np.asarray(rho, float), 1e-6)
    with np.errstate(over="ignore", invalid="ignore"):
        v = p["v_free"] * (1.0 - np.exp(-p["gamma_fd"] * (1.0 / rho - 1.0 / p["rho_jam"])))
    return np.maximum(np.nan_to_num(v, nan=p["v_min"]), p["v_min"])


def density_from_flow(q, width, p=PARAMS, iters=25):
    """
    Solve rho from the flow relation  q = rho * v(rho) * width  by fixed point.
    q in ped/s, width in m. Returns (rho, v).

    If demand exceeds the edge's maximum flow the fixed point saturates at
    jam density -- which is the correct qualitative behaviour (queueing).
    """
    q = np.asarray(q, float); width = np.asarray(width, float)
    rho = np.full_like(q, 0.5)
    for _ in range(iters):
        v = speed_from_density(rho, p)
        rho_new = q / np.maximum(width * v, 1e-9)
        rho_new = np.clip(rho_new, 1e-6, p["rho_jam"] * 1.5)
        if np.max(np.abs(rho_new - rho)) < 1e-9:
            rho = rho_new
            break
        rho = 0.5 * rho + 0.5 * rho_new          # damped for stability
    return rho, speed_from_density(rho, p)


# ---------------------------------------------------------------------------
# 3. Generalized cost
# ---------------------------------------------------------------------------

def crush_penalty(rho, p=PARAMS):
    """Psi(rho): zero below rho_crit, quadratic above. Separate from heat."""
    excess = np.maximum(np.asarray(rho, float) - p["rho_crit"], 0.0)
    return excess ** 2


def crowd_heat_offset(rho, p=PARAMS):
    """Additive effective-heat offset from crowd-generated heat (normalised)."""
    return p["beta_heat"] * np.minimum(np.asarray(rho, float) / p["rho_ref"], 1.5)


def generalized_cost(length, E, rho, theta_g, p=PARAMS, heat_to_prob=0.05):
    """
    c_ij = t_ij + theta_g * E_eff * t_ij + phi * Psi(rho)      [seconds]

    length : m
    E      : exceedance probability P(WBGT > k) in [0,1]
    rho    : ped/m^2
    theta_g: value of avoiding heat -- extra SECONDS of walking accepted per
             unit dose (dimensionless dose = probability x seconds)

    heat_to_prob converts the crowd heat offset (deg C) into an equivalent
    increase in exceedance probability. [assumed] -- report and sweep it.
    """
    v = speed_from_density(rho, p)
    t = np.asarray(length, float) / np.maximum(v, p["v_min"])
    E_eff = np.clip(np.asarray(E, float) + heat_to_prob * crowd_heat_offset(rho, p), 0.0, 1.0)
    return t + theta_g * E_eff * t + p["phi_crush"] * crush_penalty(rho, p), t, E_eff, v


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 66)
    print("PHYSICS CORE SELF-TEST")
    print("=" * 66)

    print("\n1. Fundamental diagram v(rho):")
    for r in [0.1, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 5.4, 8.0, 9.0]:
        v = float(speed_from_density(r))
        note = ""
        if r >= PARAMS["rho_jam"]:
            note = "  <- at/above jam density: near standstill"
        print(f"   rho={r:4.1f} ped/m^2 -> v={v:5.3f} m/s{note}")
    print("   NOTE: Hajj corridor densities of 8-9 ped/m^2 are ABOVE jam density,")
    print("   so exposure time diverges -- congestion IS a heat-casualty mechanism.")

    print("\n2. Dose amplification by crowding (same 1 km, same E=0.3):")
    L, E = 1000.0, 0.3
    for r in [0.5, 2.0, 4.0, 5.4]:
        v = float(speed_from_density(r))
        dose = E * L / v
        print(f"   rho={r:4.1f} -> v={v:5.3f} m/s, time={L/v/60:6.1f} min, dose={dose:8.1f}")

    print("\n3. Line-integral vs 3-point sampling (sharp gradient):")
    H = W = 64
    field = np.zeros((H, W)); field[:, W // 2:] = 1.0     # step function
    bbox = (0.0, 0.0, 1.0, 1.0)
    E_line, cov = edge_exposure(field, bbox, 0.5, 0.1, 0.5, 0.9)
    mid3 = np.mean([field[32, int(0.1 * (W - 1))], field[32, int(0.5 * (W - 1))],
                    field[32, int(0.9 * (W - 1))]])
    print(f"   line integral : {E_line:.4f}  (coverage {cov:.2f})")
    print(f"   3-point mean  : {mid3:.4f}")
    print(f"   true answer   : 0.5000  -> line integral is correct")

    print("\n4. Density from flow (q = rho*v*width):")
    for q in [1.0, 5.0, 20.0, 60.0]:
        rho, v = density_from_flow(np.array([q]), np.array([20.0])); rho=rho[0]; v=v[0]
        print(f"   q={q:5.1f} ped/s on 20 m width -> rho={float(rho):5.2f}, v={float(v):5.3f} m/s")

    print("\n5. Generalized cost components (1 km edge, E=0.3):")
    for r, th in [(0.5, 0), (0.5, 60), (4.5, 60)]:
        c, t, Ee, v = generalized_cost(1000.0, 0.3, r, th)
        print(f"   rho={r:4.1f} theta={th:3d} -> t={float(t)/60:6.1f} min, "
              f"E_eff={float(Ee):.3f}, cost={float(c)/60:7.1f} min-equiv")
    print("\nAll components behave as designed.")
