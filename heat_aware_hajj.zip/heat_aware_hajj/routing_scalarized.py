"""
Scalarized heat- and congestion-aware routing for the Hajj ritual circuit.

Design decisions (and why)
--------------------------
SCALARIZED, not constrained. We minimise a weighted sum

    c_ij = t_ij(rho) + theta * E_eff_ij * t_ij(rho) + phi * Psi(rho_ij)

rather than "minimise time subject to dose <= B". The constrained form is the
Resource-Constrained Shortest Path problem, which is weakly NP-hard; the
scalarised form collapses two objectives into one non-negative cost and stays
POLYNOMIAL. Sweeping theta traces the Pareto frontier approximately in
polynomial time instead of enumerating it exactly in exponential time.

SHORTEST PATH: A*, not plain Dijkstra. Shortest path with non-negative weights
is polynomial (Dijkstra is NOT NP-hard). Because every cost term is
non-negative, the Euclidean lower bound

    h(u, d) = great_circle(u, d) / v_free

is an ADMISSIBLE heuristic (it can never overestimate: actual cost >= travel
time >= actual distance / v_free >= straight-line distance / v_free), so A*
returns the exact optimum while expanding far fewer nodes.

EQUILIBRIUM: conjugate Frank-Wolfe, not MSA. MSA converges at O(1/n) -- in our
tests the relative gap fell only 0.44 -> 0.13 over 25 -> 400 iterations, which
made the theta sweep non-monotonic. CFW uses a conjugate search direction plus
an exact line search on the Beckmann objective and converges far faster.

Complexity
----------
Let V, E be nodes/edges, N equilibrium iterations, K line-search bisections,
S samples per edge for the line integral, L legs, T theta values.

  edge preparation (once)   O(E * S)
  one A* query              O(E + V log V) worst case; typically << with h()
  one line search           O(K * E)
  one CFW iteration         O(E + V log V + K*E)
  one leg to equilibrium    O(N * (E + V log V + K*E))
  full theta sweep          O(T * L * N * (E + V log V + K*E)) + O(E*S)

Because K and S are small constants, this is O(T*L*N*(E + V log V)) in practice
-- polynomial in every argument, with N the term CFW is designed to shrink.

Usage
-----
    python routing_scalarized.py --demo --sweep
    python routing_scalarized.py --risk field_prob.npy --sweep
    python routing_scalarized.py --demo --benchmark      # solver comparison
"""
from __future__ import annotations

import argparse
import json
import math
import time
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import networkx as nx

from routing_physics import (PARAMS, edge_exposure, speed_from_density,
                             density_from_flow, generalized_cost)
from routing_equilibrium import RITUAL_LEGS, THETA_CENTRE, prepare_edges

R_EARTH = 6371000.0


# ---------------------------------------------------------------------------
# Graph container with vectorised edge arrays (built once)
# ---------------------------------------------------------------------------

class RoutingGraph:
    """Simple DiGraph + parallel numpy arrays, so cost updates are vectorised."""

    def __init__(self, G):
        S = nx.DiGraph()
        S.add_nodes_from(G.nodes(data=True))
        for u, v, d in G.edges(data=True):
            if not S.has_edge(u, v) or d["length"] < S[u][v]["length"]:
                S.add_edge(u, v, length=float(d["length"]),
                           E=float(d["E"]), width=float(d["width"]))
        self.S = S
        self.edges = list(S.edges())
        self.idx = {e: i for i, e in enumerate(self.edges)}
        self.L = np.array([S[u][v]["length"] for u, v in self.edges])
        self.E = np.array([S[u][v]["E"] for u, v in self.edges])
        self.W = np.array([S[u][v]["width"] for u, v in self.edges])
        self.m = len(self.edges)
        self.pos = {n: (d["y"], d["x"]) for n, d in S.nodes(data=True)}
        self.astar_expansions = 0
        self.n_queries = 0

    # -- costs -------------------------------------------------------------
    def costs(self, flow, theta, p=PARAMS):
        rho, vel = density_from_flow(flow, self.W, p)
        c, t, E_eff, _ = generalized_cost(self.L, self.E, rho, theta, p)
        return c, t, E_eff, rho, vel

    def push_costs(self, c):
        for (u, v), cc in zip(self.edges, c):
            self.S[u][v]["cost"] = float(cc)

    # -- admissible heuristic ---------------------------------------------
    def heuristic(self, dst, p=PARAMS):
        """h(u) = great-circle(u,dst)/v_free : admissible lower bound on cost."""
        la2, lo2 = self.pos[dst]
        la2r, lo2r = math.radians(la2), math.radians(lo2)
        vfree = p["v_free"]

        def h(u, _v=None):
            la1, lo1 = self.pos[u]
            la1r = math.radians(la1)
            dlat = la1r - la2r
            dlon = math.radians(lo1 - lo2)
            a = (math.sin(dlat / 2) ** 2
                 + math.cos(la1r) * math.cos(la2r) * math.sin(dlon / 2) ** 2)
            d = 2 * R_EARTH * math.asin(min(1.0, math.sqrt(a)))
            return d / vfree
        return h

    def shortest(self, src, dst, use_astar=True, p=PARAMS):
        self.n_queries += 1
        if use_astar:
            return nx.astar_path(self.S, src, dst,
                                 heuristic=self.heuristic(dst, p), weight="cost")
        return nx.shortest_path(self.S, src, dst, weight="cost")


# ---------------------------------------------------------------------------
# Exact line search on the Beckmann objective
# ---------------------------------------------------------------------------

def line_search(rg, x, d, theta, p=PARAMS, tol=1e-7, maxit=40):
    """
    Find alpha in [0,1] minimising the Beckmann objective along x + alpha*d.

    The stationarity condition is phi(alpha) = d . c(x + alpha d) = 0. Cost is
    monotone increasing in flow (more flow -> higher density -> lower speed ->
    higher cost), so phi is monotone and BISECTION is guaranteed to work.
    Each evaluation is O(E), so the search is O(K*E).
    """
    def phi(a):
        c, *_ = rg.costs(x + a * d, theta, p)
        return float(np.dot(d, c))

    lo, hi = 0.0, 1.0
    if phi(hi) <= 0.0:
        return 1.0, 1                      # full step
    if phi(lo) >= 0.0:
        return 0.0, 1                      # no improving step
    k = 0
    while hi - lo > tol and k < maxit:
        mid = 0.5 * (lo + hi)
        if phi(mid) > 0.0:
            hi = mid
        else:
            lo = mid
        k += 1
    return 0.5 * (lo + hi), k


def hessian_diag(rg, x, theta, p=PARAMS, eps=1e-4):
    """Numerical diagonal of the Beckmann Hessian, i.e. dc_a/dx_a."""
    c0, *_ = rg.costs(x, theta, p)
    c1, *_ = rg.costs(x + eps, theta, p)
    return np.maximum((c1 - c0) / eps, 1e-12)


# ---------------------------------------------------------------------------
# Conjugate Frank-Wolfe
# ---------------------------------------------------------------------------

def assign_leg_cfw(rg, src, dst, demand, theta, p=PARAMS,
                   iters=60, tol=1e-4, use_astar=True, method="cfw",
                   verbose=False):
    """
    Solve one leg to user equilibrium.

    method: 'cfw'  conjugate Frank-Wolfe (recommended)
            'fw'   plain Frank-Wolfe with exact line search
            'msa'  Method of Successive Averages (the slow baseline)

    Returns metrics dict including the relative-gap curve, so convergence is
    auditable rather than asserted.
    """
    # --- initialise with a FEASIBLE flow: all-or-nothing at free-flow costs ---
    # Starting from x=0 is wrong: zero flow does not route the demand, so it is
    # infeasible, the descent condition (y-x).c(x) <= 0 fails, and the line
    # search correctly refuses to move. FW/CFW must start on the feasible set.
    c0, *_ = rg.costs(np.zeros(rg.m), theta, p)
    rg.push_costs(c0)
    try:
        p0 = rg.shortest(src, dst, use_astar, p)
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return None
    x = np.zeros(rg.m)
    for e in zip(p0[:-1], p0[1:]):
        x[rg.idx[e]] = demand

    d_prev = None
    gaps, alphas = [], []
    ls_iters = 0

    for n in range(1, iters + 1):
        c, t, E_eff, rho, vel = rg.costs(x, theta, p)
        rg.push_costs(c)

        try:
            path = rg.shortest(src, dst, use_astar, p)
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return None

        y = np.zeros(rg.m)
        for e in zip(path[:-1], path[1:]):
            y[rg.idx[e]] = demand

        # --- relative gap: standard traffic-assignment convergence measure ---
        tot = float(np.dot(x, c))
        aon = float(np.dot(y, c))
        gap = max(0.0, (tot - aon)) / max(abs(tot), 1e-9)
        gaps.append(float(gap))
        if n > 2 and gap < tol:
            if verbose:
                print(f"      converged iter {n}, gap {gap:.2e}")
            break

        d_fw = y - x

        if method == "msa":
            alpha = 1.0 / n
            d = d_fw
        else:
            d = d_fw
            if method == "cfw" and d_prev is not None:
                H = hessian_diag(rg, x, theta, p)
                num = float(np.dot(d_prev * H, d_fw))
                den = float(np.dot(d_prev * H, d_prev - d_fw))
                if abs(den) > 1e-12:
                    beta = num / den
                    if 0.0 <= beta < 0.99:                 # keep it a descent dir
                        d = d_fw + beta * (d_prev - d_fw)
            alpha, k = line_search(rg, x, d, theta, p)
            ls_iters += k

        x = x + alpha * d
        x = np.maximum(x, 0.0)
        alphas.append(float(alpha))
        d_prev = d

    # --- equilibrium state ---
    c, t, E_eff, rho, vel = rg.costs(x, theta, p)
    rg.push_costs(c)
    path = rg.shortest(src, dst, use_astar, p)

    dist = dose = time_s = danger_s = 0.0
    peak_rho = peak_E = 0.0
    for u, v in zip(path[:-1], path[1:]):
        i = rg.idx[(u, v)]
        dist += rg.L[i]; time_s += t[i]; dose += E_eff[i] * t[i]
        peak_rho = max(peak_rho, rho[i]); peak_E = max(peak_E, E_eff[i])
        if E_eff[i] > 0.5:
            danger_s += t[i]

    return {
        "distance_m": float(dist), "time_min": float(time_s / 60.0),
        "dose": float(dose), "peak_rho": float(peak_rho), "peak_E": float(peak_E),
        "danger_min": float(danger_s / 60.0),
        "gap": gaps[-1], "iters": len(gaps),
        "gap_curve": [float(g) for g in gaps],
        "mean_alpha": float(np.mean(alphas)) if alphas else 0.0,
        "line_search_iters": ls_iters,
        "path_nodes": len(path),
    }


# ---------------------------------------------------------------------------
# Circuit + sweep
# ---------------------------------------------------------------------------

def run_circuit(rg, nodes, theta, demand, p=PARAMS, method="cfw",
                use_astar=True, verbose=True):
    out, cursor = [], None
    for (a, b, day, dep_h, note) in RITUAL_LEGS:
        if a not in nodes or b not in nodes:
            continue
        r = assign_leg_cfw(rg, nodes[a], nodes[b], demand, theta, p,
                           method=method, use_astar=use_astar)
        if r is None:
            out.append({"leg": f"{a}->{b}", "day": day, "status": "no_path"})
            if verbose:
                print(f"  day {day}  {a:>11} -> {b:<11}  NO PATH")
            continue
        dep = dep_h if cursor is None else max(dep_h, cursor)
        r.update({"leg": f"{a}->{b}", "day": day, "depart_h": round(dep, 2),
                  "arrive_h": round(dep + r["time_min"] / 60.0, 2), "note": note})
        cursor = r["arrive_h"] % 24
        out.append(r)
        if verbose:
            print(f"  day {day}  {a:>11} -> {b:<11} "
                  f"{r['distance_m']/1000:5.2f} km {r['time_min']:6.1f} min "
                  f"dose {r['dose']:8.1f} peak_rho {r['peak_rho']:4.2f} "
                  f"gap {r['gap']:.1e} ({r['iters']} it)")
    return out


def theta_sweep(rg, nodes, demand, thetas, p=PARAMS, method="cfw"):
    rows = []
    for th in thetas:
        legs = run_circuit(rg, nodes, th, demand, p, method=method, verbose=False)
        good = [l for l in legs if l.get("status") != "no_path"]
        if not good:
            continue
        rows.append({
            "theta": float(th),
            "total_km": sum(l["distance_m"] for l in good) / 1000.0,
            "total_min": sum(l["time_min"] for l in good),
            "total_dose": sum(l["dose"] for l in good),
            "danger_min": sum(l["danger_min"] for l in good),
            "peak_rho": max(l["peak_rho"] for l in good),
            "peak_E": max(l["peak_E"] for l in good),
            "worst_gap": max(l["gap"] for l in good),
        })
    return rows


def print_sweep(rows):
    if not rows:
        print("  (no results)"); return
    base = rows[0]
    print("\n" + "=" * 100)
    print("THETA SWEEP (scalarized Pareto frontier)  theta = s of extra walking per unit dose")
    print("=" * 100)
    print(f"{'theta':>7}{'km':>9}{'minutes':>10}{'dose':>12}{'dose red%':>11}"
          f"{'detour%':>10}{'danger min':>12}{'peak rho':>10}{'worst gap':>12}")
    print("-" * 100)
    mono = True; prev = None
    for r in rows:
        dd = 100 * (base["total_dose"] - r["total_dose"]) / max(base["total_dose"], 1e-9)
        det = 100 * (r["total_km"] - base["total_km"]) / max(base["total_km"], 1e-9)
        if prev is not None and r["total_dose"] > prev + 1e-6:
            mono = False
        prev = r["total_dose"]
        print(f"{r['theta']:>7.0f}{r['total_km']:>9.2f}{r['total_min']:>10.1f}"
              f"{r['total_dose']:>12.1f}{dd:>10.1f}%{det:>9.2f}%"
              f"{r['danger_min']:>12.1f}{r['peak_rho']:>10.2f}{r['worst_gap']:>12.1e}")
    print("-" * 100)
    print(f"monotone in dose: {'YES' if mono else 'NO -- convergence not tight enough'}")
    print("theta=0 is the pure time-minimising (navigation-app) baseline.")
    print("No literature value exists for theta: report this frontier, not a point.")


# ---------------------------------------------------------------------------
# Benchmarks: solver comparison + complexity
# ---------------------------------------------------------------------------

def benchmark(rg, nodes, demand, theta=100.0, p=PARAMS):
    src, dst = nodes["Mina"], nodes["Arafat"]
    print("\n" + "=" * 78)
    print("SOLVER COMPARISON (same leg, same theta)")
    print("=" * 78)
    print(f"{'method':>8}{'A*':>5}{'iters':>7}{'final gap':>12}"
          f"{'dose':>10}{'seconds':>10}")
    print("-" * 78)
    res = {}
    for method in ("msa", "fw", "cfw"):
        for astar in (True,):
            t0 = time.time()
            r = assign_leg_cfw(rg, src, dst, demand, theta, p,
                               iters=60, method=method, use_astar=astar)
            dt = time.time() - t0
            if r:
                print(f"{method:>8}{'yes' if astar else 'no':>5}{r['iters']:>7}"
                      f"{r['gap']:>12.2e}{r['dose']:>10.1f}{dt:>10.2f}")
                res[method] = r

    # A* vs Dijkstra timing
    print("\nA* vs Dijkstra (query time on the same costs):")
    for astar in (False, True):
        t0 = time.time()
        for _ in range(5):
            rg.shortest(src, dst, use_astar=astar)
        dt = (time.time() - t0) / 5
        print(f"  {'A*' if astar else 'Dijkstra':>9}: {dt*1000:7.1f} ms/query")

    print("\nComplexity (this graph):")
    V, E = rg.S.number_of_nodes(), rg.S.number_of_edges()
    print(f"  V = {V:,}   E = {E:,}")
    print(f"  one A* query      O(E + V log V) = O({E:,} + {V:,}*{math.log2(max(V,2)):.0f})")
    print(f"  one line search   O(K*E), K~40   = O({40*E:,})")
    print(f"  one CFW iteration O(E + V log V + K*E)")
    if "cfw" in res and "msa" in res:
        sp = res["msa"]["iters"] / max(res["cfw"]["iters"], 1)
        print(f"  CFW used {res['cfw']['iters']} iters vs MSA {res['msa']['iters']} "
              f"-> {sp:.1f}x fewer at gap {res['cfw']['gap']:.1e} vs {res['msa']['gap']:.1e}")
    return res


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", help=".npy exceedance-probability grid P(WBGT>k)")
    ap.add_argument("--bbox", help="west,south,east,north")
    ap.add_argument("--cohort", default="unreg_75plus", choices=list(THETA_CENTRE))
    ap.add_argument("--method", default="cfw", choices=["cfw", "fw", "msa"])
    ap.add_argument("--no-astar", action="store_true")
    ap.add_argument("--sweep", action="store_true")
    ap.add_argument("--benchmark", action="store_true")
    ap.add_argument("--demand", type=float, default=None)
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo or not args.risk:
        print("DEMO MODE: irregular synthetic graph (logic check, not real geography)\n")
        from routing_equilibrium import demo_graph
        G, bbox, nodes = demo_graph()
        H = W = 96
        yy, xx = np.mgrid[0:H, 0:W] / H
        field = np.clip(.10 + .85 * np.exp(-((yy - .45) ** 2 + (xx - .60) ** 2) / .02)
                        + .55 * np.exp(-((yy - .72) ** 2 + (xx - .30) ** 2) / .012), 0, 1)
    else:
        from corridor_network import fetch, snap_sites
        G = fetch(); snapped = snap_sites(G)
        nodes = {k: v["node"] for k, v in snapped.items()}
        field = np.load(args.risk)
        bbox = (tuple(float(x) for x in args.bbox.split(","))
                if args.bbox else __import__("config").BBOX)
        print(f"risk grid {field.shape} range [{np.nanmin(field):.3f}, {np.nanmax(field):.3f}]")

    print("preparing edges (line-integral exposure) ...")
    prepare_edges(G, field, bbox)
    rg = RoutingGraph(G)
    print(f"  routing graph: {rg.S.number_of_nodes():,} nodes, {rg.m:,} edges")

    demand = (args.demand if args.demand is not None else
              PARAMS["n_pilgrims"] * PARAMS["walk_fraction"]
              / (PARAMS["leg_window_h"] * 3600.0))
    print(f"  demand: {demand:.1f} ped/s [assumed]")

    theta = THETA_CENTRE[args.cohort]
    print(f"\nCIRCUIT at equilibrium (cohort={args.cohort}, theta={theta:.0f}, "
          f"solver={args.method.upper()}, A*={'off' if args.no_astar else 'on'}):")
    legs = run_circuit(rg, nodes, theta, demand, method=args.method,
                       use_astar=not args.no_astar)
    good = [l for l in legs if l.get("status") != "no_path"]
    if good:
        print(f"\n  TOTAL {sum(l['distance_m'] for l in good)/1000:.2f} km, "
              f"{sum(l['time_min'] for l in good):.0f} min, "
              f"dose {sum(l['dose'] for l in good):.1f}, "
              f"worst gap {max(l['gap'] for l in good):.1e}")

    results = {"legs": legs, "cohort": args.cohort, "theta": theta,
               "method": args.method, "demand_ped_s": demand}

    if args.benchmark:
        results["benchmark"] = {k: {kk: vv for kk, vv in v.items()
                                    if kk != "gap_curve"}
                                for k, v in benchmark(rg, nodes, demand).items()}
    if args.sweep:
        rows = theta_sweep(rg, nodes, demand,
                           [0, 10, 20, 40, 60, 100, 150, 200, 300, 500],
                           method=args.method)
        print_sweep(rows)
        results["theta_sweep"] = rows

    with open("routing_scalarized_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nsaved -> routing_scalarized_results.json")


if __name__ == "__main__":
    main()
