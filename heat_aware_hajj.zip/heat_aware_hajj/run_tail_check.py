"""
Stage 4 driver: test whether the heat field is heavy-tailed -- the assumption the
whole extreme-value apparatus rests on.

REDUCTION MATTERS. Pooling every pixel from every scene gives a nominal n in the
hundreds of millions, but neighbouring 70 m pixels are strongly spatially
correlated and same-date scenes are correlated too, so the EFFECTIVE sample size
is closer to the number of independent acquisitions. Pooling anyway produces:

  * vanishingly narrow confidence bands on the mean-residual-life plot, so a
    threshold looks far better identified than it is;
  * normality / goodness-of-fit tests that reject at any threshold, because with
    n ~ 1e8 every test rejects -- the p-values carry no information;
  * an exceedance count in the millions, which looks reassuring and is not.

We therefore reduce each scene to ONE value by default (block maxima, or a high
spatial quantile). This is the same exchangeable unit used for the conformal
calibration, so the diagnostics and the calibration are consistent.

Usage
-----
    python run_tail_check.py                      # per-scene max (default)
    python run_tail_check.py --reduce q99         # 99th pct per scene
    python run_tail_check.py --reduce thin --thin 5000   # pooled+thinned
    python run_tail_check.py --reduce pool        # everything (NOT recommended)
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# Windows/Anaconda OpenMP guard. Must run BEFORE numpy/scipy/matplotlib import.
# Two OpenMP runtimes (e.g. MKL's libiomp5md.dll and a pip wheel's libomp.dll)
# can be loaded into one process, which aborts at import. Setting this env var
# here is reliable regardless of shell (cmd `set` vs PowerShell `$env:`).
# Safe for this script: it does a small scipy GPD fit and a matplotlib plot on
# a few hundred values -- no heavy parallel BLAS where the documented risk of
# incorrect results would apply. Do NOT rely on it for training.
# ---------------------------------------------------------------------------
import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import glob
import warnings

warnings.filterwarnings("ignore")

import numpy as np

try:
    import xarray as xr
except ImportError:
    raise SystemExit("xarray not installed. pip install xarray netCDF4")

from dataset import TARGET, acquisition_key
from tail_diagnostics import run_tail_diagnostics


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reduce", default="max",
                    choices=["max", "q99", "q95", "thin", "pool"],
                    help="how to reduce each scene to comparable units")
    ap.add_argument("--thin", type=int, default=5000,
                    help="stride for --reduce thin")
    ap.add_argument("--threshold-q", type=float, default=0.90)
    ap.add_argument("--pairs", default="data/pairs")
    args = ap.parse_args()

    files = sorted(glob.glob(f"{args.pairs}/*_pair.nc"))
    if not files:
        raise SystemExit(f"No pairs in {args.pairs}. Run align.py first.")

    vals, dates, n_px = [], [], 0
    for f in files:
        with xr.open_dataset(f) as ds:
            if TARGET not in ds:
                continue
            a = ds[TARGET].values.astype("float32")
            a = a[np.isfinite(a)]
            if a.size == 0:
                continue
            n_px += a.size
            d, _ = acquisition_key(f)
            if args.reduce == "max":
                vals.append(float(a.max())); dates.append(d)
            elif args.reduce == "q99":
                vals.append(float(np.percentile(a, 99))); dates.append(d)
            elif args.reduce == "q95":
                vals.append(float(np.percentile(a, 95))); dates.append(d)
            elif args.reduce == "thin":
                vals.append(a[::args.thin])
            else:
                vals.append(a)

    if not vals:
        raise SystemExit(f"Found {len(files)} pairs but none contain '{TARGET}'.")

    per_scene = args.reduce in ("max", "q99", "q95")
    x = np.asarray(vals, float) if per_scene else np.concatenate(vals)

    n_scenes = len(files)
    n_dates = len(set(d for d in dates if d)) if per_scene else None

    print("=" * 70)
    print("REDUCTION")
    print("=" * 70)
    print(f"  scenes read            : {n_scenes}")
    print(f"  raw valid pixels       : {n_px:,}")
    print(f"  reduction              : {args.reduce}"
          + (f" (stride {args.thin})" if args.reduce == "thin" else ""))
    print(f"  values used (nominal n): {x.size:,}")
    if per_scene:
        print(f"  distinct dates         : {n_dates}")
        print("  -> one value per scene: units are exchangeable across")
        print("     acquisitions, and match the unit used for ECP calibration.")
    else:
        print("  -> POOLED PIXELS. Nominal n is NOT the effective sample size:")
        print("     spatial correlation means confidence bands and p-values are")
        print("     over-confident. Report this, or use a per-scene reduction.")
    print()

    summary = run_tail_diagnostics(
        x, name=f"ECOSTRESS LST ({args.reduce}, n={x.size:,})",
        threshold_q=args.threshold_q,
        out_png=f"tail_real_{args.reduce}.png")

    xi = summary["gpd_shape"]["xi"]
    n_exc = summary["gpd_shape"]["n_exceed"]

    print("\n" + "=" * 70)
    print("WHAT TO DO WITH THIS")
    print("=" * 70)
    if np.isfinite(xi) and xi > 0.05:
        print("  HEAVY tail (xi > 0): the EVT framing is justified.")
    elif np.isfinite(xi) and xi < -0.05:
        print("  BOUNDED tail (xi < 0): soften EVT claims; lean the")
        print("  contribution on the calibration and routing layers.")
    else:
        print("  ~EXPONENTIAL tail (xi ~ 0): EVT applies but the tail is light.")
        print("  Be measured about claiming heavy-tail machinery is required.")

    if n_exc < 50:
        print(f"\n  [caution] only {n_exc} exceedances above the q{args.threshold_q:.2f}")
        print("  threshold. The GPD shape is barely identified; report the count")
        print("  and treat xi as indicative, not estimated.")

    print(f"\n  Use the mean-residual-life and threshold-stability panels in")
    print(f"  tail_real_{args.reduce}.png to choose the POT threshold: pick the")
    print("  LOWEST u above which both stabilise. Then re-run at q=0.85 and")
    print("  q=0.95 and report the sensitivity rather than a single choice.")
    print("\n  State the reduction in the paper -- it is a modelling decision.")


if __name__ == "__main__":
    main()
