"""
Schematic corridor network with DOCUMENTED Hajj geometry.

*** THIS IS NOT OPENSTREETMAP DATA. ***

The development environment had no access to the Overpass API or to Saudi GIS
services, so a real network could not be fetched. This module builds a
*schematic* corridor instead, and must be labelled as such in any write-up:

  - ritual-site coordinates are the real, documented ones (verify before
    publication);
  - inter-site distances are therefore real great-circle distances;
  - the CORRIDOR TOPOLOGY is schematic: between consecutive sites we place a
    small number of parallel routes with distinct exposure/width characteristics,
    reflecting the documented reality that only a handful of engineered corridors
    connect the sites (pedestrian walkways, road corridors, tunnels), rather than
    a dense street grid;
  - widths and exposures are ASSUMED, chosen to span the plausible range.

Why the topology matters
------------------------
The earlier random-grid test could not exhibit equity differentiation because
68% of its edges had identical exposure -- every path cost the same, so
displacing a cohort onto residual capacity changed nothing. Real corridors have
FEW alternatives that differ SUBSTANTIALLY (a shaded tunnel is cooler and
narrower than an open road), which is exactly the regime where capacity is
scarce and a lexicographic priority actually bites.

Route archetypes per leg
------------------------
  tunnel/shaded : lowest exposure, NARROW  (scarce, desirable)
  walkway       : medium exposure, wide
  open road     : highest exposure, wide
"""
from __future__ import annotations

import math
import numpy as np
import networkx as nx

from corridor_network import SITES
from routing_equilibrium import RITUAL_LEGS

R_EARTH = 6371000.0

# [ASSUMED] route archetypes: (name, exposure multiplier, width m, detour factor)
ARCHETYPES = [
    ("tunnel",  0.45,  8.0, 1.06),   # coolest, narrow -> scarce capacity
    ("walkway", 0.80, 22.0, 1.00),   # baseline
    ("road",    1.15, 25.0, 0.98),   # hottest, widest, most direct
]

BASE_EXPOSURE = 0.55      # [ASSUMED] mid-afternoon corridor exceedance level
SEG_LEN_M = 400.0         # waypoint spacing along a corridor


def gc_m(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R_EARTH * math.asin(min(1.0, math.sqrt(a)))


def build_corridor(exposure_jitter=0.12, seed=0):
    """
    Returns (G, nodes, meta). G is a MultiDiGraph with the attributes the
    routing code expects: y, x on nodes; length, E, width, highway on edges.
    """
    rng = np.random.default_rng(seed)
    G = nx.MultiDiGraph(crs="epsg:4326")
    nodes = {}

    # site nodes at their real coordinates
    for name, (la, lo) in SITES.items():
        nid = f"S:{name}"
        G.add_node(nid, y=float(la), x=float(lo))
        nodes[name] = nid

    meta = {"legs": [], "archetypes": [a[0] for a in ARCHETYPES]}

    # unique ordered site pairs from the ritual circuit
    pairs = []
    for (a, b, day, dep, note) in RITUAL_LEGS:
        if (a, b) not in pairs:
            pairs.append((a, b))

    for (a, b) in pairs:
        la1, lo1 = SITES[a]; la2, lo2 = SITES[b]
        straight = gc_m(la1, lo1, la2, lo2)

        for (arch, exp_mult, width, det) in ARCHETYPES:
            length = straight * det
            nseg = max(2, int(round(length / SEG_LEN_M)))
            # lateral offset so archetypes are geometrically distinct
            off = {"tunnel": -0.0035, "walkway": 0.0, "road": 0.0035}[arch]
            dlat, dlon = (la2 - la1), (lo2 - lo1)
            # unit normal in degrees (approximate, fine at this scale)
            nrm = math.hypot(dlat, dlon) or 1e-9
            nx_, ny_ = -dlon / nrm, dlat / nrm

            prev = nodes[a]
            for k in range(1, nseg + 1):
                t = k / nseg
                bulge = math.sin(math.pi * t) * off
                yy = la1 + dlat * t + ny_ * bulge
                xx = lo1 + dlon * t + nx_ * bulge
                cur = nodes[b] if k == nseg else f"W:{a}-{b}:{arch}:{k}"
                if cur != nodes[b]:
                    G.add_node(cur, y=float(yy), x=float(xx))
                seg_len = length / nseg
                E = float(np.clip(BASE_EXPOSURE * exp_mult
                                  * (1 + rng.normal(0, exposure_jitter)), 0.02, 0.99))
                for (u, v) in ((prev, cur), (cur, prev)):
                    G.add_edge(u, v, length=float(seg_len), E=E,
                               width=float(width), highway=arch, archetype=arch,
                               leg=f"{a}->{b}")
                prev = cur

        meta["legs"].append({"from": a, "to": b,
                             "straight_km": round(straight / 1000, 3)})

    # Jamarat is a documented bottleneck: throttle its approach widths
    n_throttled = 0
    for u, v, k, d in G.edges(keys=True, data=True):
        if "Jamarat" in str(d.get("leg", "")):
            d["width"] = min(d["width"], 10.0)      # [ASSUMED] narrowed approach
            n_throttled += 1
    meta["jamarat_edges_throttled"] = n_throttled
    return G, nodes, meta


def summary(G, nodes, meta):
    import numpy as np
    E = np.array([d["E"] for _, _, _, d in G.edges(keys=True, data=True)])
    W = np.array([d["width"] for _, _, _, d in G.edges(keys=True, data=True)])
    print(f"schematic corridor: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    print(f"  exposure : min {E.min():.3f} median {np.median(E):.3f} max {E.max():.3f}")
    frac = float(np.mean(np.abs(E - np.median(E)) < 0.05 * np.median(E)))
    print(f"  fraction within 5% of median: {frac:.2f}  "
          f"(the random grid had 0.68 -- this is the fix)")
    print(f"  widths   : min {W.min():.0f} m median {np.median(W):.0f} m max {W.max():.0f} m")
    print("  legs:")
    for L in meta["legs"]:
        print(f"    {L['from']:>11} -> {L['to']:<11} {L['straight_km']:6.2f} km straight")
    print(f"  Jamarat approach edges throttled: {meta['jamarat_edges_throttled']}")
    und = G.to_undirected()
    comps = list(nx.connected_components(und))
    print(f"  connected components: {len(comps)} (largest {len(max(comps,key=len))})")
    return E, W


if __name__ == "__main__":
    print("=" * 74)
    print("SCHEMATIC HAJJ CORRIDOR  (NOT OpenStreetMap -- see module docstring)")
    print("=" * 74)
    G, nodes, meta = build_corridor()
    summary(G, nodes, meta)
    print("\nPer-archetype exposure (the scarcity structure that enables equity):")
    for arch, mult, width, det in ARCHETYPES:
        e = [d["E"] for _, _, _, d in G.edges(keys=True, data=True)
             if d["archetype"] == arch]
        print(f"  {arch:<8} mean E {np.mean(e):.3f}  width {width:5.1f} m  "
              f"({'scarce/desirable' if arch=='tunnel' else 'ample'})")
