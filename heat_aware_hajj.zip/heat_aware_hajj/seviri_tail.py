"""
Meteosat SEVIRI land surface temperature: the best available block maxima.

WHY GEOSTATIONARY BEATS POLAR-ORBITING FOR THIS PURPOSE.

Extreme-value analysis on block maxima needs the blocks to be comparable draws
from the same distribution. Our two polar-orbiting records each fall short:

  ECOSTRESS   70 m, but the ISS orbit precesses, so acquisitions drift through
              the diurnal cycle. Time of day explains R^2 = 0.937 of the
              variance in scene-level temperature, and the GPD shape drifted
              from -0.49 to -0.89 with threshold: not identified.
  MODIS       1 km at four FIXED local times (Terra 10:30/22:30, Aqua
              13:30/01:30). Aqua's 13:30 pass sits near the measured diurnal
              peak of 12.94 h and does give an identified shape, but a "daily
              maximum" from two daytime samples is the larger of two draws, not
              the day's actual maximum. If the peak falls between overpasses it
              is missed.

  SEVIRI      3 km at nadir, degrading to roughly 5-6 km at Makkah's viewing
              geometry, but scanning the full disk every FIFTEEN MINUTES from a
              fixed geostationary position. Roughly 96 observations per day
              means the daily maximum is genuinely observed, and the viewing
              geometry is identical on every scan, so exchangeability is exact
              rather than approximate. The record runs from 2004.

For a corridor-aggregate tail statistic, temporal completeness is what matters
and spatial resolution is not; at 3-6 km the corridor is only a handful of
pixels, so SEVIRI cannot inform routing. This is the same complementarity
argument as for MODIS, one step further.

A true daily maximum also makes annual maxima directly comparable to the
station-based GEV analyses in the literature, which fit annual maxima of daily
maximum temperature.

DATA ACCESS. The product is LSA SAF MLST (LSA-001), 15-minute land surface
temperature on the MSG grid, distributed as HDF5 after free registration at
https://landsaf.ipma.pt. Values are stored as integers in hundredths of a degree
Celsius with -8000 as the fill value. Makkah (21.42 N, 39.89 E) lies near the
eastern edge of the North Africa (NAfr) regional subset; verify the region
covers the corridor before bulk-downloading, or use the full-disk product.

Usage
-----
    python seviri_tail.py --check            # inspect one file, confirm geometry
    python seviri_tail.py --root data/raw/seviri
    python seviri_tail.py --root data/raw/seviri --stat q95
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import glob
import json
import re
import warnings
from collections import defaultdict
from datetime import datetime

warnings.filterwarnings("ignore")

import numpy as np

SCALE = 0.01          # stored in hundredths of a degree Celsius
FILL = -8000
UTC_OFFSET_H = 3.0    # Makkah


def parse_slot(path):
    """LSA SAF names carry _YYYYMMDDhhmm. Returns (date, local hour)."""
    m = re.search(r"_(\d{8})(\d{4})", os.path.basename(path))
    if not m:
        return None, None
    d = datetime.strptime(m.group(1), "%Y%m%d").date()
    hh = int(m.group(2)[:2]) + int(m.group(2)[2:]) / 60.0
    return d, (hh + UTC_OFFSET_H) % 24.0


def read_lst(path, window=None):
    """
    Read the LST field from an LSA SAF HDF5 granule, in degrees Celsius.

    h5py is used directly rather than GDAL: the same HDF4 driver problem that
    blocked the MODIS read applies to HDF5 in some builds, and h5py has no such
    dependency.
    """
    try:
        import h5py
    except ImportError:
        raise SystemExit("h5py is required. Run: pip install h5py")
    try:
        with h5py.File(path, "r") as f:
            key = "LST" if "LST" in f else next(
                (k for k in f.keys() if "LST" in k.upper()), None)
            if key is None:
                return None
            a = np.asarray(f[key][:]).astype("float32")
    except Exception:
        return None

    a[a == FILL] = np.nan
    a = a * SCALE
    a[(a < -50) | (a > 85)] = np.nan
    if window is not None:
        r0, r1, c0, c1 = window
        if r1 > a.shape[0] or c1 > a.shape[1]:
            return None
        a = a[r0:r1, c0:c1]
    return a if np.isfinite(a).any() else None


def inspect(path):
    """Print the structure of one granule so the window can be set correctly."""
    import h5py
    print(f"  file: {os.path.basename(path)}")
    print(f"  size: {os.path.getsize(path):,} bytes")
    with h5py.File(path, "r") as f:
        print("  datasets:")
        for k in list(f.keys())[:12]:
            try:
                print(f"    {k:<24} shape {f[k].shape} dtype {f[k].dtype}")
            except Exception:
                print(f"    {k}")
        print("  root attributes of interest:")
        for k, v in list(f.attrs.items()):
            if any(t in k.upper() for t in
                   ("REGION", "PROJ", "SUB", "NC", "NL", "CFAC", "COFF",
                    "LFAC", "LOFF", "SCAL", "MISS")):
                print(f"    {k} = {v}")
    print("\n  Set --window r0 r1 c0 c1 from the grid geometry above. The MSG")
    print("  projection is geostationary, not lat/lon: converting the corridor")
    print("  box to row/column needs CFAC/COFF/LFAC/LOFF from the attributes.")


def gpd_sweep(x, qs=(0.60, 0.70, 0.80, 0.90, 0.95)):
    from scipy.stats import genpareto
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    out = []
    for q in qs:
        u = float(np.quantile(x, q))
        exc = x[x > u] - u
        if exc.size < 10:
            out.append({"q": q, "n_exc": int(exc.size), "xi": None})
            continue
        xi, _, sc = genpareto.fit(exc, floc=0)
        out.append({"q": q, "n_exc": int(exc.size), "xi": float(xi),
                    "scale": float(sc), "u": u,
                    "endpoint": float(u - sc / xi) if xi < 0 else float("inf")})
    return out


def gev_annual(maxima):
    """GEV on annual maxima, the framing used by the station-based literature."""
    from scipy.stats import genextreme
    m = np.asarray(maxima, float); m = m[np.isfinite(m)]
    if m.size < 8:
        return None
    c, loc, sc = genextreme.fit(m)
    xi = -float(c)          # scipy's c is the negative of the usual shape
    rl = {T: float(genextreme.ppf(1 - 1 / T, c, loc, sc)) for T in (2, 10, 50, 100)}
    return {"xi": xi, "loc": float(loc), "scale": float(sc),
            "n": int(m.size), "return_levels": rl}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="data/raw/seviri")
    ap.add_argument("--stat", default="q95",
                    choices=["q95", "q99", "max", "mean"])
    ap.add_argument("--window", nargs=4, type=int, default=None,
                    metavar=("R0", "R1", "C0", "C1"),
                    help="row/column window covering the corridor")
    ap.add_argument("--min-pixels", type=int, default=4,
                    help="valid pixels needed to use a slot")
    ap.add_argument("--check", action="store_true",
                    help="inspect one granule and exit")
    ap.add_argument("--day-only", action="store_true", default=True,
                    help="restrict to daylight slots (default)")
    args = ap.parse_args()

    files = sorted(glob.glob(os.path.join(args.root, "**", "*.h5"),
                             recursive=True)) or \
            sorted(glob.glob(os.path.join(args.root, "**", "*HDF5*"),
                             recursive=True))
    print("=" * 76)
    print("SEVIRI 15-MINUTE LST: TRUE DAILY MAXIMA")
    print("=" * 76)
    print(f"  granules found: {len(files)}")
    if not files:
        print("\n  No files. Register at https://landsaf.ipma.pt and download the")
        print("  MLST (LSA-001) product for the corridor. Note the 15-minute")
        print("  cadence: one month is ~2,900 granules, so start with one month")
        print("  and confirm the geometry before a bulk pull.")
        return
    if args.check:
        inspect(files[0]); return

    if args.window is None:
        print("\n  [warn] no --window given, so the WHOLE granule is used. At")
        print("  3-6 km that is a continental field, not the corridor. Run with")
        print("  --check first and set the window.")

    red = {"q95": lambda v: np.nanpercentile(v, 95),
           "q99": lambda v: np.nanpercentile(v, 99),
           "max": np.nanmax, "mean": np.nanmean}[args.stat]

    per_slot, n_ok, n_unread, n_mask, frac = [], 0, 0, 0, []
    for f in files:
        d, loc_h = parse_slot(f)
        if d is None:
            continue
        if args.day_only and not (6.0 <= loc_h <= 19.0):
            continue
        a = read_lst(f, tuple(args.window) if args.window else None)
        if a is None:
            n_unread += 1
            continue
        v = a[np.isfinite(a)]
        # LST is masked for sea, cloud and quality, so a correctly located
        # window is still frequently empty. That is a MASKED slot, not an
        # unreadable file, and the two are counted separately: a high unread
        # count means the window or the reader is wrong, while a high masked
        # count is just weather.
        if v.size < args.min_pixels:
            n_mask += 1
            frac.append(float(np.isfinite(a).mean()))
            continue
        frac.append(float(np.isfinite(a).mean()))
        per_slot.append((d, loc_h, float(red(v))))
        n_ok += 1

    print(f"  slots with data: {n_ok}   cloud/quality masked: {n_mask}   "
          f"unreadable: {n_unread}")
    if frac:
        print(f"  valid-pixel fraction in the window: median "
              f"{np.median(frac):.2f}, max {max(frac):.2f}")
    if not per_slot:
        print("\n  No slot had enough valid pixels.")
        if n_unread > n_mask:
            print("  Most files could not be READ, so the window or the reader")
            print("  is wrong. Check msg_window.py --file against one granule:")
            print("  the sub-satellite point must map to COFF/LOFF.")
        else:
            print("  The files read correctly but the window was masked. That is")
            print("  cloud and quality masking, not an error. Try more days, or")
            print("  lower --min-pixels, accepting a noisier scene statistic.")
        return

    # ---- true daily maxima, and the hour at which they occur ---------------
    by_day = defaultdict(list)
    for d, h, v in per_slot:
        by_day[d].append((h, v))
    days = sorted(by_day)
    dmax = {d: max(by_day[d], key=lambda t: t[1]) for d in days}
    n_per_day = np.array([len(by_day[d]) for d in days])
    peak_h = np.array([dmax[d][0] for d in days])
    vals = np.array([dmax[d][1] for d in days])

    print(f"\n1. DAILY COVERAGE")
    print(f"   days: {len(days)}  ({days[0]} .. {days[-1]})")
    print(f"   slots per day: median {np.median(n_per_day):.0f}, "
          f"range {n_per_day.min()}-{n_per_day.max()}")
    print(f"   daily maximum: {vals.min():.1f} .. {vals.max():.1f} C")
    print(f"   hour of daily maximum: median {np.median(peak_h):.2f} h local, "
          f"IQR {np.percentile(peak_h,25):.2f}-{np.percentile(peak_h,75):.2f}")
    print("   With ~15-minute sampling the daily maximum is OBSERVED, not the")
    print("   larger of two overpasses. The spread in the hour at which it")
    print("   occurs is exactly what a twice-daily sensor cannot see, and is")
    print("   why ECOSTRESS and MODIS block maxima are not comparable draws.")
    miss = float(np.mean((peak_h < 13.0) | (peak_h > 14.0)))
    print(f"   fraction of days whose peak falls outside 13:00-14:00: {miss:.2f}")
    print("   (those are the days Aqua's 13:30 overpass would under-record)")

    # ---- tail ------------------------------------------------------------
    print(f"\n2. GPD THRESHOLD SWEEP on {len(days)} daily maxima")
    for r in gpd_sweep(vals):
        if r["xi"] is None:
            print(f"   q{r['q']:.2f}: only {r['n_exc']} exceedances")
        else:
            print(f"   q{r['q']:.2f}: xi {r['xi']:+.3f}  k={r['n_exc']:>4}  "
                  f"endpoint {r['endpoint']:6.1f} C")
    print("   A shape steady across thresholds is identified. Compare:")
    print("     ECOSTRESS  -0.49 to -0.89 (drift 0.40, NOT identified)")
    print("     MODIS Aqua -0.276 to -0.191 (drift 0.085, identified)")

    by_year = defaultdict(list)
    for d in days:
        by_year[d.year].append(dmax[d][1])
    yrs = sorted(by_year)
    amax = [max(by_year[y]) for y in yrs]
    print(f"\n3. ANNUAL MAXIMA ({len(yrs)} years)")
    for y, v in zip(yrs, amax):
        print(f"   {y}: {v:5.1f} C   ({len(by_year[y])} days)")
    g = gev_annual(amax)
    if g:
        print(f"\n   GEV on annual maxima: xi {g['xi']:+.3f}, "
              f"loc {g['loc']:.1f}, scale {g['scale']:.2f}")
        print("   return levels (years): " +
              "  ".join(f"{T}y {v:.1f} C" for T, v in g["return_levels"].items()))
        print("   These are true annual maxima of an observed daily maximum, so")
        print("   the framing matches the station-based GEV literature directly.")

    json.dump({"days": [str(d) for d in days],
               "daily_max": vals.tolist(),
               "peak_hour": peak_h.tolist(),
               "annual_max": {str(y): v for y, v in zip(yrs, amax)},
               "gev": g}, open("seviri_tail.json", "w"), indent=2)
    print("\n  results -> seviri_tail.json")
    print("\n  NOTE. At 3-6 km the corridor spans only a few pixels, so SEVIRI")
    print("  characterises the corridor's thermal regime and tail but cannot")
    print("  inform routing. Its contribution is temporal completeness.")


if __name__ == "__main__":
    main()
