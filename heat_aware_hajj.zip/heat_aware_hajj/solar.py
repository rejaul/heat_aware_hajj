"""
Solar geometry for the radiation correction in the paper.

Implements the sunlit-fraction-averaged cosine of the solar zenith angle,

    cos(theta)_bar = (1 / dt_sun) * integral over sunlit part of the hour,

which prevents the spurious heat-index spikes at sunrise/sunset that appear if
you average cos(theta) over the whole hour (including the dark part) or sample
it only at the hour's midpoint.

Solar position follows the standard NOAA low-precision algorithm; accuracy is
well within what is needed for hourly heat-index work.
"""
from __future__ import annotations

import numpy as np

DEG = np.pi / 180.0


def _fractional_year(doy, hour):
    return 2.0 * np.pi / 365.0 * (doy - 1 + (hour - 12.0) / 24.0)


def _declination(gamma):
    return (0.006918
            - 0.399912 * np.cos(gamma) + 0.070257 * np.sin(gamma)
            - 0.006758 * np.cos(2 * gamma) + 0.000907 * np.sin(2 * gamma)
            - 0.002697 * np.cos(3 * gamma) + 0.00148 * np.sin(3 * gamma))


def _eq_of_time(gamma):
    """Equation of time, minutes."""
    return 229.18 * (0.000075
                     + 0.001868 * np.cos(gamma) - 0.032077 * np.sin(gamma)
                     - 0.014615 * np.cos(2 * gamma) - 0.040849 * np.sin(2 * gamma))


def cos_zenith(lat_deg, lon_deg, doy, hour_utc):
    """Cosine of the solar zenith angle (negative values mean sun below horizon)."""
    gamma = _fractional_year(doy, hour_utc)
    decl = _declination(gamma)
    eot = _eq_of_time(gamma)

    # True solar time in minutes, then hour angle.
    tst = (hour_utc * 60.0) + eot + 4.0 * lon_deg
    ha = (tst / 4.0 - 180.0) * DEG

    lat = np.asarray(lat_deg) * DEG
    return (np.sin(lat) * np.sin(decl)
            + np.cos(lat) * np.cos(decl) * np.cos(ha))


def mean_cos_zenith_sunlit(lat_deg, lon_deg, doy, hour_utc, n_sub=60):
    """
    Average cos(zenith) over the *sunlit* portion of the hour beginning at
    `hour_utc`, plus the sunlit fraction itself.

    Returns
    -------
    (mean_cos, sunlit_fraction)
        mean_cos is 0.0 for fully dark hours.
    """
    offsets = (np.arange(n_sub) + 0.5) / n_sub          # sub-hour midpoints
    doy = np.asarray(doy, dtype=float)
    hour_utc = np.asarray(hour_utc, dtype=float)

    # Broadcast: put the sub-hour axis last.
    sub_hours = hour_utc[..., None] + offsets
    mu = cos_zenith(np.asarray(lat_deg)[..., None],
                    np.asarray(lon_deg)[..., None],
                    doy[..., None], sub_hours)

    sunlit = mu > 0.0
    frac = sunlit.mean(axis=-1)

    total = np.where(sunlit, mu, 0.0).sum(axis=-1)
    count = sunlit.sum(axis=-1)
    mean_cos = np.divide(total, count, out=np.zeros_like(total),
                         where=count > 0)
    return mean_cos, frac


SOLAR_CONSTANT = 1361.0        # W m-2, top of atmosphere


def direct_sunlit_radiation(ssrd_j_m2, mean_cos, sunlit_frac, dt_seconds=3600.0,
                            min_frac=0.05, max_flux=SOLAR_CONSTANT):
    """
    Convert ERA5 downward shortwave (J m-2 PER HOUR) to a mean flux over the
    sunlit part of the hour (W m-2), the quantity that drives the radiant term.

    IMPORTANT: ssrd must already be DE-ACCUMULATED (see align.deaccumulate).
    ERA5-Land accumulations run from 00 UTC, so passing the raw stored value
    overestimates the flux by up to ~24x.

    Two guards, both added after a real failure:

    min_frac  Floor on the sunlit fraction. The previous floor of 1e-6 permitted
              a 10^6-fold amplification near sunrise/sunset; 0.05 caps it at 20x.
    max_flux  Hard cap at the solar constant. No surface flux can exceed it, so
              anything above is a computation error rather than weather. Without
              this cap the pipeline produced 183,941 W m-2 (135x the solar
              constant), which propagated into tg = t + 0.0125*sw_sunlit and
              gave globe temperatures of 2338 C and WBGT of 488 C.
    """
    with np.errstate(divide="ignore", invalid="ignore"):
        flux = np.where(sunlit_frac > 0,
                        ssrd_j_m2 / (dt_seconds * np.maximum(sunlit_frac, min_frac)),
                        0.0)
    flux = np.clip(np.nan_to_num(flux, nan=0.0, posinf=max_flux), 0.0, max_flux)
    return flux * np.where(mean_cos > 0, 1.0, 0.0)
