"""
Mean radiant temperature from a digital surface model, SOLWEIG-style.

WHY. Our hazard field is land surface temperature, which Reviewer 1 correctly
noted overstates risk on asphalt and understates it in shade. The
physiologically relevant quantity is mean radiant temperature T_mrt: the
uniform enclosure temperature that would give a person the same net radiant
exchange as their actual surroundings. Unlike LST it is not observed from
space, because it depends on where a person stands, what they can see of the
sky, and whether they are in sun or shadow. It must be modelled.

T_mrt is also the input that turns our relative index into a physiological one:
it feeds UTCI and the globe-temperature term of WBGT.

METHOD (Hoppe 1992; Lindberg, Holmer & Thorsson 2008, the SOLWEIG model).
For each pixel and timestep:

  1. cast shadows from the DSM along the solar vector
  2. compute the sky view factor by ray casting
  3. sum the radiant fluxes reaching a standing person: direct, diffuse and
     reflected shortwave, plus longwave from sky and from surrounding surfaces
  4. invert the Stefan-Boltzmann law for the equivalent black-body temperature

The person is represented by angular weighting factors: 0.06 for the upward and
downward hemispheres and 0.22 for each of four sides, summing to one. The
cylinder projected-area factor for direct beam is taken as 0.22.

WHAT THIS NEEDS THAT WE DO NOT HAVE. A digital surface model at metre scale.
Constructing one from building footprints and a coarse height raster, as the
`--synthesise` option does, is an approximation: shadow geometry is exactly
where it is weakest. At Mina the dominant shade source is a seasonal tent city
that building datasets do not contain at all, so a result there would be
missing the main effect. Check coverage before trusting any output.

Usage
-----
    python solweig_tmrt.py --demo                     # synthetic block geometry
    python solweig_tmrt.py --dsm dsm.tif --hour 13
    python solweig_tmrt.py --dsm dsm.tif --hour 13 --ta 43 --rh 20 --out tmrt.npy
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import math
import warnings

warnings.filterwarnings("ignore")

import numpy as np

SIGMA = 5.670374419e-8      # Stefan-Boltzmann
ALB_PERSON = 0.70           # shortwave absorption of a human (1 - albedo 0.30)
EPS_PERSON = 0.97           # longwave emissivity of clothing/skin
F_UP = F_DOWN = 0.06        # angular weighting, standing person
F_SIDE = 0.22               # each of four sides
F_CYL = 0.22                # projected-area factor for the direct beam


# ---------------------------------------------------------------- geometry
def solar_position(lat, lon, day_of_year, local_hour, utc_offset=3.0):
    """Solar altitude and azimuth in degrees. Azimuth measured from north."""
    d = math.radians(360.0 / 365.0 * (day_of_year - 81))
    eot = 9.87 * math.sin(2 * d) - 7.53 * math.cos(d) - 1.5 * math.sin(d)
    lstm = 15.0 * utc_offset
    tc = 4.0 * (lon - lstm) + eot
    solar_time = local_hour + tc / 60.0
    hra = math.radians(15.0 * (solar_time - 12.0))
    decl = math.radians(23.45 * math.sin(math.radians(360.0 / 365.0 *
                                                     (day_of_year - 81))))
    la = math.radians(lat)
    alt = math.asin(math.sin(decl) * math.sin(la) +
                    math.cos(decl) * math.cos(la) * math.cos(hra))
    az = math.acos(np.clip((math.sin(decl) * math.cos(la) -
                            math.cos(decl) * math.sin(la) * math.cos(hra)) /
                           max(math.cos(alt), 1e-9), -1, 1))
    if hra > 0:
        az = 2 * math.pi - az
    return math.degrees(alt), math.degrees(az)


def cast_shadow(dsm, px, sun_alt_deg, sun_az_deg, max_dist_m=300.0):
    """
    Binary shadow mask by iterative height comparison along the solar vector.

    This is the Ratti and Richens shifting method used by SOLWEIG: step along
    the sun azimuth, lowering a reference surface by the height the sun drops
    over that distance, and mark a pixel shadowed wherever the shifted terrain
    still rises above it. It is exact for a raster surface and far cheaper than
    per-pixel ray tracing.
    """
    alt = math.radians(max(sun_alt_deg, 0.1))
    az = math.radians(sun_az_deg)
    # direction the shadow is cast TOWARD (away from the sun)
    dx, dy = -math.sin(az), math.cos(az)

    shadow = np.zeros_like(dsm, dtype=bool)
    n_steps = int(max_dist_m / px)
    for k in range(1, n_steps + 1):
        dist = k * px
        drop = dist * math.tan(alt)
        sx, sy = int(round(dx * k)), int(round(dy * k))
        if abs(sx) >= dsm.shape[1] or abs(sy) >= dsm.shape[0]:
            break
        shifted = np.full_like(dsm, -9999.0)
        ys = slice(max(0, sy), dsm.shape[0] + min(0, sy))
        xs = slice(max(0, sx), dsm.shape[1] + min(0, sx))
        ys2 = slice(max(0, -sy), dsm.shape[0] + min(0, -sy))
        xs2 = slice(max(0, -sx), dsm.shape[1] + min(0, -sx))
        shifted[ys2, xs2] = dsm[ys, xs] - drop
        shadow |= shifted > dsm
    return shadow


def sky_view_factor(dsm, px, n_dirs=16, max_dist_m=200.0):
    """
    Fraction of the hemisphere that is sky, by ray casting in n_dirs azimuths.

    For each direction we find the maximum elevation angle to any obstruction
    and integrate the unobstructed solid angle. 16 directions is the SOLWEIG
    default and is adequate; more directions cost time for little gain.
    """
    H, W = dsm.shape
    max_elev = np.zeros((n_dirs, H, W), dtype="float32")
    n_steps = max(1, int(max_dist_m / px))
    for i in range(n_dirs):
        az = 2 * math.pi * i / n_dirs
        dx, dy = math.sin(az), -math.cos(az)
        for k in range(1, n_steps + 1):
            sx, sy = int(round(dx * k)), int(round(dy * k))
            if abs(sx) >= W or abs(sy) >= H:
                break
            shifted = np.full_like(dsm, -9999.0)
            ys = slice(max(0, sy), H + min(0, sy))
            xs = slice(max(0, sx), W + min(0, sx))
            ys2 = slice(max(0, -sy), H + min(0, -sy))
            xs2 = slice(max(0, -sx), W + min(0, -sx))
            shifted[ys2, xs2] = dsm[ys, xs]
            dh = shifted - dsm
            ang = np.arctan2(np.maximum(dh, 0.0), k * px)
            max_elev[i] = np.maximum(max_elev[i], ang)
    # SVF for a vertical-cylinder person: average of cos^2 over directions
    svf = np.mean(np.cos(max_elev) ** 2, axis=0)
    return np.clip(svf, 0.0, 1.0)


# ------------------------------------------------------------- radiation
def tmrt_field(dsm, px, sun_alt, sun_az, ta_c, rh_pct,
               ghi=None, albedo_ground=0.25, eps_ground=0.95,
               ts_offset=18.0, ts_shade_offset=4.0):
    """
    T_mrt in degrees Celsius.

    ta_c, rh_pct    air temperature and relative humidity
    ghi             global horizontal irradiance, W/m2; estimated if None
    ts_offset       how far a SUNLIT surface sits above air temperature. In an
                    arid corridor at midday this is large; 18 K is a
                    conservative value consistent with our observed LST
                    (surface ~60 C against air ~43 C).
    ts_shade_offset the same for shaded surface.
    """
    alt = math.radians(max(sun_alt, 0.0))
    if ghi is None:
        # clear-sky estimate; replace with measured GHI where available
        ghi = max(0.0, 1098.0 * math.sin(alt) * math.exp(-0.057 / max(math.sin(alt), 1e-3)))
    # Erbs split into direct and diffuse
    kt = np.clip(ghi / max(1367.0 * math.sin(alt), 1e-6), 0.0, 1.0) if alt > 0 else 0.0
    kd = 0.165 if kt > 0.8 else (0.9511 - 0.1604 * kt + 4.388 * kt**2
                                 - 16.638 * kt**3 + 12.336 * kt**4) if kt > 0.22 \
         else 1.0 - 0.09 * kt
    dif = ghi * kd
    dni = (ghi - dif) / max(math.sin(alt), 1e-3) if alt > 0 else 0.0

    shadow = cast_shadow(dsm, px, sun_alt, sun_az) if alt > 0 else np.ones_like(dsm, bool)
    svf = sky_view_factor(dsm, px)
    sunlit = (~shadow).astype("float32")

    # --- shortwave reaching the person, by direction ---
    #
    # The six angular weights must sum to one and every direction must receive
    # its flux. An earlier version applied the side weights only to part of the
    # shortwave, which silently discarded roughly 40% of the absorbed energy and
    # produced T_mrt BELOW air temperature in full sun.
    #
    #   from above : direct beam on the horizontal plus diffuse sky
    #   from below : ground-reflected
    #   each side  : half the diffuse sky plus half the ground reflection
    K_down = (dni * math.sin(alt) * sunlit + dif * svf)       # horizontal
    K_up = albedo_ground * K_down                             # reflected
    K_side = 0.5 * dif * svf + 0.5 * albedo_ground * K_down
    # the beam also strikes the cylinder's flank when the sun is low
    K_beam_side = dni * math.cos(alt) * sunlit * F_CYL

    K_total = (K_down * F_UP + K_up * F_DOWN
               + 4.0 * K_side * F_SIDE + K_beam_side)

    # --- longwave, same weighting discipline ---
    ta_k = ta_c + 273.15
    e_a = (rh_pct / 100.0) * 6.112 * math.exp(17.67 * ta_c / (ta_c + 243.5))
    eps_sky = 1.24 * (e_a / ta_k) ** (1.0 / 7.0)          # Brutsaert
    L_sky = eps_sky * SIGMA * ta_k ** 4

    ts_k = ta_k + ts_offset * sunlit + ts_shade_offset * (1.0 - sunlit)
    L_surf = eps_ground * SIGMA * ts_k ** 4

    # upward hemisphere sees sky where unobstructed, surfaces where not
    L_above = svf * L_sky + (1.0 - svf) * L_surf
    L_total = (L_above * F_UP + L_surf * F_DOWN + 4.0 * L_above * F_SIDE)

    # --- absorbed radiation and the equivalent black-body temperature ---
    S_str = ALB_PERSON * K_total + EPS_PERSON * L_total
    tmrt_k = (S_str / (EPS_PERSON * SIGMA)) ** 0.25
    return tmrt_k - 273.15, {"svf": svf, "shadow": shadow, "ghi": ghi,
                             "dni": dni, "dif": dif}


# ------------------------------------------------------------------ main
def synth_dsm(n=200, px=2.0, seed=0):
    """A synthetic block geometry, for checking the pipeline without real data."""
    rng = np.random.default_rng(seed)
    d = np.zeros((n, n), "float32")
    for _ in range(18):
        h = rng.uniform(6, 25)
        r0, c0 = rng.integers(5, n - 35, 2)
        dr, dc = rng.integers(12, 32, 2)
        d[r0:r0 + dr, c0:c0 + dc] = h
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dsm", default=None, help="GeoTIFF surface model (ground+buildings)")
    ap.add_argument("--demo", action="store_true", help="use synthetic geometry")
    ap.add_argument("--px", type=float, default=2.0, help="pixel size, m")
    ap.add_argument("--lat", type=float, default=21.4133)
    ap.add_argument("--lon", type=float, default=39.8933)
    ap.add_argument("--doy", type=int, default=166, help="day of year (166 = 14 Jun)")
    ap.add_argument("--hour", type=float, default=13.0, help="local solar hour")
    ap.add_argument("--ta", type=float, default=43.0, help="air temperature, C")
    ap.add_argument("--rh", type=float, default=20.0, help="relative humidity, %%")
    ap.add_argument("--ghi", type=float, default=None, help="measured GHI, W/m2")
    ap.add_argument("--out", default=None, help="save T_mrt as .npy")
    args = ap.parse_args()

    if args.demo or args.dsm is None:
        dsm, px = synth_dsm(), args.px
        src = "synthetic block geometry"
    else:
        import rioxarray
        da = rioxarray.open_rasterio(args.dsm, masked=True).squeeze()
        dsm = np.nan_to_num(np.asarray(da.values, "float32"))
        px = abs(float(da.rio.resolution()[0]))
        src = args.dsm

    alt, az = solar_position(args.lat, args.lon, args.doy, args.hour)
    print("=" * 72)
    print("MEAN RADIANT TEMPERATURE (SOLWEIG-style)")
    print("=" * 72)
    print(f"  surface model : {src}  {dsm.shape} at {px:.1f} m")
    print(f"  position      : {args.lat:.4f} N, {args.lon:.4f} E, DOY {args.doy}, "
          f"{args.hour:.1f} h local")
    print(f"  sun           : altitude {alt:.1f} deg, azimuth {az:.1f} deg")
    print(f"  air           : {args.ta:.1f} C, RH {args.rh:.0f}%")
    if alt <= 0:
        print("  sun below the horizon; T_mrt is longwave only")

    tmrt, aux = tmrt_field(dsm, px, alt, az, args.ta, args.rh, args.ghi)

    shade_frac = float(aux["shadow"].mean())
    print(f"\n  GHI {aux['ghi']:.0f} W/m2  (direct {aux['dni']:.0f}, "
          f"diffuse {aux['dif']:.0f})")
    print(f"  shaded fraction : {shade_frac:.3f}")
    print(f"  sky view factor : {aux['svf'].min():.2f} .. {aux['svf'].max():.2f}"
          f"  mean {aux['svf'].mean():.2f}")
    print(f"\n  T_mrt : {np.nanmin(tmrt):.1f} .. {np.nanmax(tmrt):.1f} C   "
          f"mean {np.nanmean(tmrt):.1f}  sd {np.nanstd(tmrt):.1f}")

    sun_m = float(np.nanmean(tmrt[~aux["shadow"]])) if (~aux["shadow"]).any() else float("nan")
    sh_m = float(np.nanmean(tmrt[aux["shadow"]])) if aux["shadow"].any() else float("nan")
    print(f"  sunlit mean {sun_m:.1f} C   shaded mean {sh_m:.1f} C   "
          f"difference {sun_m - sh_m:.1f} K")
    print(f"  air temperature is {args.ta:.1f} C throughout, so the spatial")
    print("  variation above is entirely radiative. This is the contrast that")
    print("  70 m land surface temperature cannot resolve, and the reason")
    print("  T_mrt and not LST is the physiologically relevant field.")

    if args.out:
        np.save(args.out, tmrt.astype("float32"))
        np.save(args.out.replace(".npy", "_svf.npy"), aux["svf"].astype("float32"))
        print(f"\n  wrote {args.out} and the sky view factor alongside")

    json.dump({"sun_alt": alt, "sun_az": az, "ghi": aux["ghi"],
               "shade_fraction": shade_frac,
               "tmrt_min": float(np.nanmin(tmrt)),
               "tmrt_max": float(np.nanmax(tmrt)),
               "tmrt_sunlit_mean": sun_m, "tmrt_shaded_mean": sh_m},
              open("solweig_tmrt.json", "w"), indent=2)
    print("  summary -> solweig_tmrt.json")
    print("\n  NEXT: feed this field to route_diversity.py in place of the LST")
    print("  exceedance. If between-path spread now exceeds the usability")
    print("  threshold, shade supplies the heterogeneity surface temperature")
    print("  lacked, and the negative result becomes conditional.")
    print("\n  CAVEAT: a DSM built from footprints and a coarse height raster is")
    print("  an approximation, and at Mina the dominant shade source is a")
    print("  seasonal tent city absent from building datasets entirely.")


if __name__ == "__main__":
    main()
