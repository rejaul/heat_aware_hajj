"""
Drop-in replacement for dataset.split_files() that ACTUALLY delivers the claim
"trained and evaluated on disjoint ECOSTRESS acquisition dates".

Two defects in the original:

  1. it sorted by FILENAME. ECOSTRESS pair names put the orbit number before the
     timestamp (ECOv002_L2T_LSTE_<orbit>_<scene>_<tile>_<YYYYMMDD>T<HHMMSS>_...),
     so lexicographic order sorts by orbit, not acquisition time. Orbit and date
     correlate but are not identical, so the split was not reliably chronological.

  2. it sliced by INDEX. Even with a correct chronological sort, a date with
     several scenes can straddle a boundary, putting scenes from the SAME day on
     both sides. That breaks date-disjointness and weakens the conformal
     calibration guarantee, which requires the calibration set to be genuinely
     held out.

This version parses the timestamp, groups scenes BY DATE, and splits at date
boundaries -- so every acquisition date lands wholly in one set.

Usage: replace split_files in dataset.py with this, or import it.
"""
from __future__ import annotations

import re
from pathlib import Path

import config

TS = re.compile(r"(\d{8})T(\d{6})")
D8 = re.compile(r"(\d{8})")


def acquisition_key(path: Path):
    """
    (date, datetime) parsed from an ECOSTRESS-derived pair filename.
    Returns (None, None) if no timestamp is present.
    """
    m = TS.search(path.name)
    if m:
        return m.group(1), m.group(1) + m.group(2)
    m = D8.search(path.name)
    if m:
        return m.group(1), m.group(1) + "000000"
    return None, None


def split_files(pair_dir=None, val_frac=0.15, cal_frac=0.20, seed=0,
                strict=True, verbose=True):
    """
    Chronological split at DATE boundaries.

    train | val | calib are contiguous in time and share no acquisition date.
    Fractions are applied to the number of DATES, not the number of scenes, so
    the scene counts will not match the fractions exactly -- that is correct and
    should be reported as-is.

    strict=True raises if any file lacks a parseable timestamp, so the claim
    cannot be made on unverifiable data.
    """
    pair_dir = Path(pair_dir or config.PAIRS)
    files = sorted(pair_dir.glob("*_pair.nc"))
    if not files:
        raise SystemExit(f"No pairs in {pair_dir}. Run align.py first.")

    keyed, unparsed = [], []
    for f in files:
        d, dt = acquisition_key(f)
        (unparsed if d is None else keyed).append(f if d is None else (d, dt, f))

    if unparsed:
        msg = (f"{len(unparsed)} file(s) have no parseable acquisition "
               f"timestamp, e.g. {unparsed[0].name}")
        if strict:
            raise SystemExit(
                msg + "\nA date-disjoint split cannot be verified. Either fix "
                "the naming in align.py or call with strict=False (and then do "
                "NOT claim disjoint acquisition dates).")
        print("  [warn] " + msg)

    # group scenes by date, order dates chronologically
    by_date = {}
    for d, dt, f in keyed:
        by_date.setdefault(d, []).append((dt, f))
    dates = sorted(by_date)
    n_dates = len(dates)
    if n_dates < 3:
        raise SystemExit(
            f"Only {n_dates} distinct acquisition date(s). A three-way "
            "date-disjoint split is impossible; widen config.QUICK_RANGE.")

    n_val = max(1, round(val_frac * n_dates))
    n_cal = max(1, round(cal_frac * n_dates))
    if n_val + n_cal >= n_dates:
        raise SystemExit(
            f"{n_dates} dates cannot support val={n_val} + cal={n_cal} and a "
            "non-empty training set. Widen the window.")

    d_tr = dates[: n_dates - n_val - n_cal]
    d_va = dates[n_dates - n_val - n_cal: n_dates - n_cal]
    d_cal = dates[n_dates - n_cal:]

    def flat(ds):
        out = []
        for d in ds:
            out.extend(f for _, f in sorted(by_date[d]))
        return out

    tr, va, cal = flat(d_tr), flat(d_va), flat(d_cal)

    # invariant: no date appears in more than one set
    assert not (set(d_tr) & set(d_va)), "date leak train/val"
    assert not (set(d_tr) & set(d_cal)), "date leak train/calib"
    assert not (set(d_va) & set(d_cal)), "date leak val/calib"

    if verbose:
        print(f"  date-grouped chronological split over {n_dates} dates:")
        print(f"    train {len(d_tr):>3} dates / {len(tr):>3} scenes  "
              f"[{d_tr[0]} .. {d_tr[-1]}]")
        print(f"    val   {len(d_va):>3} dates / {len(va):>3} scenes  "
              f"[{d_va[0]} .. {d_va[-1]}]")
        print(f"    calib {len(d_cal):>3} dates / {len(cal):>3} scenes  "
              f"[{d_cal[0]} .. {d_cal[-1]}]")
        print("    all sets are date-disjoint and strictly forward in time")

    return tr, va, cal


if __name__ == "__main__":
    tr, va, cal = split_files()
    print(f"\ntrain {len(tr)} | val {len(va)} | calib {len(cal)}")
    print("\nNumbers to paste into the paper:")
    print(f"  'The {len(tr)+len(va)+len(cal)} usable scenes span N acquisition")
    print("   dates, partitioned chronologically at date boundaries into")
    print(f"   training ({len(tr)} scenes), validation ({len(va)}) and")
    print(f"   calibration ({len(cal)}) sets that share no acquisition date.'")
