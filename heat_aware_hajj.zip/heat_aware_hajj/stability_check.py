"""
Does a macroscopic assignment sit in the stop-and-go regime?

THE QUESTION. Our min-cost flow assigns densities assuming orderly flow at a
steady-state fundamental diagram. Real crowds above some density develop
stop-and-go waves, and above that, turbulence. Neither is representable in a
steady-state relation, and both are what precede crush incidents. So: for a
given assignment, is any arc operating where uniform flow would be unstable?

WHY THIS DOES NOT NEED A SOCIAL FORCE SIMULATION. Stop-and-go is a LINEAR
INSTABILITY of uniform flow, and instability thresholds depend on far fewer
parameters than the full non-linear dynamics. For the optimal-velocity class of
car-following and pedestrian models, uniform flow at density rho is linearly
unstable when

    tau * rho^2 * |v'(rho)|  >  1/2

where tau is the relaxation time (how quickly a pedestrian adjusts speed toward
the equilibrium value). Everything else in that expression comes from the
fundamental diagram we already use. So the check needs ONE parameter beyond what
the paper already assumes, and because the criterion is monotone in tau we can
sweep it and report a boundary rather than asserting a value.

For Weidmann, v(rho) = vf [1 - exp(-gamma(1/rho - 1/rho_j))], the derivative
simplifies: rho^2 |v'(rho)| = vf * gamma * exp(-gamma(1/rho - 1/rho_j)).

WHAT THIS IS NOT. A linear criterion detects the ONSET of instability, not what
the crowd does afterwards. Amplitude, wave speed and whether instability
develops into turbulence all need the non-linear model. This answers "is this
operating point in the unstable regime", which is the yes/no question, and
deliberately not more.

Run:
    python stability_check.py
    python stability_check.py --assignment real_network_validation.json
    python stability_check.py --tau 0.3 0.5 0.7
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import argparse
import json
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

import numpy as np

# Weidmann parameters, as used throughout the paper
VF, RHO_J, GAMMA = 1.34, 5.4, 1.913
RHO_C = 4.0          # crush onset


def v_weidmann(rho, vf=VF, rj=RHO_J, g=GAMMA):
    rho = np.maximum(np.asarray(rho, float), 1e-9)
    with np.errstate(over="ignore"):
        return vf * (1.0 - np.exp(-g * (1.0 / rho - 1.0 / rj)))


def instability_index(rho, tau, vf=VF, rj=RHO_J, g=GAMMA):
    """tau * rho^2 * |v'(rho)|; uniform flow is unstable where this exceeds 1/2."""
    rho = np.maximum(np.asarray(rho, float), 1e-9)
    return tau * vf * g * np.exp(-g * (1.0 / rho - 1.0 / rj))


def critical_density(tau, vf=VF, rj=RHO_J, g=GAMMA):
    """Lowest density at which uniform flow becomes linearly unstable."""
    r = np.linspace(0.05, rj - 0.01, 40000)
    bad = instability_index(r, tau, vf, rj, g) > 0.5
    return float(r[np.argmax(bad)]) if bad.any() else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tau", nargs="+", type=float,
                    default=[0.2, 0.3, 0.4, 0.5, 0.7, 1.0],
                    help="relaxation times to sweep (s)")
    ap.add_argument("--rho-star", type=float, default=1.751)
    ap.add_argument("--assignment", default=None,
                    help="real_network_validation.json, to check realised arcs")
    args = ap.parse_args()

    print("=" * 74)
    print("STOP-AND-GO STABILITY OF THE ASSIGNED OPERATING POINT")
    print("=" * 74)
    print("  criterion: uniform flow is linearly unstable where")
    print("      tau * rho^2 |v'(rho)| > 1/2")
    print("  Only tau is new; the rest is the fundamental diagram already in use.")
    print(f"\n  rho* = {args.rho_star:.3f},  crush onset rho_c = {RHO_C}")

    print(f"\n{'tau (s)':>9}{'rho_crit':>11}{'index at rho*':>15}{'verdict at rho*':>20}")
    print("-" * 56)
    rows = []
    for tau in args.tau:
        rc = critical_density(tau)
        idx = float(instability_index(args.rho_star, tau))
        unstable = idx > 0.5
        rows.append({"tau": tau, "rho_crit": rc, "index_at_rho_star": idx,
                     "unstable_at_rho_star": bool(unstable)})
        print(f"{tau:>9.2f}{rc:>11.2f}{idx:>15.3f}"
              f"{'UNSTABLE' if unstable else 'stable':>20}")

    tau_b = None
    lo, hi = 0.05, 3.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if instability_index(args.rho_star, mid) > 0.5:
            hi = mid
        else:
            lo = mid
    tau_b = 0.5 * (lo + hi)

    print("\n" + "=" * 74)
    print("READING THIS")
    print("=" * 74)
    print(f"  The boundary is at tau = {tau_b:.2f} s. Below it, uniform flow at")
    print("  rho* is linearly stable; above it, stop-and-go waves grow.")
    print("  Reported pedestrian relaxation times span roughly 0.3-1.0 s, and")
    print("  slower-reacting pedestrians (elderly, encumbered, unfamiliar with")
    print("  the route) sit at the upper end.")
    print("\n  CONSEQUENCE FOR THE CAPACITY RESULT. rho* maximises flow in the")
    print("  steady-state relation, but it is NOT automatically in the stable")
    print("  regime. For tau above the boundary the flow-maximising density is")
    print("  itself subject to stop-and-go, so the operating point implied by")
    print("  the fundamental diagram alone may be optimistic. A stability-aware")
    print("  operating point is")
    print("      rho_op = min(rho*, rho_crit(tau))")
    print("  which is never higher than rho* and is lower for slow responders.")
    for r in rows:
        if r["unstable_at_rho_star"]:
            print(f"    at tau={r['tau']:.1f} s: rho_op = {r['rho_crit']:.2f} "
                  f"instead of {args.rho_star:.2f} "
                  f"({100*(1-r['rho_crit']/args.rho_star):.0f}% lower)")

    # ---- check an actual assignment, if one is supplied -------------------
    if args.assignment and Path(args.assignment).exists():
        d = json.load(open(args.assignment))
        print("\n  REALISED ARCS IN THE SUPPLIED ASSIGNMENT")
        any_row = False
        for coh, v_ in d.get("assignment", {}).items():
            if not isinstance(v_, dict):
                continue
            util = v_.get("max_utilisation")
            full = v_.get("arcs_at_capacity")
            if util is None:
                continue
            any_row = True
            rho_real = args.rho_star * float(util)
            flags = [f"{t:.1f}" for t in args.tau
                     if instability_index(rho_real, t) > 0.5]
            print(f"    {coh:<16} max util {util:.2f} -> rho {rho_real:.2f}, "
                  f"{full} arcs at capacity; unstable for tau >= "
                  f"{flags[0] if flags else 'none tested'}")
        if not any_row:
            print("    (no utilisation fields found)")
        print("\n  Arcs at capacity are at rho* by construction, so whether they")
        print("  are in the unstable regime depends entirely on tau.")

    json.dump({"rho_star": args.rho_star, "tau_boundary": tau_b, "sweep": rows},
              open("stability_check.json", "w"), indent=2)
    print("\n  results -> stability_check.json")
    print("\n  LIMITATION. This is a linear onset criterion. It says whether an")
    print("  operating point is in the unstable regime, not what the crowd does")
    print("  once instability develops. Amplitude, wave speed and the transition")
    print("  to turbulence require the non-linear model and trajectory data to")
    print("  calibrate it.")


if __name__ == "__main__":
    main()
