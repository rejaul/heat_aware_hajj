"""
Would surface-type predictors improve the downscaler? Check before building.

THE LOGIC. Adding albedo, NDVI or impervious fraction as input channels means
sourcing rasters, aligning them, retraining and revalidating: a day's work at
least. It is worth that only if surface type explains variation the model is
currently getting wrong.

The diagnostic is direct. If the model's prediction residuals correlate with a
surface-type proxy, the model is systematically wrong over particular surfaces
and the channel would help. If they do not, the eleven meteorological inputs,
which include coarse skin temperature, are already capturing surface effects
indirectly and the extra channels would add complexity for nothing.

PROXIES, IN ORDER OF PREFERENCE.
  real raster     a supplied albedo / NDVI / impervious GeoTIFF, aligned to the
                  study box. Best, but needs sourcing.
  OSM surface     edges carry a `surface` tag (asphalt, sand, paving_stones);
                  rasterising it gives a crude but free and directly relevant
                  classification over the corridor.
  self-proxy      the per-pixel TIME MEAN of observed LST across all scenes.
                  Surfaces that are persistently hotter than their surroundings
                  are the impervious ones; this needs no external data at all.
                  It is circular if used as a model input, but it is perfectly
                  sound as a DIAGNOSTIC of whether such structure exists.

Run:
    python surface_residuals.py                       # self-proxy
    python surface_residuals.py --raster albedo.tif
    python surface_residuals.py --osm-surface
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import glob
import json
import warnings

warnings.filterwarnings("ignore")

import numpy as np


def load_residuals(split="val", device="cpu", max_scenes=24):
    """Per-pixel residuals y - mu over held-out scenes, stacked."""
    import torch
    import xarray as xr
    from model import AMUN
    from dataset import PREDICTORS, TARGET, BASELINE, split_files

    ck = torch.load("checkpoints/amun_best.pt", map_location=device)
    st = ck["stats"][TARGET]; y_mu, y_sd = st["mean"], st["std"]
    net = AMUN(in_ch=len(PREDICTORS)); net.load_state_dict(ck["model"])
    net.eval().to(device)

    tr, va, ca = split_files(verbose=False)
    files = {"train": tr, "val": va, "calib": ca}[split][:max_scenes]

    res, obs = [], []
    with torch.no_grad():
        for f in files:
            with xr.open_dataset(f) as d:
                ch = []
                for v in PREDICTORS:
                    a = (np.nan_to_num(d[v].values.astype("float32"))
                         if v in d else np.zeros(d[TARGET].shape, "float32"))
                    s2 = ck["stats"].get(v)
                    ch.append((a - s2["mean"]) / s2["std"] if s2 else a)
                x = torch.from_numpy(np.stack(ch, 0))[None].to(device)
                b = (np.nan_to_num(d[BASELINE].values.astype("float32")) - y_mu) / y_sd
                base = torch.from_numpy(b)[None, None].to(device)
                y = d[TARGET].values.astype("float32")
            out = net(x, baseline=base)
            mu = (out[0] if isinstance(out, (tuple, list)) else out)
            mu = mu[0, 0].cpu().numpy() * y_sd + y_mu
            r = y - mu
            res.append(r); obs.append(y)
    return np.stack(res), np.stack(obs)


def self_proxy(obs):
    """
    Per-pixel time-mean of observed LST, as a surface-type stand-in.

    Pixels that are persistently hotter than the scene mean are the impervious
    ones. Circular as a model INPUT, but valid as a diagnostic: it asks whether
    persistent per-pixel structure exists that the model is failing to capture.
    """
    z = obs - np.nanmean(obs, axis=(1, 2), keepdims=True)   # remove scene level
    return np.nanmean(z, axis=0)


def rasterise_osm_surface(shape, bbox):
    """Crude surface classification from OSM `surface` tags along edges."""
    import networkx as nx
    try:
        G = nx.read_graphml("data/corridor_walk.graphml")
    except Exception:
        return None
    HARD = {"asphalt", "concrete", "paved", "paving_stones", "sett"}
    SOFT = {"sand", "ground", "dirt", "earth", "gravel", "unpaved"}
    H, W = shape
    west, south, east, north = bbox
    grid = np.full((H, W), np.nan, "float32")
    n_tag = 0
    for u, v, d in G.edges(data=True):
        s = str(d.get("surface", "")).lower()
        if not s:
            continue
        val = 1.0 if any(k in s for k in HARD) else (0.0 if any(k in s for k in SOFT) else np.nan)
        if not np.isfinite(val):
            continue
        n_tag += 1
        for n in (u, v):
            try:
                la, lo = float(G.nodes[n]["y"]), float(G.nodes[n]["x"])
            except KeyError:
                continue
            r = int((north - la) / (north - south) * (H - 1))
            c = int((lo - west) / (east - west) * (W - 1))
            if 0 <= r < H and 0 <= c < W:
                grid[r, c] = val
    print(f"   OSM edges carrying a surface tag: {n_tag}")
    return grid if n_tag > 20 else None


def report(res_mean, proxy, label):
    m = np.isfinite(res_mean) & np.isfinite(proxy)
    if m.sum() < 100:
        print(f"   {label}: too few overlapping pixels ({m.sum()})")
        return None
    a, b = res_mean[m], proxy[m]
    r = float(np.corrcoef(a, b)[0, 1])
    # variance of the residual explained by a linear fit on the proxy
    p = np.polyfit(b, a, 1)
    expl = 1.0 - np.var(a - np.polyval(p, b)) / max(np.var(a), 1e-12)
    print(f"   {label:<28} n={m.sum():>7}  r={r:+.3f}  "
          f"variance explained {100*expl:5.1f}%  slope {p[0]:+.3f}")
    return {"label": label, "n": int(m.sum()), "r": r,
            "variance_explained": float(expl), "slope": float(p[0])}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="val", choices=["train", "val", "calib"])
    ap.add_argument("--raster", default=None,
                    help="albedo / NDVI / impervious GeoTIFF over the study box")
    ap.add_argument("--osm-surface", action="store_true")
    ap.add_argument("--max-scenes", type=int, default=24)
    ap.add_argument("--bbox")
    args = ap.parse_args()

    import config
    bbox = (tuple(float(x) for x in args.bbox.split(","))
            if args.bbox else config.BBOX)

    print("=" * 74)
    print("DOES SURFACE TYPE EXPLAIN THE MODEL'S RESIDUALS?")
    print("=" * 74)
    res, obs = load_residuals(args.split, max_scenes=args.max_scenes)
    print(f"  scenes: {res.shape[0]}  grid: {res.shape[1]}x{res.shape[2]}")
    print(f"  residual (y - mu): mean {np.nanmean(res):+.2f} C, "
          f"sd {np.nanstd(res):.2f} C")

    # the quantity of interest: PERSISTENT per-pixel bias, not scene-level error
    res_mean = np.nanmean(res, axis=0)
    res_sd_pix = np.nanstd(np.nanmean(res, axis=(1, 2)))
    print(f"  per-pixel mean residual: sd {np.nanstd(res_mean):.2f} C "
          f"(scene-to-scene sd {res_sd_pix:.2f} C)")
    print("  A large per-pixel sd means the model is persistently wrong in")
    print("  particular PLACES, which is what a surface-type channel could fix.")

    print("\n  CORRELATION AGAINST SURFACE PROXIES")
    out = []
    p = self_proxy(obs)
    r = report(res_mean, p, "self-proxy (persistent LST)")
    if r:
        out.append(r)

    if args.raster:
        try:
            import rioxarray
            da = rioxarray.open_rasterio(args.raster, masked=True).squeeze()
            arr = np.asarray(da.values, "float32")
            if arr.shape != res_mean.shape:
                from scipy.ndimage import zoom
                arr = zoom(arr, (res_mean.shape[0] / arr.shape[0],
                                 res_mean.shape[1] / arr.shape[1]), order=1)
            r = report(res_mean, arr, os.path.basename(args.raster))
            if r:
                out.append(r)
        except Exception as e:
            print(f"   raster failed: {str(e)[:70]}")

    if args.osm_surface:
        g = rasterise_osm_surface(res_mean.shape, bbox)
        if g is not None:
            r = report(res_mean, g, "OSM surface tag (hard=1/soft=0)")
            if r:
                out.append(r)
        else:
            print("   OSM surface tags: too few to use")

    print("\n" + "=" * 74)
    print("READING THIS")
    print("=" * 74)
    best = max((abs(r["r"]) for r in out), default=0.0)
    if best < 0.15:
        print(f"  Strongest correlation is {best:.3f}. Surface type explains")
        print("  almost none of the residual structure, so the eleven")
        print("  meteorological channels, which include coarse skin")
        print("  temperature, are already capturing surface effects")
        print("  indirectly. Adding albedo or NDVI channels would add")
        print("  complexity for little gain. Do not build it.")
    elif best < 0.35:
        print(f"  Strongest correlation is {best:.3f}: a modest relationship.")
        print("  A surface channel would help somewhat. Worth doing if time")
        print("  allows, but it is not where the largest error lives.")
    else:
        print(f"  Strongest correlation is {best:.3f}. The model is")
        print("  systematically wrong over particular surface types, and a")
        print("  surface-type channel should measurably reduce residual")
        print("  variance. Worth building.")
    print("\n  CAVEAT ON THE SELF-PROXY. It is derived from the observed LST")
    print("  the model is trying to predict, so a correlation shows that")
    print("  persistent spatial structure is being missed; it does not prove")
    print("  an EXTERNAL surface product would capture that structure. Confirm")
    print("  with a real raster before committing to a retrain.")

    json.dump(out, open("surface_residuals.json", "w"), indent=2)
    print("\n  results -> surface_residuals.json")


if __name__ == "__main__":
    main()
