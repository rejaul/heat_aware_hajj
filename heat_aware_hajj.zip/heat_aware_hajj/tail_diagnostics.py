"""
Tail diagnostics -- validate the distributional assumptions that justify the
extreme-value machinery.

The method choice (GPD tail, EQRN, extreme conformal) is only warranted if the
heat field is actually heavy-tailed and the peaks-over-threshold model fits. This
module runs the standard extreme-value diagnostics to test that, on ANY 1-D
sample of field values (synthetic now, real ECOSTRESS later).

Diagnostics implemented
-----------------------
1. Descriptive tail signals   : skewness, kurtosis, tail ratios.
2. Normality / light-tail tests: Shapiro-Wilk, Anderson-Darling, Jarque-Bera.
   Rejecting normality is necessary (not sufficient) evidence against a light tail.
3. Tail-index estimation      : Hill estimator (+ plot) and GPD-shape (xi) MLE.
   xi > 0 => heavy (Frechet) tail; xi = 0 => exponential; xi < 0 => bounded.
4. Mean residual life (mean excess) plot : should be ~linear above a valid GPD
   threshold; the slope's sign echoes xi. THE classic threshold + fit diagnostic.
5. Threshold stability plot   : xi and modified scale should be ~constant above
   the true threshold. Instability => threshold too low / GPD misspecified.
6. GPD goodness-of-fit        : fit GPD to exceedances; QQ-plot correlation and a
   Kolmogorov-Smirnov / Anderson-Darling test of the exceedances vs fitted GPD.
7. Return-level curve with CI : the practical output of the tail model.

Everything is saved as a multi-panel PNG plus a printed/return summary dict, so
you can drop the figure straight into the paper and cite the numbers.

Usage
-----
    from tail_diagnostics import run_tail_diagnostics
    summary = run_tail_diagnostics(values, name="ECOSTRESS LST",
                                   out_png="tail_diag.png")
"""
from __future__ import annotations

import numpy as np
from scipy import stats
from scipy.stats import genpareto

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# 1. Descriptive
# ---------------------------------------------------------------------------

def descriptive_tail(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    q = np.percentile(x, [50, 90, 95, 99, 99.9])
    return {
        "n": int(x.size),
        "mean": float(np.mean(x)),
        "std": float(np.std(x)),
        "skewness": float(stats.skew(x)),
        "excess_kurtosis": float(stats.kurtosis(x)),   # 0 = normal
        "q50": float(q[0]), "q90": float(q[1]), "q95": float(q[2]),
        "q99": float(q[3]), "q99.9": float(q[4]),
        # tail ratio: how far the 99.9th sits above the 50th, in IQR units
        "tail_ratio_99.9_vs_50": float((q[4] - q[0]) /
                                       (np.percentile(x, 75) - np.percentile(x, 25) + 1e-9)),
    }


# ---------------------------------------------------------------------------
# 2. Normality / light-tail tests
# ---------------------------------------------------------------------------

def normality_tests(x, max_n=5000):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    xs = x if x.size <= max_n else np.random.default_rng(0).choice(x, max_n, replace=False)
    out = {}
    try:
        w, p = stats.shapiro(xs)
        out["shapiro_W"] = float(w); out["shapiro_p"] = float(p)
    except Exception:
        pass
    try:
        jb, pjb = stats.jarque_bera(xs)
        out["jarque_bera"] = float(jb); out["jarque_bera_p"] = float(pjb)
    except Exception:
        pass
    try:
        ad = stats.anderson(xs, dist="norm")
        out["anderson_stat"] = float(ad.statistic)
        out["anderson_crit_5pct"] = float(ad.critical_values[2])
        out["anderson_reject_normal_5pct"] = bool(ad.statistic > ad.critical_values[2])
    except Exception:
        pass
    return out


# ---------------------------------------------------------------------------
# 3. Tail-index estimation
# ---------------------------------------------------------------------------

def hill_estimator(x, k_frac=0.10):
    """
    Hill estimator of the tail index for the top k order statistics.
    Returns alpha (tail index; smaller = heavier) and xi = 1/alpha.
    Only meaningful for positive, heavy (Frechet) tails.
    """
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    xs = np.sort(x)
    n = xs.size
    k = max(10, int(k_frac * n))
    top = xs[-(k + 1):]
    top = top[top > 0]
    if top.size < 5:
        return {"hill_alpha": float("nan"), "hill_xi": float("nan"), "k": k}
    logs = np.log(top)
    hill_xi = float(np.mean(logs[1:] - logs[0]))    # = 1/alpha
    return {"hill_alpha": float(1.0 / hill_xi) if hill_xi > 0 else float("inf"),
            "hill_xi": hill_xi, "k": k}


def gpd_shape_mle(x, threshold_q=0.90):
    """
    Fit a GPD to exceedances above the threshold_q quantile; return shape xi,
    scale, threshold, and exceedance count. xi>0 heavy, xi=0 exponential, xi<0 bounded.
    """
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    u = float(np.quantile(x, threshold_q))
    exc = x[x > u] - u
    if exc.size < 20:
        return {"xi": float("nan"), "scale": float("nan"), "u": u,
                "n_exceed": int(exc.size)}
    xi, loc, scale = genpareto.fit(exc, floc=0)
    return {"xi": float(xi), "scale": float(scale), "u": u,
            "n_exceed": int(exc.size), "threshold_q": threshold_q}


# ---------------------------------------------------------------------------
# 4-5. Mean residual life & threshold stability (data for plots + slopes)
# ---------------------------------------------------------------------------

def mean_residual_life(x, n_thresh=40):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    lo, hi = np.percentile(x, [75, 99.5])
    us = np.linspace(lo, hi, n_thresh)
    mrl, ci = [], []
    for u in us:
        e = x[x > u] - u
        if e.size > 5:
            mrl.append(e.mean())
            ci.append(1.96 * e.std() / np.sqrt(e.size))
        else:
            mrl.append(np.nan); ci.append(np.nan)
    return us, np.array(mrl), np.array(ci)


def threshold_stability(x, n_thresh=30):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    lo, hi = np.percentile(x, [75, 99])
    us = np.linspace(lo, hi, n_thresh)
    xis, scales = [], []
    for u in us:
        e = x[x > u] - u
        if e.size > 20:
            xi, _, sc = genpareto.fit(e, floc=0)
            xis.append(xi)
            scales.append(sc - xi * u)      # modified scale (should be constant)
        else:
            xis.append(np.nan); scales.append(np.nan)
    return us, np.array(xis), np.array(scales)


# ---------------------------------------------------------------------------
# 6. GPD goodness-of-fit
# ---------------------------------------------------------------------------

def gpd_goodness_of_fit(x, threshold_q=0.90):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    u = float(np.quantile(x, threshold_q))
    exc = np.sort(x[x > u] - u)
    if exc.size < 20:
        return {"ks_stat": float("nan"), "ks_p": float("nan"),
                "qq_corr": float("nan"), "n_exceed": int(exc.size)}
    xi, loc, scale = genpareto.fit(exc, floc=0)
    # KS test of exceedances against the fitted GPD
    ks, pks = stats.kstest(exc, "genpareto", args=(xi, 0, scale))
    # QQ correlation (empirical vs theoretical quantiles)
    probs = (np.arange(1, exc.size + 1) - 0.5) / exc.size
    theo = genpareto.ppf(probs, xi, 0, scale)
    qq_corr = float(np.corrcoef(exc, theo)[0, 1])
    return {"xi": float(xi), "scale": float(scale), "u": u,
            "ks_stat": float(ks), "ks_p": float(pks),
            "qq_corr": qq_corr, "n_exceed": int(exc.size)}


# ---------------------------------------------------------------------------
# 7. Return levels with CI (delta method via profile of the fit)
# ---------------------------------------------------------------------------

def return_levels(x, threshold_q=0.90, periods=(2, 5, 10, 50, 100, 500)):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    u = float(np.quantile(x, threshold_q))
    exc = x[x > u] - u
    if exc.size < 20:
        return {T: float("nan") for T in periods}
    xi, _, scale = genpareto.fit(exc, floc=0)
    zeta = exc.size / x.size
    out = {}
    for T in periods:
        m = T
        if abs(xi) < 1e-6:
            rl = u + scale * np.log(m * zeta)
        else:
            rl = u + (scale / xi) * ((m * zeta) ** xi - 1)
        out[T] = float(rl)
    return out


# ---------------------------------------------------------------------------
# Orchestration + figure
# ---------------------------------------------------------------------------

def run_tail_diagnostics(x, name="field", threshold_q=0.90,
                         out_png="tail_diagnostics.png", verbose=True):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    summary = {"name": name}
    summary["descriptive"] = descriptive_tail(x)
    summary["normality"] = normality_tests(x)
    summary["hill"] = hill_estimator(x)
    summary["gpd_shape"] = gpd_shape_mle(x, threshold_q)
    summary["gof"] = gpd_goodness_of_fit(x, threshold_q)
    summary["return_levels"] = return_levels(x, threshold_q)

    # ---- verdict logic ----
    xi = summary["gpd_shape"]["xi"]
    kurt = summary["descriptive"]["excess_kurtosis"]
    reject_normal = summary["normality"].get("anderson_reject_normal_5pct", None)
    qq = summary["gof"]["qq_corr"]
    verdict = []
    if np.isfinite(xi):
        if xi > 0.05:
            verdict.append(f"HEAVY-tailed: GPD shape xi = {xi:.3f} > 0 (Frechet domain).")
        elif xi < -0.05:
            verdict.append(f"BOUNDED tail: xi = {xi:.3f} < 0 (finite upper limit).")
        else:
            verdict.append(f"~EXPONENTIAL tail: xi = {xi:.3f} ~ 0 (light tail).")
    if kurt > 1:
        verdict.append(f"Excess kurtosis {kurt:.2f} > 0 (heavier-than-normal peak/tails).")
    if reject_normal:
        verdict.append("Normality REJECTED at 5% (Anderson-Darling).")
    if np.isfinite(qq):
        verdict.append(f"GPD QQ correlation {qq:.4f} "
                       f"({'good' if qq > 0.98 else 'check'} tail fit).")
    summary["verdict"] = verdict

    # ---- figure ----
    fig, ax = plt.subplots(2, 3, figsize=(15, 9))

    # (a) histogram + log-y
    ax[0, 0].hist(x, bins=60, color="steelblue", edgecolor="none")
    ax[0, 0].set_yscale("log")
    ax[0, 0].set_title(f"{name}: histogram (log y)")
    ax[0, 0].set_xlabel("value"); ax[0, 0].set_ylabel("count")

    # (b) empirical survival on log-log (heavy tail => straight line)
    xs = np.sort(x); surv = 1.0 - np.arange(1, xs.size + 1) / xs.size
    pos = xs > 0
    ax[0, 1].loglog(xs[pos], surv[pos], ".", ms=2, color="darkorange")
    ax[0, 1].set_title("survival function (log-log)")
    ax[0, 1].set_xlabel("value"); ax[0, 1].set_ylabel("P(X > x)")

    # (c) Normal QQ plot (departure at top => heavy right tail)
    stats.probplot(x, dist="norm", plot=ax[0, 2])
    ax[0, 2].set_title("Normal QQ (curved top = heavy tail)")

    # (d) mean residual life
    us, mrl, ci = mean_residual_life(x)
    ax[1, 0].plot(us, mrl, "-", color="seagreen")
    ax[1, 0].fill_between(us, mrl - ci, mrl + ci, alpha=0.2, color="seagreen")
    ax[1, 0].axvline(summary["gpd_shape"]["u"], ls="--", color="red",
                     label=f"u (q{int(threshold_q*100)})")
    ax[1, 0].set_title("mean residual life (linear above valid u)")
    ax[1, 0].set_xlabel("threshold u"); ax[1, 0].set_ylabel("mean excess")
    ax[1, 0].legend(fontsize=8)

    # (e) threshold stability of xi
    us2, xis, scales = threshold_stability(x)
    ax[1, 1].plot(us2, xis, "-o", ms=3, color="purple")
    ax[1, 1].axhline(0, ls=":", color="gray")
    ax[1, 1].axvline(summary["gpd_shape"]["u"], ls="--", color="red")
    ax[1, 1].set_title("threshold stability: shape xi (flat above u)")
    ax[1, 1].set_xlabel("threshold u"); ax[1, 1].set_ylabel("xi")

    # (f) GPD QQ of exceedances
    u = summary["gpd_shape"]["u"]
    exc = np.sort(x[x > u] - u)
    if exc.size >= 20:
        xi_f, _, sc_f = genpareto.fit(exc, floc=0)
        probs = (np.arange(1, exc.size + 1) - 0.5) / exc.size
        theo = genpareto.ppf(probs, xi_f, 0, sc_f)
        ax[1, 2].plot(theo, exc, ".", ms=3, color="crimson")
        lim = [0, max(exc.max(), theo.max())]
        ax[1, 2].plot(lim, lim, "k--", lw=1)
        ax[1, 2].set_title(f"GPD QQ of exceedances (corr={summary['gof']['qq_corr']:.3f})")
        ax[1, 2].set_xlabel("theoretical"); ax[1, 2].set_ylabel("empirical")

    fig.suptitle(f"Tail diagnostics: {name}", fontsize=14, y=1.00)
    fig.tight_layout()
    fig.savefig(out_png, dpi=130, bbox_inches="tight")
    plt.close(fig)
    summary["figure"] = out_png

    if verbose:
        _print_summary(summary)
    return summary


def _print_summary(s):
    d = s["descriptive"]
    print("=" * 68)
    print(f"TAIL DIAGNOSTICS: {s['name']}   (n = {d['n']})")
    print("=" * 68)
    print(f"skewness {d['skewness']:.3f} | excess kurtosis {d['excess_kurtosis']:.3f} "
          f"| tail ratio(99.9/50) {d['tail_ratio_99.9_vs_50']:.2f}")
    n = s["normality"]
    if "anderson_stat" in n:
        print(f"Anderson-Darling {n['anderson_stat']:.2f} "
              f"(crit@5% {n['anderson_crit_5pct']:.2f}) -> "
              f"normal {'REJECTED' if n['anderson_reject_normal_5pct'] else 'not rejected'}")
    h = s["hill"]; g = s["gpd_shape"]
    print(f"Hill xi {h['hill_xi']:.3f} (alpha {h['hill_alpha']:.2f}, k={h['k']})")
    print(f"GPD MLE xi {g['xi']:.3f}, scale {g['scale']:.3f}, "
          f"u=q{int(g.get('threshold_q',0.9)*100)}={g['u']:.3f}, exceed {g['n_exceed']}")
    gof = s["gof"]
    print(f"GPD fit: QQ corr {gof['qq_corr']:.4f}, KS stat {gof['ks_stat']:.3f} "
          f"(p {gof['ks_p']:.3f})")
    print("Return levels:", {k: round(v, 2) for k, v in s["return_levels"].items()})
    print("-" * 68)
    print("VERDICT:")
    for v in s["verdict"]:
        print("  * " + v)
    print(f"Figure saved -> {s['figure']}")


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    rng = np.random.default_rng(0)

    print("\n### DEMO 1: KNOWN HEAVY tail (GPD xi=0.3) -- should detect heavy\n")
    heavy = genpareto.rvs(0.3, scale=2, size=8000, random_state=1) + 25
    run_tail_diagnostics(heavy, name="synthetic-heavy", out_png="tail_heavy.png")

    print("\n### DEMO 2: KNOWN LIGHT tail (Normal) -- should detect light/exponential\n")
    light = rng.normal(30, 4, size=8000)
    run_tail_diagnostics(light, name="synthetic-normal", out_png="tail_light.png")

    print("\nInterpretation guide:")
    print("  xi > 0  -> heavy tail: GPD/EQRN/EVT machinery IS justified.")
    print("  xi ~ 0  -> exponential: EVT still applies but tail is light.")
    print("  xi < 0  -> bounded: extreme extrapolation less critical.")
    print("  On REAL ECOSTRESS data these tests decide whether the heavy-tail")
    print("  assumption behind the whole method actually holds.")
