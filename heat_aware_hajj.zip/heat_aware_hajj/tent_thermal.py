"""
Does the Mina tent city show a thermal signature at all?

THE QUESTION BEHIND THIS. Our routing negative result rests on surface
temperature showing no exploitable variation between alternative paths. One
hypothesis for why is that the real source of thermal contrast at Mina is shade
from the seasonal tent city, which no building dataset contains and which 70 m
LST may not resolve. Before building a surface model and a shade simulation to
chase that hypothesis, it is worth asking the cheaper observational question:
is the tented area measurably different from adjacent open ground in the data
we already have?

METHOD. Mina's tents are erected for the pilgrimage and removed afterwards, so
the same ground is tented during Hajj and bare outside it. That gives a natural
contrast with two independent axes:

  SPATIAL   tented area against nearby open ground, same scene, same hour
  TEMPORAL  the same polygon during the Hajj window against the same polygon
            outside it, matched for day of year and local solar time

The temporal comparison is the stronger of the two, because it controls for
terrain, elevation and surface material: only the tents change.

WHAT A NULL RESULT WOULD MEAN. If tented ground is no cooler than open ground,
the shade hypothesis weakens and there is no case for investing in a surface
model. If it is several degrees cooler, there is observational grounds to
pursue the geometry.

AN IMPORTANT ASYMMETRY. LST measures the TENT ROOF, not the pilgrim beneath it.
Tent fabric is light, reflective and has little thermal mass, so its surface may
sit near air temperature while the ground underneath is deeply shaded. A small
LST difference therefore does NOT establish that tents fail to provide thermal
relief; it establishes that the satellite cannot see the relief. That is the
same surface-versus-experienced-conditions problem the paper already identifies,
in a sharper form, and it is the honest reading of a weak signal here.

Run:
    python tent_thermal.py
    python tent_thermal.py --mina-radius 600 --open-radius 1500
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import glob
import json
import re
import warnings
from datetime import date, datetime

warnings.filterwarnings("ignore")

import numpy as np

# Gregorian equivalents of 8-13 Dhul-Hijjah. VERIFY before publication: the
# civil start of the month is set by observation and can shift by a day.
HAJJ = {2019: (date(2019, 8, 9), date(2019, 8, 14)),
        2020: (date(2020, 7, 28), date(2020, 8, 2)),
        2021: (date(2021, 7, 17), date(2021, 7, 22)),
        2022: (date(2022, 7, 7), date(2022, 7, 12)),
        2023: (date(2023, 6, 26), date(2023, 7, 1)),
        2024: (date(2024, 6, 14), date(2024, 6, 19))}

MINA = (21.4133, 39.8933)
TS = re.compile(r"(\d{8})T(\d{6})")
UTC_OFFSET_H = 3.0


def parse(name):
    m = TS.search(name)
    if not m:
        return None, None
    d = datetime.strptime(m.group(1), "%Y%m%d").date()
    utc = int(m.group(2)[:2]) + int(m.group(2)[2:4]) / 60.0
    return d, (utc + UTC_OFFSET_H) % 24.0


def in_hajj(d, pad=0):
    for y, (a, b) in HAJJ.items():
        if d.year == y:
            from datetime import timedelta
            if a - timedelta(days=pad) <= d <= b + timedelta(days=pad):
                return True
    return False


def disc_mask(shape, bbox, centre, r_inner_m, r_outer_m=None):
    """Pixels within r_inner of a point, or in an annulus if r_outer given."""
    H, W = shape
    west, south, east, north = bbox
    lat = np.linspace(north, south, H)[:, None]
    lon = np.linspace(west, east, W)[None, :]
    dy = (lat - centre[0]) * 111_320.0
    dx = (lon - centre[1]) * 111_320.0 * np.cos(np.radians(centre[0]))
    d = np.sqrt(dx ** 2 + dy ** 2)
    if r_outer_m is None:
        return d <= r_inner_m
    return (d > r_inner_m) & (d <= r_outer_m)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", default="data/pairs")
    ap.add_argument("--bbox")
    ap.add_argument("--mina-radius", type=float, default=800.0,
                    help="radius of the tented area, m")
    ap.add_argument("--open-radius", type=float, default=2000.0,
                    help="outer radius of the comparison annulus, m")
    ap.add_argument("--hour-lo", type=float, default=10.0)
    ap.add_argument("--hour-hi", type=float, default=16.0)
    ap.add_argument("--pad-days", type=int, default=3,
                    help="days either side of the ritual window to count as Hajj")
    args = ap.parse_args()

    import xarray as xr
    import config
    bbox = (tuple(float(x) for x in args.bbox.split(","))
            if args.bbox else config.BBOX)

    files = sorted(glob.glob(os.path.join(args.pairs, "*_pair.nc")))
    print("=" * 74)
    print("DOES THE MINA TENT CITY SHOW A THERMAL SIGNATURE?")
    print("=" * 74)
    print(f"  scenes available : {len(files)}")
    print(f"  tented disc      : {args.mina_radius:.0f} m around "
          f"{MINA[0]:.4f} N, {MINA[1]:.4f} E")
    print(f"  comparison ring  : {args.mina_radius:.0f}-{args.open_radius:.0f} m")
    print(f"  daytime window   : {args.hour_lo:.0f}-{args.hour_hi:.0f} h local")

    rows = []
    m_in = m_out = None
    for f in files:
        d, h = parse(os.path.basename(f))
        if d is None or not (args.hour_lo <= h <= args.hour_hi):
            continue
        with xr.open_dataset(f) as ds:
            if "lst_fine" not in ds:
                continue
            a = ds["lst_fine"].values.astype("float32")
        if m_in is None or m_in.shape != a.shape:
            m_in = disc_mask(a.shape, bbox, MINA, args.mina_radius)
            m_out = disc_mask(a.shape, bbox, MINA,
                              args.mina_radius, args.open_radius)
        vi = a[m_in & np.isfinite(a)]
        vo = a[m_out & np.isfinite(a)]
        if vi.size < 20 or vo.size < 20:
            continue
        rows.append({"date": d, "hour": h, "hajj": in_hajj(d, args.pad_days),
                     "tent_mean": float(vi.mean()), "open_mean": float(vo.mean()),
                     "diff": float(vi.mean() - vo.mean()),
                     "n_in": int(vi.size), "n_out": int(vo.size)})

    if not rows:
        print("\n  No usable scenes in the daytime window. Widen --hour-lo/-hi")
        print("  or check that the pairs directory is populated.")
        return

    print(f"\n  usable daytime scenes: {len(rows)}")
    print(f"  pixels: tented {rows[0]['n_in']}, open {rows[0]['n_out']}")
    if rows[0]["n_in"] < 50:
        print("  [warn] few tented pixels at 70 m; the tent area is small")
        print("  relative to the resolution, so the contrast is diluted.")

    hajj = [r for r in rows if r["hajj"]]
    other = [r for r in rows if not r["hajj"]]

    print("\n1. SPATIAL CONTRAST (tented disc minus surrounding ring)")
    for lbl, sub in (("during Hajj", hajj), ("outside Hajj", other),
                     ("all scenes", rows)):
        if not sub:
            print(f"   {lbl:<14} no scenes")
            continue
        d_ = np.array([r["diff"] for r in sub])
        print(f"   {lbl:<14} n={len(sub):>3}  mean {d_.mean():+6.2f} C  "
              f"sd {d_.std():5.2f}  range {d_.min():+6.2f} .. {d_.max():+6.2f}")

    print("\n2. TEMPORAL CONTRAST (the decisive test)")
    print("   Same ground, tented during Hajj and bare outside it. This")
    print("   controls for terrain and surface material: only tents change.")
    if hajj and other:
        a_ = np.array([r["tent_mean"] for r in hajj])
        b_ = np.array([r["tent_mean"] for r in other])
        # control for season and hour by differencing against the open ring
        da = np.array([r["diff"] for r in hajj])
        db = np.array([r["diff"] for r in other])
        print(f"   tented disc LST : Hajj {a_.mean():.2f} C (n={a_.size}), "
              f"other {b_.mean():.2f} C (n={b_.size})")
        print(f"   difference-in-differences: "
              f"{da.mean() - db.mean():+.2f} C")
        try:
            from scipy import stats
            t = stats.mannwhitneyu(da, db, alternative="two-sided")
            print(f"   Mann-Whitney on the contrast: p = {t.pvalue:.3f}")
            sig = t.pvalue < 0.05
        except Exception:
            sig = None
        eff = da.mean() - db.mean()
        print()
        if abs(eff) < 0.5 or sig is False:
            print("   -> NO detectable tent signature. Two readings, and they")
            print("      differ in consequence:")
            print("      (a) tents provide little surface-thermal contrast, so")
            print("          the shade hypothesis weakens and a surface model")
            print("          is not worth building; or")
            print("      (b) LST sees the TENT ROOF, which is light, reflective")
            print("          and low in thermal mass, while the shaded ground")
            print("          beneath is invisible to the sensor.")
            print("      (b) cannot be ruled out from this data, and is the more")
            print("      likely explanation if the tented area is cooler by an")
            print("      amount far smaller than a shaded surface would be.")
        else:
            print(f"   -> A tent signature of {eff:+.2f} C is detectable. There is")
            print("      observational grounds for pursuing shade geometry, and")
            print("      the magnitude bounds what a surface model should")
            print("      reproduce.")
    else:
        print(f"   insufficient scenes: {len(hajj)} during Hajj, "
              f"{len(other)} outside")
        print("   The ritual days occupy ~24% of a May-September window at best,")
        print("   so this comparison is sampling-limited rather than signal-")
        print("   limited. Report the shortfall rather than the point estimate.")

    json.dump([{**r, "date": str(r["date"])} for r in rows],
              open("tent_thermal.json", "w"), indent=2)
    print("\n  results -> tent_thermal.json")
    print("\n  NEXT IF POSITIVE: map the tent extent per season from Sentinel-2")
    print("  (10 m, 5-day revisit, open) and use it as a land-cover class,")
    print("  rather than inferring geometry from building datasets that do not")
    print("  contain seasonal structures.")


if __name__ == "__main__":
    main()
