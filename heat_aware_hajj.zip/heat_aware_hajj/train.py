"""
Train AMUN on the aligned heat pairs.

Tuned for a single 32 GB GPU with 64 GB system RAM.

    python train.py                       # defaults below
    python train.py --tile 384 --batch 12
    python train.py --amp bf16            # if the GPU supports bfloat16

Memory guide (base=48, depth=4, mixed precision):
    tile 256, batch 16  ~  11 GB
    tile 512, batch  8  ~  20 GB
    tile 512, batch 12  ~  29 GB   <- close to the limit, reduce if it OOMs
Start conservative and raise the batch until you see ~85% utilisation.
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

import config
from dataset import HeatPairDataset, split_files, save_stats, load_stats, PREDICTORS
from model import AMUN, masked_l1, gaussian_nll, gradient_loss

CKPT = config.ROOT / "checkpoints"
CKPT.mkdir(exist_ok=True)


def build_loaders(args, stats):
    tr, va, _ = split_files()
    print(f"train {len(tr)} | val {len(va)} scenes")
    if getattr(config, "QUICK", False):
        print("  [CASE-STUDY MODE] Training on a reduced slice. Results are")
        print("  PRELIMINARY -- report as a proof-of-concept, not the full study.")
    n_scenes = len(tr) + len(va)
    if n_scenes < 20:
        print(f"  [WARNING] Only {n_scenes} scenes total. This is enough to")
        print("  DEMONSTRATE the pipeline but too few for robust metrics. Use")
        print("  more augmentation, fewer epochs, and strong regularisation;")
        print("  treat all numbers as illustrative until the full download.")
    common = dict(tile=args.tile, stats=stats)
    dtr = HeatPairDataset(tr, augment=True, samples_per_file=args.reps, **common)
    dva = HeatPairDataset(va, augment=False, samples_per_file=2, **common)
    ltr = DataLoader(dtr, batch_size=args.batch, shuffle=True,
                     num_workers=args.workers, pin_memory=True,
                     drop_last=True, persistent_workers=args.workers > 0)
    lva = DataLoader(dva, batch_size=args.batch, shuffle=False,
                     num_workers=max(1, args.workers // 2), pin_memory=True)
    return ltr, lva


def run_epoch(net, loader, opt, scaler, device, dtype, train: bool, args):
    net.train(train)
    tot, n = 0.0, 0
    ctx = torch.enable_grad() if train else torch.no_grad()
    with ctx:
        for x, base, y, mask in loader:
            x = x.to(device, non_blocking=True)
            base = base.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)
            mask = mask.to(device, non_blocking=True)

            with torch.autocast(device_type=device.type, dtype=dtype,
                                enabled=dtype is not None):
                mu, log_sigma = net(x, baseline=base)
                loss = gaussian_nll(mu, log_sigma, y, mask) \
                    if net.heteroscedastic else masked_l1(mu, y, mask)
                loss = loss + args.grad_weight * gradient_loss(mu, y, mask)

            if train:
                opt.zero_grad(set_to_none=True)
                if scaler is not None:
                    scaler.scale(loss).backward()
                    scaler.unscale_(opt)
                    torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
                    scaler.step(opt)
                    scaler.update()
                else:
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
                    opt.step()

            tot += float(loss.detach()) * x.size(0)
            n += x.size(0)
    return tot / max(n, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tile", type=int, default=512)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--epochs", type=int, default=120)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--wd", type=float, default=1e-2)
    ap.add_argument("--base", type=int, default=48)
    ap.add_argument("--depth", type=int, default=4)
    ap.add_argument("--reps", type=int, default=4, help="crops per scene/epoch")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--grad-weight", type=float, default=0.1)
    ap.add_argument("--amp", choices=["fp16", "bf16", "off"], default="fp16")
    ap.add_argument("--resume", default=None,
                    help="warm-start from a checkpoint, e.g. checkpoints/amun_best.pt")
    ap.add_argument("--finetune-lr", type=float, default=None,
                    help="constant LR for the resumed run (skips OneCycle). "
                         "Use ~1/10 of --lr when finishing off a run.")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device: {device}")
    if device.type == "cuda":
        print(f"GPU: {torch.cuda.get_device_name(0)} "
              f"({torch.cuda.get_device_properties(0).total_memory/2**30:.0f} GB)")
        torch.backends.cudnn.benchmark = True

    dtype = {"fp16": torch.float16, "bf16": torch.bfloat16,
             "off": None}[args.amp]
    scaler = torch.amp.GradScaler(device.type) if args.amp == "fp16" else None

    stats_path = CKPT / "norm_stats.json"
    if stats_path.exists():
        stats = load_stats(stats_path)
    else:
        print("computing normalisation statistics ...")
        tr, _, _ = split_files()
        stats = HeatPairDataset.compute_stats(tr)
        save_stats(stats, stats_path)
    print(f"normalised variables: {len(stats)}")

    ltr, lva = build_loaders(args, stats)

    net = AMUN(in_ch=len(PREDICTORS), base=args.base, depth=args.depth).to(device)
    net = net.to(memory_format=torch.channels_last)
    print(f"parameters: {sum(p.numel() for p in net.parameters())/1e6:.2f} M")

    best = np.inf
    if args.resume:
        ck = torch.load(args.resume, map_location=device)
        net.load_state_dict(ck["model"])
        best = float(ck.get("val", np.inf))
        print(f"resumed weights from {args.resume} (recorded val {best:.4f})")
        print("  NOTE: optimizer and scheduler state are NOT in the checkpoint,")
        print("  so this is a WARM START, not an exact continuation. Use")
        print("  --finetune-lr to run at a flat low LR instead of restarting")
        print("  the OneCycle schedule from its warm-up phase.")

    lr0 = args.finetune_lr if args.finetune_lr else args.lr
    opt = torch.optim.AdamW(net.parameters(), lr=lr0, weight_decay=args.wd)
    if args.finetune_lr:
        # flat LR: restarting OneCycle would push the LR back up through warm-up
        # and undo the convergence already achieved.
        sched = torch.optim.lr_scheduler.ConstantLR(opt, factor=1.0, total_iters=1)
        print(f"fine-tune mode: constant LR {lr0:g} (OneCycle disabled)")
    else:
        sched = torch.optim.lr_scheduler.OneCycleLR(
            opt, max_lr=args.lr, total_steps=args.epochs * max(1, len(ltr)),
            pct_start=0.1)
    for ep in range(1, args.epochs + 1):
        t0 = time.time()
        tr_loss = run_epoch(net, ltr, opt, scaler, device, dtype, True, args)
        va_loss = run_epoch(net, lva, opt, scaler, device, dtype, False, args)
        try:
            sched.step()
        except Exception:
            pass

        mem = (torch.cuda.max_memory_allocated() / 2**30
               if device.type == "cuda" else 0.0)
        print(f"epoch {ep:3d}/{args.epochs} | train {tr_loss:.4f} | "
              f"val {va_loss:.4f} | {time.time()-t0:5.1f}s | {mem:4.1f} GB")

        if va_loss < best:
            best = va_loss
            torch.save({"model": net.state_dict(), "args": vars(args),
                        "stats": stats, "val": va_loss}, CKPT / "amun_best.pt")
            print(f"           saved (val {va_loss:.4f})")

    print(f"\nbest val loss {best:.4f} -> {CKPT/'amun_best.pt'}")


if __name__ == "__main__":
    main()
