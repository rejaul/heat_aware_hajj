"""
Train the CENSORED EQRN (GPD-tail head with augmented censoring channel) on the
real 2024 case-study data.

This is the runnable entry point for Option 2. It:
  1. loads the real aligned pairs from align.py (data/pairs/*.nc),
  2. builds a covariate-anchored censoring indicator from the coarse baseline
     field (the WBGT channel), marking tail cells,
  3. trains CensoredEQRN with the censored GPD NLL (tail cells only),
  4. evaluates on held-out scenes with the tail diagnostics,
  5. prints an honest small-data report.

Because 2024 alone yields few scenes, this is a PRELIMINARY, case-study run:
few epochs, strong regularisation, and explicit small-n warnings. Treat numbers
as illustrative; the value of the censoring channel here is methodological.

Usage
-----
    python train_censored_eqrn.py                 # default small-data settings
    python train_censored_eqrn.py --epochs 40 --tile 128
    python train_censored_eqrn.py --tau 0.90      # threshold quantile for censoring
"""
from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

warnings.filterwarnings("ignore")

import config
from dataset import HeatPairDataset, split_files, PREDICTORS
from eqrn_censored import CensoredEQRN, censored_gpd_nll


def make_censoring(base, tau_field, margin=0.0):
    """
    Build the censoring indicator and threshold from the coarse baseline field.

    base      : (B,1,H,W) standardized coarse field (WBGT), the covariate anchor.
    tau_field : per-batch scalar threshold (a high quantile of `base`), so the
                threshold FOLLOWS the covariate signal (the anchoring lesson).
    Returns (threshold u(x), indicator I where base>threshold).
    """
    thr = tau_field + margin
    indicator = (base > thr).float()
    return thr, indicator


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--tile", type=int, default=128)
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--tau", type=float, default=0.90,
                    help="quantile of the coarse field used as censoring threshold")
    ap.add_argument("--zeta", type=float, default=0.10,
                    help="exceedance rate P(Y>u) for quantile recovery")
    args = ap.parse_args()

    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device: {dev}")
    if getattr(config, "QUICK", False):
        print("[CASE-STUDY MODE] 2024 slice -- results are PRELIMINARY.")

    # ---- data ----
    tr, va, _ = split_files()
    n = len(tr) + len(va)
    print(f"train {len(tr)} | val {len(va)} scenes")
    if n == 0:
        raise SystemExit("No pairs found. Run align.py first (data/pairs/*.nc).")
    if n < 20:
        print(f"[WARNING] only {n} scenes -- small-data regime. Using strong")
        print("  regularisation and few epochs; treat metrics as illustrative.")

    stats = HeatPairDataset.compute_stats(tr)
    ds_tr = HeatPairDataset(tr, tile=args.tile, stats=stats, augment=True,
                            samples_per_file=8)
    ds_va = HeatPairDataset(va, tile=args.tile, stats=stats, augment=False,
                            samples_per_file=4)
    dl_tr = DataLoader(ds_tr, batch_size=args.batch, shuffle=True, num_workers=0)
    dl_va = DataLoader(ds_va, batch_size=args.batch, shuffle=False, num_workers=0)

    # ---- model ----
    net = CensoredEQRN(in_ch=len(PREDICTORS)).to(dev)
    opt = torch.optim.Adam(net.parameters(), lr=args.lr, weight_decay=1e-3)
    print(f"CensoredEQRN: {sum(p.numel() for p in net.parameters())/1e6:.2f} M params, "
          f"{len(PREDICTORS)} covariates + 1 censoring channel")

    # ---- train ----
    for ep in range(1, args.epochs + 1):
        net.train(); tot = 0.0; nb = 0
        for x, base, y, mask in dl_tr:
            x, base, y, mask = x.to(dev), base.to(dev), y.to(dev), mask.to(dev)
            # per-batch threshold = tau-quantile of the coarse field
            u = torch.quantile(base.flatten(), args.tau)
            thr, indicator = make_censoring(base, u)
            # censored cells contribute to the tail likelihood only where BOTH
            # the target is valid AND the cell exceeds the threshold
            exc_mask = indicator * mask
            excess = (y - thr).clamp_min(0.0)

            log_sigma, xi = net(x, indicator)
            loss = censored_gpd_nll(log_sigma, xi, excess, exc_mask)

            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
            opt.step()
            tot += float(loss); nb += 1

        # ---- validation ----
        net.eval(); vtot = 0.0; vnb = 0
        with torch.no_grad():
            for x, base, y, mask in dl_va:
                x, base, y, mask = x.to(dev), base.to(dev), y.to(dev), mask.to(dev)
                u = torch.quantile(base.flatten(), args.tau)
                thr, indicator = make_censoring(base, u)
                exc_mask = indicator * mask
                excess = (y - thr).clamp_min(0.0)
                log_sigma, xi = net(x, indicator)
                vtot += float(censored_gpd_nll(log_sigma, xi, excess, exc_mask))
                vnb += 1
        if ep % 5 == 0 or ep == 1 or ep == args.epochs:
            print(f"epoch {ep:3d}/{args.epochs} | train NLL {tot/max(nb,1):.4f} "
                  f"| val NLL {vtot/max(vnb,1):.4f}")

    # ---- final evaluation with tail diagnostics ----
    print("\nFinal evaluation on held-out scenes:")
    from metrics import evaluate_extremes, evaluate_quantile_method
    TAUS = (0.5, 0.9, 0.95, 0.99)
    all_q, all_y = [], []
    net.eval()
    with torch.no_grad():
        for x, base, y, mask in dl_va:
            x, base, y, mask = x.to(dev), base.to(dev), y.to(dev), mask.to(dev)
            u = torch.quantile(base.flatten(), args.tau)
            thr, indicator = make_censoring(base, u)
            log_sigma, xi = net(x, indicator)
            cols = []
            tr_flat = base[mask.bool()].flatten().cpu().numpy()
            for tau in TAUS:
                if tau < (1 - args.zeta):
                    qv = float(np.quantile(tr_flat, tau)) if tr_flat.size else 0.0
                    q = torch.full_like(log_sigma, qv)
                else:
                    q = net.extreme_quantile(log_sigma, xi, thr, args.zeta, tau)
                cols.append(q)
            qs = torch.cat(cols, 1)
            qs, _ = torch.sort(qs, dim=1)
            m = mask.bool().squeeze(1)
            for b in range(qs.shape[0]):
                yb = y[b, 0][m[b]].cpu().numpy()
                qb = qs[b].permute(1, 2, 0)[m[b]].cpu().numpy()
                if yb.size > 50:
                    all_q.append(qb); all_y.append(yb)

    if all_q:
        Q = np.concatenate(all_q, 0); Y = np.concatenate(all_y, 0)
        thr_danger = float(np.quantile(Y, 0.95))
        gen = evaluate_quantile_method(Q, TAUS, Y, thr_danger)
        ext = evaluate_extremes(Q, TAUS, Y, periods=(10, 100))
        print(f"  n eval pixels: {Y.size}")
        print(f"  RMSE {gen['RMSE']:.3f} | peak_bias {gen['peak_bias']:.3f} "
              f"| exc_F1 {gen.get('exc_F1', float('nan')):.3f}")
        print(f"  RL10_err {ext['RL10_err']:.3f} | RL100_err {ext['RL100_err']:.3f} "
              f"| tail_corr {ext['tail_corr']:.3f} | tail_jaccard {ext['tail_jaccard']:.3f}")
        print("\n  Compare tail_corr/tail_jaccard against the non-censored EQRN")
        print("  (eqrn.py) to see whether the censoring channel places extremes")
        print("  more accurately. On a small near-light-tailed sample the")
        print("  difference may be within noise -- report it honestly.")
    else:
        print("  Not enough valid held-out pixels to evaluate; widen the window.")

    # ---- save ----
    out = Path("censored_eqrn_2024.pt")
    torch.save(net.state_dict(), out)
    print(f"\nsaved -> {out}")


if __name__ == "__main__":
    main()
