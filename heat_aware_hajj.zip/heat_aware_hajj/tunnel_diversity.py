"""
Do pedestrian tunnels create the route diversity that surface temperature cannot?

CONTEXT. Routing on an LST-derived exceedance field produced a clean negative
result: across three acquisitions and all six ritual legs, the twenty shortest
paths differ in mean exceedance by at most 0.0035, because the thermal gradient
runs ALONG the ritual axis rather than across it. All alternatives traverse the
same gradient, so route choice cannot reduce exposure.

Tunnels are a different kind of variable. A tunnel and the surface route above
it connect the same points through very different thermal environments, and that
difference is PERPENDICULAR to the corridor gradient -- exactly the structure the
negative result said was missing. The network contains 52 pedestrian tunnel edges
totalling 19.32 km (median 295 m), concentrated near Jamarat and the Haram.

TWO EFFECTS, OPPOSITE IN SIGN. A tunnel is cooler, but it is also a confined
space with no lateral escape, and the 1990 Al-Ma'aisim tunnel disaster killed
over 1,400 pilgrims in precisely such a structure. Treating a tunnel as simply
"cool and therefore preferable" would invert the lesson of this paper's own
capacity result: routing more pilgrims in raises density, pushing past rho*,
which REDUCES throughput, SLOWS walking, and -- because dose is exposure
integrated over time -- partly cancels the thermal benefit while adding crush
risk. We therefore model both effects and sweep the assumed thermal benefit
rather than asserting one.

Run
---
    python tunnel_diversity.py --risk field_prob.npy
    python tunnel_diversity.py --risk field_prob.npy --leg Mina Jamarat
    python tunnel_diversity.py --risk field_prob.npy --factors 0.9 0.7 0.5 0.3
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import networkx as nx

PED_TAGS = ("footway", "pedestrian", "steps", "path")

LEGS = [("Haram", "Mina"), ("Mina", "Arafat"), ("Arafat", "Muzdalifah"),
        ("Muzdalifah", "Mina"), ("Mina", "Jamarat"), ("Jamarat", "Haram")]


def is_ped_tunnel(d):
    if str(d.get("tunnel", "")).lower() != "yes":
        return False
    h = str(d.get("highway", ""))
    return any(p in h for p in PED_TAGS)


def build_simple(rg, G, factor, tunnel_width_cap=None):
    """
    Cheapest-parallel-edge DiGraph with tunnel edges marked, their exposure
    scaled by `factor`, and optionally their width capped.
    """
    S = nx.DiGraph()
    tun_edges, tun_len = 0, 0.0
    for u, v, d in G.edges(data=True):
        L = float(d.get("length", 0) or 0)
        E = float(d.get("E", np.nan))
        if not np.isfinite(E) or L <= 0:
            continue
        t = is_ped_tunnel(d)
        if t:
            E = E * factor
            tun_edges += 1
            tun_len += L
        if not S.has_edge(u, v) or L < S[u][v]["w"]:
            S.add_edge(u, v, w=L, E=E, tunnel=bool(t))
    return S, tun_edges, tun_len


def path_stats(S, p):
    L = sum(S[a][b]["w"] for a, b in zip(p[:-1], p[1:]))
    if L <= 0:
        return 0.0, 0.0, 0.0
    E = sum(S[a][b]["E"] * S[a][b]["w"] for a, b in zip(p[:-1], p[1:])) / L
    tl = sum(S[a][b]["w"] for a, b in zip(p[:-1], p[1:]) if S[a][b]["tunnel"])
    return L, E, tl


def leg_spread(S, src, dst, k=40):
    try:
        gen = nx.shortest_simple_paths(S, src, dst, weight="w")
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return None
    rows = []
    for i, p in enumerate(gen):
        rows.append(path_stats(S, p))
        if i + 1 >= k:
            break
    if len(rows) < 2:
        return None
    L = np.array([r[0] for r in rows]) / 1000.0
    E = np.array([r[1] for r in rows])
    T = np.array([r[2] for r in rows]) / 1000.0
    j = int(np.argmin(E))
    return {"n": len(rows),
            "len_km": (float(L.min()), float(L.max())),
            "exp": (float(E.min()), float(E.max())),
            "exp_spread": float(E.max() - E.min()),
            "best_cut_pct": float(100 * (E[0] - E[j]) / max(E[0], 1e-9)),
            "detour_pct": float(100 * (L[j] - L[0]) / max(L[0], 1e-9)),
            "tunnel_km_shortest": float(T[0]),
            "tunnel_km_coolest": float(T[j])}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", required=True)
    ap.add_argument("--bbox")
    ap.add_argument("--k", type=int, default=40)
    ap.add_argument("--factors", nargs="+", type=float,
                    default=[1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3])
    ap.add_argument("--min-spread", type=float, default=0.02)
    ap.add_argument("--leg", nargs=2, metavar=("FROM", "TO"), default=None)
    args = ap.parse_args()

    from corridor_network import fetch, snap_sites
    from routing_equilibrium import prepare_edges
    from routing_scalarized import RoutingGraph
    import config

    bbox = (tuple(float(x) for x in args.bbox.split(",")) if args.bbox
            else config.BBOX)
    G = fetch()
    prepare_edges(G, np.load(args.risk), bbox)
    rg = RoutingGraph(G)
    snapped = snap_sites(G)
    node = {k: v["node"] for k, v in snapped.items()}
    legs = [tuple(args.leg)] if args.leg else LEGS

    print("=" * 92)
    print("DO PEDESTRIAN TUNNELS CREATE EXPLOITABLE ROUTE DIVERSITY?")
    print("=" * 92)
    S0, ne, nl = build_simple(rg, G, 1.0)
    print(f"  network {S0.number_of_nodes():,} nodes, {S0.number_of_edges():,} edges")
    print(f"  pedestrian tunnel edges retained in the simple graph: {ne} "
          f"({nl/1000:.2f} km)")
    print(f"  thermal benefit is ASSUMED and swept: factors {args.factors}")
    print(f"  a leg is 'usable' if exposure spread exceeds {args.min_spread}")

    results = []
    for a, b in legs:
        if a not in node or b not in node:
            continue
        print(f"\n  {a} -> {b}")
        print(f"    {'factor':>7}{'exposure range':>22}{'spread':>10}"
              f"{'best cut':>10}{'detour':>9}{'tunnel km':>11}  usable")
        print("    " + "-" * 78)
        for fct in args.factors:
            S, _, _ = build_simple(rg, G, fct)
            r = leg_spread(S, node[a], node[b], args.k)
            if r is None:
                print(f"    {fct:>7.2f}   no path")
                continue
            ok = r["exp_spread"] > args.min_spread
            r.update({"leg": f"{a}->{b}", "factor": fct, "usable": bool(ok)})
            results.append(r)
            print(f"    {fct:>7.2f}{r['exp'][0]:>11.4f}-{r['exp'][1]:<10.4f}"
                  f"{r['exp_spread']:>10.4f}{r['best_cut_pct']:>9.2f}%"
                  f"{r['detour_pct']:>8.2f}%{r['tunnel_km_coolest']:>11.2f}"
                  f"  {'YES' if ok else 'no'}")

    print("\n" + "=" * 92)
    print("READING THIS")
    print("=" * 92)
    usable = [r for r in results if r["usable"]]
    if usable:
        best = min(r["factor"] for r in usable)
        print(f"  Diversity appears once the assumed tunnel benefit reaches "
              f"{best:.2f}x ambient.")
        print("  Report the THRESHOLD, not a single factor: the finding is that")
        print("  route choice becomes exploitable only if tunnels are at least")
        print(f"  this much cooler, which is an empirical question about the")
        print("  ventilation and cooling of specific structures.")
        for r in sorted(usable, key=lambda x: -x["exp_spread"])[:5]:
            print(f"    {r['leg']:<20} factor {r['factor']:.2f}  "
                  f"spread {r['exp_spread']:.4f}  cut {r['best_cut_pct']:.1f}% "
                  f"for {r['detour_pct']:.1f}% detour, "
                  f"{r['tunnel_km_coolest']:.2f} km in tunnel")
        print("\n  CRUSH CAVEAT. Any route that gains thermally by entering a")
        print("  tunnel concentrates pilgrims in a confined space with no")
        print("  lateral escape. The 1990 Al-Ma'aisim tunnel disaster killed")
        print("  over 1,400 pilgrims in such a structure. Before presenting a")
        print("  tunnel route as an improvement, re-run the capacity-constrained")
        print("  assignment with a TIGHTER density cap on tunnel edges: the")
        print("  thermal gain is partly self-cancelling, since higher density")
        print("  slows walking and dose is exposure integrated over time.")
    else:
        print("  No leg becomes usable at any assumed benefit down to "
              f"{min(args.factors):.2f}x ambient.")
        print("  Tunnels do not create exploitable diversity here either: they")
        print("  are concentrated near Jamarat and the Haram and do not offer")
        print("  parallel alternatives between the ritual sites. The negative")
        print("  result stands and is now stronger, having survived a second,")
        print("  physically independent candidate variable.")

    json.dump(results, open("tunnel_diversity.json", "w"), indent=2)
    print("\n  results -> tunnel_diversity.json")


if __name__ == "__main__":
    main()
