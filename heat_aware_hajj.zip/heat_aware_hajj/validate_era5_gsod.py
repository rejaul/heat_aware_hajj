"""
Validate the ERA5-derived 2 m temperature predictor against station observations.

WHY. Zittis et al. (npj Natural Hazards 2, 107, 2025) report that ERA5-Land
substantially UNDERESTIMATES daily maximum temperature at Mecca during the 2024
Hajj period, despite its high resolution. ERA5-Land supplies eleven of our
eleven coarse predictors, so a cold bias in the reanalysis propagates into the
downscaler, the derived heat indices and every routing cost built on them. This
script tests whether our extracted t2m reproduces that bias.

WHAT IS AND IS NOT COMPARABLE.
  comparable      : ERA5 t2m (2 m AIR temperature) vs GSOD station air temperature
  NOT comparable  : ECOSTRESS LST (radiometric SURFACE temperature) vs either.
                    Over dry paved ground at midday LST runs 10-20 C above air
                    temperature; treating the difference as model error would be
                    a category mistake. The surface-to-air offset is itself worth
                    reporting, but as an offset, not a validation.

DATA. GSOD for the Mecca station (WMO 41030, 21.43 N, 39.77 E, 240 m) is free
from NOAA NCEI. The same station underpins the bias correction in both Zittis et
al. and Kang et al. (GRL 46, 10094, 2019), so a comparison against it places our
input stack on the same footing as the published projection literature.

    https://www.ncei.noaa.gov/data/global-summary-of-the-day/access/<YEAR>/41030099999.csv

Download the years you need into gsod/ and run:

    python validate_era5_gsod.py --gsod gsod
    python validate_era5_gsod.py --gsod gsod --hajj-only
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import glob
import json
import warnings
from datetime import date, datetime

warnings.filterwarnings("ignore")

import numpy as np

HAJJ = {2019: (date(2019, 8, 9), date(2019, 8, 14)),
        2020: (date(2020, 7, 28), date(2020, 8, 2)),
        2021: (date(2021, 7, 17), date(2021, 7, 22)),
        2022: (date(2022, 7, 7), date(2022, 7, 12)),
        2023: (date(2023, 6, 26), date(2023, 7, 1)),
        2024: (date(2024, 6, 14), date(2024, 6, 19))}

STATION = (21.43, 39.77)          # Mecca, WMO 41030


NCEI_API = "https://www.ncei.noaa.gov/access/services/data/v1"


def fetch_ncei(station="SAM00041030", dataset="daily-summaries",
               start="1983-01-01", end="2024-12-31", out="station.csv"):
    """
    Pull station data from the NCEI Access Data Service.

    The bulk directory paths under /data/global-summary-of-the-day/access/ are
    unreliable since GSOD was retired (2025-08-29) and NCEI began migrating to
    the cloud. The Access Data Service is the supported route:

        /access/services/data/v1?dataset=...&stations=...&startDate=...
                                 &endDate=...&dataTypes=...&format=csv

    dataset  "daily-summaries"          GHCN-Daily  -> TMAX in tenths of degC
             "global-summary-of-the-day" GSOD       -> MAX in Fahrenheit
    station  GHCN-Daily uses SAM00041030 for Mecca; GSOD uses 41030099999.

    Dates are plain ISO-8601 (YYYY-MM-DD). The service also accepts combined
    date-time with a UTC offset, in which case the plus sign must be encoded as
    %2B or the request fails validation; we avoid that by not using offsets.
    urlencode() handles the rest of the escaping.
    """
    import urllib.parse, urllib.request
    dtypes = "TMAX,TMIN" if dataset == "daily-summaries" else "MAX,MIN,TEMP"
    q = urllib.parse.urlencode({"dataset": dataset, "stations": station,
                                "startDate": start, "endDate": end,
                                "dataTypes": dtypes, "format": "csv",
                                "includeStationName": "true"})
    url = f"{NCEI_API}?{q}"
    print(f"  GET {url}")
    with urllib.request.urlopen(url, timeout=120) as r:
        body = r.read().decode("utf-8", "replace")
    if len(body) < 200:
        raise SystemExit(f"Response too short ({len(body)} bytes); "
                         f"check the station id and date range.\n{body[:200]}")
    open(out, "w", newline="").write(body)
    print(f"  wrote {out} ({len(body):,} bytes)")
    return out


def load_station(path_or_folder):
    """
    Daily maximum temperature in degC from either product.

    GHCN-Daily : column TMAX, tenths of a degree Celsius
    GSOD       : column MAX,  degrees Fahrenheit, 9999.9 = missing

    Returns {date: degC}. The format is detected from the header, so a folder
    may mix both.
    """
    import csv
    from pathlib import Path
    p = Path(path_or_folder)
    files = sorted(p.glob("*.csv")) if p.is_dir() else [p]
    if not files:
        raise SystemExit(f"No CSV files under {path_or_folder}")

    out, n_ghcn, n_gsod = {}, 0, 0
    for f in files:
        with open(f, newline="") as fh:
            rd = csv.DictReader(fh)
            cols = rd.fieldnames or []
            ghcn = "TMAX" in cols
            for row in rd:
                try:
                    d = datetime.strptime(row["DATE"][:10], "%Y-%m-%d").date()
                except (KeyError, ValueError):
                    continue
                if ghcn:
                    v = (row.get("TMAX") or "").strip()
                    if not v:
                        continue
                    try:
                        c = float(v) / 10.0          # tenths degC
                    except ValueError:
                        continue
                    n_ghcn += 1
                else:
                    v = (row.get("MAX") or "").strip().replace("*", "")
                    if not v:
                        continue
                    try:
                        fF = float(v)
                    except ValueError:
                        continue
                    if fF > 200:                     # 9999.9 sentinel
                        continue
                    c = (fF - 32.0) * 5.0 / 9.0
                    n_gsod += 1
                if -50 < c < 70:                     # physical plausibility
                    out[d] = c
    print(f"  parsed {len(out)} daily maxima "
          f"({n_ghcn} GHCN-Daily rows, {n_gsod} GSOD rows)")
    return out


def load_era5_t2m(era5_dir, lat=STATION[0], lon=STATION[1]):
    """
    Daily maximum ERA5 2 m temperature at the station grid point.

    Files are opened INDIVIDUALLY rather than with open_mfdataset. The archive
    can contain months downloaded under different bounding boxes -- ours mixes a
    wide early box with the narrowed corridor box -- and those have different
    longitude/latitude coordinates, so a merge fails with "Resulting object does
    not have monotonic global indexes along dimension longitude". Since we need
    a single grid point, extracting per file and concatenating the resulting
    series sidesteps the problem entirely and tolerates a heterogeneous archive.
    """
    import xarray as xr
    files = sorted(glob.glob(os.path.join(era5_dir, "*.nc")))
    if not files:
        raise SystemExit(f"No ERA5 files in {era5_dir}")

    out, skipped, used = {}, [], 0
    for f in files:
        try:
            ds = xr.open_dataset(f)
        except Exception as e:
            skipped.append((os.path.basename(f), str(e)[:60]))
            continue
        with ds:
            if "valid_time" in ds.dims:
                ds = ds.rename({"valid_time": "time"})
            var = "t2m" if "t2m" in ds else ("2t" if "2t" in ds else None)
            if var is None or "time" not in ds.dims:
                skipped.append((os.path.basename(f), "no t2m/time"))
                continue
            latn = "latitude" if "latitude" in ds.coords else "lat"
            lonn = "longitude" if "longitude" in ds.coords else "lon"
            if latn not in ds.coords or lonn not in ds.coords:
                skipped.append((os.path.basename(f), "no lat/lon coords"))
                continue

            # the station must fall inside this file's box, or the nearest
            # neighbour silently returns a point tens of km away
            la = ds[latn].values; lo = ds[lonn].values
            if not (min(la) - 0.2 <= lat <= max(la) + 0.2 and
                    min(lo) - 0.2 <= lon <= max(lo) + 0.2):
                skipped.append((os.path.basename(f), "station outside box"))
                continue

            pt = ds[var].sel({latn: lat, lonn: lon}, method="nearest")
            vals = pt.values
            if np.nanmax(vals) > 200:                    # Kelvin
                pt = pt - 273.15
            daily = pt.resample(time="1D").max().to_series()
            for k, v in daily.items():
                if np.isfinite(v):
                    out[k.date()] = float(v)
            used += 1

    print(f"  ERA5: {used} of {len(files)} files used")
    if skipped:
        print(f"  skipped {len(skipped)}:")
        for nm, why in skipped[:6]:
            print(f"    {nm}: {why}")
        if len(skipped) > 6:
            print(f"    ... and {len(skipped)-6} more")
    return out


def summarise(pairs, label):
    if not pairs:
        print(f"  {label}: no overlapping days")
        return None
    e = np.array([p[0] for p in pairs]); g = np.array([p[1] for p in pairs])
    d = e - g
    r = float(np.corrcoef(e, g)[0, 1]) if e.size > 2 else float("nan")
    out = {"n": int(e.size), "bias": float(d.mean()), "mae": float(np.abs(d).mean()),
           "rmse": float(np.sqrt((d ** 2).mean())), "corr": r,
           "era5_mean": float(e.mean()), "gsod_mean": float(g.mean()),
           "p05": float(np.percentile(d, 5)), "p95": float(np.percentile(d, 95))}
    sign = "COLD" if out["bias"] < 0 else "warm"
    print(f"  {label:<28} n={out['n']:>4}  ERA5 {out['era5_mean']:5.1f}  "
          f"GSOD {out['gsod_mean']:5.1f}  bias {out['bias']:+5.2f} ({sign})  "
          f"MAE {out['mae']:4.2f}  r {out['corr']:.3f}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gsod", default="gsod",
                    help="CSV file or folder (GHCN-Daily or GSOD format)")
    ap.add_argument("--fetch", action="store_true",
                    help="download from the NCEI Access Data Service first")
    ap.add_argument("--station", default="SAM00041030")
    ap.add_argument("--dataset", default="daily-summaries",
                    choices=["daily-summaries", "global-summary-of-the-day"])
    ap.add_argument("--start", default="1983-01-01")
    ap.add_argument("--end", default="2024-12-31")
    ap.add_argument("--era5", default="data/raw/era5land")
    ap.add_argument("--hajj-only", action="store_true")
    args = ap.parse_args()

    print("=" * 78)
    print("ERA5 t2m vs GSOD station observations, Mecca (WMO 41030)")
    print("=" * 78)
    print("  Comparing AIR temperature against AIR temperature. ECOSTRESS LST is")
    print("  a SURFACE temperature and is deliberately excluded: the 10-20 C")
    print("  surface-to-air offset is physics, not model error.")

    if args.fetch:
        os.makedirs("gsod", exist_ok=True)
        fetch_ncei(args.station, args.dataset, args.start, args.end,
                   out=os.path.join("gsod", f"{args.station}.csv"))
        args.gsod = "gsod"
    gsod = load_station(args.gsod)
    era5 = load_era5_t2m(args.era5)
    print(f"\n  GSOD days: {len(gsod)}   ERA5 days: {len(era5)}")

    common = sorted(set(gsod) & set(era5))
    print(f"  overlapping days: {len(common)}")
    if not common:
        raise SystemExit("No overlap. Check the years downloaded and the ERA5 range.")

    results = {}
    print("\n  OVERALL")
    results["all"] = summarise([(era5[d], gsod[d]) for d in common], "all overlapping days")

    print("\n  BY YEAR")
    for y in sorted({d.year for d in common}):
        sub = [(era5[d], gsod[d]) for d in common if d.year == y]
        results[f"year_{y}"] = summarise(sub, f"{y}")

    print("\n  ON THE RITUAL DAYS")
    for y, (a, b) in sorted(HAJJ.items()):
        sub = [(era5[d], gsod[d]) for d in common if a <= d <= b]
        results[f"hajj_{y}"] = summarise(sub, f"{y} Hajj ({a:%d %b}-{b:%d %b})")

    print("\n  HOTTEST DAYS (upper decile of GSOD)")
    thr = float(np.percentile([gsod[d] for d in common], 90))
    hot = [(era5[d], gsod[d]) for d in common if gsod[d] >= thr]
    results["hot_decile"] = summarise(hot, f"GSOD >= {thr:.1f} C")

    print("\n" + "=" * 78)
    print("READING THIS")
    print("=" * 78)
    a = results.get("all"); h = results.get("hot_decile")
    if a and h:
        print(f"  overall bias {a['bias']:+.2f} C, hottest-decile bias "
              f"{h['bias']:+.2f} C")
        if h["bias"] < a["bias"] - 0.5:
            print("  -> the cold bias WORSENS at high temperatures, which is the")
            print("     pattern reported for ERA5-Land at Mecca during the 2024")
            print("     Hajj. Our input stack inherits it: the predictors are")
            print("     coldest exactly where the hazard matters most. State this")
            print("     as a limitation and cite the independent finding.")
        elif abs(a["bias"]) < 1.0:
            print("  -> no substantial bias at this station. We do not reproduce")
            print("     the reported underestimate; report that honestly, noting")
            print("     that a single station cannot settle the question.")
        else:
            print("  -> a bias is present but does not worsen in the tail.")
    print("\n  NOTE. GSOD daily MAX is a 24-hour maximum; our ERA5 daily maximum")
    print("  is taken over the same calendar day in UTC. Makkah is UTC+3, so the")
    print("  windows are offset by three hours. For a stricter comparison, shift")
    print("  the ERA5 series to local time before resampling.")

    json.dump(results, open("era5_gsod_validation.json", "w"), indent=2)
    print("\n  results -> era5_gsod_validation.json")


if __name__ == "__main__":
    main()
