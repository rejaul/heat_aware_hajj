"""
Validate the reformulated assignment on the REAL Hajj pedestrian network.

MUST RUN ON A MACHINE WITH INTERNET (the Overpass API is required). This script
was written but could NOT be executed in the development sandbox, where Overpass
is blocked -- so its outputs are unverified. Treat the first run as a test.

What it does
------------
1. fetches/loads the real OSM walk network for the ritual corridor
2. reports network quality (nodes, edges, components, site snapping, widths)
3. attaches an exceedance field (yours, or a placeholder) by line integral
4. sizes the time horizon from the network itself
5. runs the lexicographic multi-cohort, hard-capacity assignment
6. sweeps the dispatch window to find the MINIMUM FEASIBLE window
7. writes real_network_validation.json

Usage
-----
    python validate_real_network.py                          # placeholder field
    python validate_real_network.py --risk field_prob.npy    # your real field
    python validate_real_network.py --network all            # if walk is sparse
"""
from __future__ import annotations

import argparse
import json
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import networkx as nx


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--risk", help=".npy exceedance grid P(WBGT>k), north-up")
    ap.add_argument("--bbox", help="west,south,east,north of the grid")
    ap.add_argument("--network", default="walk",
                    choices=["walk", "all", "all_public"])
    ap.add_argument("--refresh", action="store_true")
    ap.add_argument("--pilgrims", type=float, default=1_800_000)
    ap.add_argument("--walk-frac", type=float, default=0.45)
    ap.add_argument("--dt-min", type=float, default=15.0)
    ap.add_argument("--speed-mode", default="loaded",
                    choices=["capacity", "loaded", "free"],
                    help="travel-time convention. 'capacity' uses v(rho*) on "
                         "every edge (worst case); 'loaded' uses a nominal "
                         "load factor; 'free' uses v_free (best case).")
    ap.add_argument("--load-factor", type=float, default=0.5,
                    help="fraction of rho* used by --speed-mode loaded")
    ap.add_argument("--from", dest="src", default="Mina")
    ap.add_argument("--to", dest="dst", default="Arafat")
    args = ap.parse_args()

    from corridor_network import fetch, snap_sites, report, SITES
    from routing_equilibrium import prepare_edges
    from routing_scalarized import RoutingGraph
    from assignment_td import (TimeExpanded, lexicographic_assign, window_sweep,
                               flow_maximising_density)
    from routing_physics import PARAMS

    out = {"config": vars(args)}

    # ---- 1-2. real network + quality report -----------------------------
    print("=" * 78)
    print("STEP 1: real OSM network")
    print("=" * 78)
    G = fetch(network_type=args.network, refresh=args.refresh)
    snapped = snap_sites(G)
    ok = report(G, snapped)
    out["network"] = {
        "nodes": G.number_of_nodes(), "edges": G.number_of_edges(),
        "network_type": args.network,
        "all_legs_connected": bool(ok),
        "site_snap_m": {k: round(v["snap_m"], 1) for k, v in snapped.items()},
        "site_access_nodes": {k: v.get("n_access", 1) for k, v in snapped.items()},
        "site_node_degree": {k: v.get("degree") for k, v in snapped.items()},
    }
    if not ok:
        print("\nWARNING: some ritual legs are disconnected. Continuing with the")
        print("requested leg only; re-run with --network all if it fails.")

    # ---- 3. exceedance field -------------------------------------------
    print("\n" + "=" * 78)
    print("STEP 2: exceedance field")
    print("=" * 78)
    lats = [d["y"] for _, d in G.nodes(data=True)]
    lons = [d["x"] for _, d in G.nodes(data=True)]
    net_bbox = (min(lons), min(lats), max(lons), max(lats))

    if args.risk:
        field = np.load(args.risk)
        bbox = (tuple(float(x) for x in args.bbox.split(","))
                if args.bbox else __import__("config").BBOX)
        print(f"loaded {args.risk}: shape {field.shape}, "
              f"range [{np.nanmin(field):.3f}, {np.nanmax(field):.3f}]")
    else:
        print("NO --risk GIVEN: using a PLACEHOLDER field (results are not")
        print("meaningful; supply your predicted P(WBGT>k) grid).")
        H = W = 128
        yy, xx = np.mgrid[0:H, 0:W] / H
        field = np.clip(.15 + .7 * np.exp(-((yy - .5) ** 2 + (xx - .5) ** 2) / .05), 0, 1)
        bbox = net_bbox
    out["field"] = {"shape": list(field.shape),
                    "min": float(np.nanmin(field)), "max": float(np.nanmax(field)),
                    "placeholder": args.risk is None,
                    "bbox_used": list(bbox), "network_bbox": list(net_bbox)}

    prepare_edges(G, field, bbox)
    rg = RoutingGraph(G)
    print(f"routing graph: V={rg.S.number_of_nodes():,} E={rg.m:,}")
    print(f"edge widths: min {rg.W.min():.1f} m, median {np.median(rg.W):.1f} m, "
          f"max {rg.W.max():.1f} m  [ASSUMED from OSM tags]")
    out["routing_graph"] = {"V": rg.S.number_of_nodes(), "E": rg.m,
                            "width_median_m": float(np.median(rg.W))}

    # ---- 4. horizon sizing ---------------------------------------------
    print("\n" + "=" * 78)
    print("STEP 3: capacity operating point and horizon")
    print("=" * 78)
    r_s, v_s, q_s = flow_maximising_density()
    print(f"flow-maximising density rho* = {r_s:.3f} ped/m^2  "
          f"(v*={v_s:.3f} m/s, q*={q_s:.3f} ped/m/s)")
    print(f"  vs crush onset rho_c = {PARAMS['rho_crit']:.1f}: capping at rho*")
    print(f"  gives ~2x the throughput AND a faster walk.")

    # use the multi-node ACCESS SET, not the single snapped node
    src = snapped[args.src].get("access", [snapped[args.src]["node"]])
    dst = snapped[args.dst].get("access", [snapped[args.dst]["node"]])
    print(f"  access nodes    : {args.src} {len(src)} "
          f"(r={snapped[args.src].get('radius_m', 0):.0f} m), "
          f"{args.dst} {len(dst)} (r={snapped[args.dst].get('radius_m', 0):.0f} m)")
    probe = TimeExpanded(rg, n_slices=4, dt_s=args.dt_min * 60,
                          speed_mode=args.speed_mode,
                          load_factor=args.load_factor)
    probe.build(theta=0.0)
    need = probe.min_slices_for(src, dst)
    if need is None:
        print(f"\n{args.src} -> {args.dst} NOT REACHABLE on this network. Stop and")
        print("re-fetch with --network all, or pick a connected leg.")
        out["status"] = "leg_unreachable"
        json.dump(out, open("real_network_validation.json", "w"), indent=2)
        return
    T = int(need * 2 + 6)
    print(f"min slices {args.src}->{args.dst} at capacity speed: {need} "
          f"({need*args.dt_min/60:.1f} h)  -> horizon T={T}")

    te = TimeExpanded(rg, n_slices=T, dt_s=args.dt_min * 60,
                      speed_mode=args.speed_mode,
                      load_factor=args.load_factor)
    te.build(theta=0.0)
    st = te.stats()
    print("time-expanded:", st)
    out["time_expanded"] = st
    out["capacity_point"] = {"rho_star": r_s, "v_star": v_s, "q_star": q_s,
                             "min_slices": int(need), "horizon_slices": T}

    # ---- 5. lexicographic multi-cohort assignment -----------------------
    N = args.pilgrims * args.walk_frac
    win_hi = max(2, T // 3)
    print("\n" + "=" * 78)
    print(f"STEP 4: lexicographic assignment (N={N:,.0f} walking, "
          f"window slices 0-{win_hi})")
    print("=" * 78)
    res = lexicographic_assign(te, src, dst, N, (0, win_hi))
    out["assignment"] = {k: v for k, v in res.items()}

    # ---- 6. dispatch-window sweep --------------------------------------
    print("\n" + "=" * 78)
    print("STEP 5: minimum feasible dispatch window")
    print("=" * 78)
    wins = sorted(set([1, 2, 4, 8, 12, 16, 24, max(2, T // 3), T - 1]))
    wins = [w for w in wins if 1 <= w < T]
    rows = window_sweep(te, src, dst, N, wins)
    min_feasible = None
    for r in rows:
        if r["feasible"]:
            if min_feasible is None:
                min_feasible = r["hours"]
            print(f"  {r['slices']:>3} slices ({r['hours']:5.1f} h): FEASIBLE  "
                  f"{r['mean_km']:6.2f} km {r['mean_min']:7.1f} min "
                  f"dose {r['mean_dose']:9.1f} max util {r['max_util']:.2f}")
        else:
            print(f"  {r['slices']:>3} slices ({r['hours']:5.1f} h): INFEASIBLE")
    out["window_sweep"] = rows
    out["min_feasible_window_h"] = min_feasible
    if min_feasible is not None:
        print(f"\n  MINIMUM FEASIBLE DISPATCH WINDOW: {min_feasible:.1f} hours")
        print("  This is the operationally actionable number the soft-penalty")
        print("  model could not produce -- it would have returned a 'solution'")
        print("  at crush density instead of declaring infeasibility.")

    json.dump(out, open("real_network_validation.json", "w"), indent=2, default=str)
    print("\nsaved -> real_network_validation.json")


if __name__ == "__main__":
    main()
