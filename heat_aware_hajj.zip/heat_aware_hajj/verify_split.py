"""
Verify what the validation split ACTUALLY is, before making a claim about it.

Two different splits exist in this pipeline and they support DIFFERENT claims:

  dataset.py:split_files()  -> index slice of sorted filenames  (real-data path)
  compare.py:make_scene()   -> contiguous SPATIAL block         (synthetic path)

This script checks the real-data path against your files on disk and tells you
which sentence you are entitled to write.

Run:  python verify_split.py
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import config
from dataset import split_files

DATE_PATTERNS = [
    (r"(\d{8})T(\d{6})", "%Y%m%dT%H%M%S"),   # 20240615T103012 (ECOSTRESS style)
    (r"(\d{4})-(\d{2})-(\d{2})", "iso"),
    (r"doy(\d{4})(\d{3})", "doy"),
]


def extract_dt(name: str):
    """Pull an acquisition timestamp out of a filename, if one is present."""
    m = re.search(r"(\d{8})T(\d{6})", name)
    if m:
        return m.group(1) + m.group(2)
    m = re.search(r"(\d{8})", name)
    if m:
        return m.group(1)
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", name)
    if m:
        return "".join(m.groups())
    return None


def main():
    pair_dir = Path(config.PAIRS)
    files = sorted(pair_dir.glob("*_pair.nc"))
    if not files:
        sys.exit(f"No pairs in {pair_dir}. Run align.py first.")

    print("=" * 74)
    print("WHAT IS THE SPLIT, ACTUALLY?")
    print("=" * 74)
    print(f"pair directory : {pair_dir}")
    print(f"files found    : {len(files)}")
    print(f"example name   : {files[0].name}")

    # ---- 1. do filenames carry a parseable acquisition timestamp? ----
    stamps = [extract_dt(f.name) for f in files]
    n_ok = sum(s is not None for s in stamps)
    print(f"\n1. timestamps parsed from filenames: {n_ok}/{len(files)}")
    if n_ok < len(files):
        print("   -> SOME FILES HAVE NO PARSEABLE DATE.")
        print("      You cannot claim a temporal split without fixing naming.")

    # ---- 2. does lexicographic order == chronological order? ----
    if n_ok == len(files):
        lex = list(range(len(files)))
        chrono = sorted(lex, key=lambda i: stamps[i])
        same = lex == chrono
        print(f"\n2. lexicographic order == chronological order: {same}")
        if not same:
            n_bad = sum(1 for a, b in zip(lex, chrono) if a != b)
            print(f"   -> NO. {n_bad} files are out of chronological order.")
            print("      split_files() sorts by NAME, so the split is NOT temporal.")
            print("      Fix: sort by parsed timestamp, or rename files date-first.")
        else:
            print("   -> yes: sorting by name does sort by acquisition time.")
    else:
        same = False

    # ---- 3. are the resulting sets date-disjoint? ----
    tr, va, cal = split_files()
    print(f"\n3. split sizes: train {len(tr)} | val {len(va)} | calib {len(cal)}")

    def dates_of(fs):
        return {extract_dt(f.name)[:8] for f in fs if extract_dt(f.name)}

    dtr, dva, dcal = dates_of(tr), dates_of(va), dates_of(cal)
    print(f"   distinct acquisition DAYS: train {len(dtr)}, val {len(dva)}, "
          f"calib {len(dcal)}")
    ov_tv, ov_tc, ov_vc = dtr & dva, dtr & dcal, dva & dcal
    disjoint = not (ov_tv or ov_tc or ov_vc)
    print(f"   date-disjoint across all three sets: {disjoint}")
    for nm, ov in (("train/val", ov_tv), ("train/calib", ov_tc), ("val/calib", ov_vc)):
        if ov:
            print(f"     {nm} SHARE {len(ov)} day(s): {sorted(ov)[:5]}")
            print("     -> scenes from the same day appear on both sides:")
            print("        NOT a disjoint-date hold-out, and the conformal")
            print("        calibration guarantee is weakened by the leakage.")

    if dtr and dva and dcal and disjoint:
        print(f"   ranges: train {min(dtr)}..{max(dtr)} | "
              f"val {min(dva)}..{max(dva)} | calib {min(dcal)}..{max(dcal)}")
        forward = max(dtr) <= min(dva) and max(dva) <= min(dcal)
        print(f"   strictly forward in time (train < val < calib): {forward}")

    # ---- 4. spatial coverage: is the domain fixed? ----
    print("\n4. spatial domain")
    print(f"   config.BBOX = {config.BBOX}")
    print("   All pairs are cut to this single bounding box, so every split")
    print("   shares the SAME spatial domain. Spatial generalisation to other")
    print("   regions is therefore untested -- that non-claim is correct.")

    # ---- verdict ----
    print("\n" + "=" * 74)
    print("WHAT YOU MAY WRITE")
    print("=" * 74)
    if n_ok == len(files) and same and disjoint:
        print("OK: 'We use a temporal hold-out: training, validation and")
        print("     calibration sets are drawn from disjoint acquisition dates.")
        print("     The spatial domain is fixed, so spatial generalisation is")
        print("     not tested.'")
    else:
        print("NOT YET. The chronological split is not verified. Either fix the")
        print("ordering/naming, or write what is true, e.g.:")
        print("  'We split scenes by sorted filename into disjoint training,")
        print("   validation and calibration sets over a fixed spatial domain.'")

    print("\nIMPORTANT -- which results is the claim about?")
    print("  * dataset.py/split_files : the REAL-DATA path (this script).")
    print("  * compare.py/make_scene  : the SYNTHETIC path, which uses a")
    print("    CONTIGUOUS SPATIAL BLOCK hold-out, not a temporal one.")
    print("  If the numbers in your paper come from compare.py, then a")
    print("  'temporal hold-out' sentence is WRONG for them, and the correct")
    print("  non-claim is the reverse: a spatial block is held out, while")
    print("  TEMPORAL generalisation is untested.")


if __name__ == "__main__":
    main()
